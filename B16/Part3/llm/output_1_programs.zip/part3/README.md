# Part 3: two JUnit 6.1.3 patterns in four languages

| Folder | Pattern | JUnit instance it is based on |
|---|---|---|
| `observer-test-listeners/` | Observer | C1: `TestExecutionListener`, with failures isolated as in `CompositeTestExecutionListener.notifyEach` |
| `composite-test-tree/` | Composite | A1: the `TestDescriptor` tree (engine, classes, methods), with `prune()` |

Each problem folder has the same layout:

```
test-data/     input file(s), the exact expected output, a bad input and its expected error
java/          code in src/, test runner in test/, README.md
python/        code, test_*.py (unittest), README.md
javascript/    code in src/, test/*.test.js (node:test), README.md
cpp/           code, test_main.cpp, README.md
```

Every version reads the same input and prints byte-for-byte the same output, which each test
runner checks against `test-data/expected-output.txt`. Each test runner also checks that the bad
input fails with the exact message in `test-data/expected-error.txt`, plus one pattern-specific
check (a throwing listener does not stop the next one; a leaf and a container answer `countTests`
the same way). Standard library only; nothing to install.

The exact commands are in each language's README, to be run from that language's folder.
`sh run-all.sh` (from this folder) runs all of them in order and diffs every program's output
against the expected file.

## What was run, and with which versions

`RUN-LOG.txt` is the full, unedited output of `sh run-all.sh`: 30 commands, all exit 0, and all
eight programs' output identical to `expected-output.txt`. It was run in a Linux container, whose
toolchain is older than yours:

| Tool | Used here | Yours |
|---|---|---|
| Java | OpenJDK 21.0.12.1 | Java 25 |
| Python | 3.13.16 | 3.14 |
| Node.js | v22.22.0 | 26 |
| C++ | Ubuntu clang 18.1.3 and g++ 13.3.0, `-std=c++20` (libstdc++) | Apple clang 21, C++20 (libc++) |

The code avoids anything newer than these versions and anything removed since, so it should run
unchanged on yours; there was no way to run your exact versions here. The `duration_ms` lines in
the Node test output are printed by `node --test` itself; nothing was timed on purpose.

Extra checks that are not in the log:
- Both C++ test runners also passed when built with g++ and `-fsanitize=address,undefined`
  (no leaks or memory errors). The C++ headers include everything they use directly, because Apple's
  libc++ is stricter about indirect includes than the libstdc++ used here.
- 16 more inputs (every parser error message, extra whitespace, `\r\n` line endings, a reason with
  spaces, a tag that matches nothing) gave identical output and exit codes in all four languages.
- Running each program on the bad input prints the expected error to stderr and exits with 1.
