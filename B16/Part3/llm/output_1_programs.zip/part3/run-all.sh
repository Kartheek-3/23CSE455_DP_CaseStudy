#!/bin/sh
# Runs every compile, run and test command from the READMEs, from each language folder,
# and diffs every program's output against the shared expected-output.txt.
# Usage: sh run-all.sh   (from this part3/ folder). Exits 1 if anything failed.

cd "$(dirname "$0")" || exit 1
ROOT=$(pwd)
FAILED=0

step() {
    printf '\n$ %s\n' "$*"
    sh -c "$*" 2>&1
    status=$?
    echo "[exit $status]"
    [ "$status" -eq 0 ] || FAILED=1
}

in_dir() {
    cd "$ROOT/$1" || exit 1
    printf '\n========== %s ==========\n' "$1"
}

echo "== Tool versions =="
uname -sm
java -version 2>&1 | head -1
javac -version 2>&1
python3 --version
node --version
clang++ --version | head -1

for problem in observer-test-listeners composite-test-tree; do
    if [ "$problem" = observer-test-listeners ]; then
        pkg=observer; demo=ObserverDemo; test=ObserverTest; args="../test-data/events.txt"
        py_test=test_observer; js_test=test/observer.test.js
        cpp_src="listeners.cpp runner.cpp"; bin=observer
    else
        pkg=composite; demo=CompositeDemo; test=CompositeTest; args="../test-data/tree.txt slow"
        py_test=test_composite; js_test=test/composite.test.js
        cpp_src="nodes.cpp tree_parser.cpp"; bin=composite
    fi
    expected="../test-data/expected-output.txt"

    in_dir "$problem/java"
    step "javac -d out src/$pkg/*.java test/$pkg/*.java"
    step "java -cp out $pkg.$demo $args"
    step "java -cp out $pkg.$demo $args | diff - $expected && echo same"
    step "java -cp out $pkg.$test"

    in_dir "$problem/python"
    step "python3 main.py $args"
    step "python3 main.py $args | diff - $expected && echo same"
    step "python3 -m unittest -v $py_test"

    in_dir "$problem/javascript"
    step "node src/main.js $args"
    step "node src/main.js $args | diff - $expected && echo same"
    step "node --test $js_test"

    in_dir "$problem/cpp"
    step "clang++ -std=c++20 -Wall -Wextra -pedantic -o $bin main.cpp $cpp_src"
    step "./$bin $args"
    step "./$bin $args | diff - $expected && echo same"
    step "clang++ -std=c++20 -Wall -Wextra -pedantic -o ${bin}_test test_main.cpp $cpp_src"
    step "./${bin}_test"
done

echo
[ "$FAILED" -eq 0 ] && echo "ALL STEPS PASSED" || echo "SOME STEPS FAILED"
exit "$FAILED"
