import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Trainer } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class TrainersService {
  private apiUrl = `${environment.apiUrl}/trainers`;

  constructor(private http: HttpClient) {}

  getAll(search?: string): Observable<Trainer[]> {
    let params = new HttpParams();
    if (search) params = params.set('search', search);
    return this.http.get<Trainer[]>(this.apiUrl, { params });
  }

  getById(id: number): Observable<Trainer> {
    return this.http.get<Trainer>(`${this.apiUrl}/${id}`);
  }

  getMe(): Observable<Trainer> {
    return this.http.get<Trainer>(`${this.apiUrl}/me`);
  }

  create(data: any): Observable<Trainer> {
    return this.http.post<Trainer>(this.apiUrl, data);
  }

  update(id: number, data: any): Observable<Trainer> {
    return this.http.put<Trainer>(`${this.apiUrl}/${id}`, data);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  getAvailability(trainerId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/${trainerId}/availability`);
  }

  setAvailability(trainerId: number, data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/${trainerId}/availability`, data);
  }

  rateTrainer(data: { trainer_id: number; rating: number; comment?: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/rate`, data);
  }
}
