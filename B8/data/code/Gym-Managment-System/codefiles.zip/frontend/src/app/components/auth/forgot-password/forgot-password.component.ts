import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="auth-page">
      <div class="auth-hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
          <h1 class="hero-title">RESET<br>ACCESS</h1>
          <p class="hero-sub">We'll send a secure link to reset your password.</p>
        </div>
      </div>
      <div class="auth-panel">
        <div class="auth-form-wrap">
          <div class="auth-brand">
            <span class="brand-name">GYM</span><span class="brand-sub">MANAGER</span>
          </div>
          <h2 class="auth-title">Reset Password</h2>
          <p class="auth-desc">Enter your email address to receive a reset link.</p>
          <form (ngSubmit)="onSubmit()">
            <div class="form-group">
              <label>Email Address</label>
              <input type="email" [(ngModel)]="email" name="email" required
                     placeholder="you@example.com" class="form-control" />
            </div>
            <div class="alert alert-error" *ngIf="error">{{ error }}</div>
            <div class="alert alert-success" *ngIf="success">{{ success }}</div>
            <button type="submit" class="btn btn-white btn-full" [disabled]="loading">
              {{ loading ? 'SENDING...' : 'SEND RESET LINK' }}
            </button>
          </form>
          <p class="auth-switch"><a routerLink="/login">Back to Sign In</a></p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-page { display: flex; min-height: 100vh; background: #000; }
    .auth-hero {
      flex: 1; position: relative; overflow: hidden;
      background-image: url('https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=1200&q=80');
      background-size: cover; background-position: center;
      display: flex; flex-direction: column; justify-content: flex-end; padding: 3rem;
    }
    .hero-overlay { position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.3) 100%); }
    .hero-content { position: relative; z-index: 1; }
    .hero-title { font-family: 'Bebas Neue', sans-serif; font-size: clamp(4rem, 8vw, 7rem); line-height: 0.9; letter-spacing: 0.02em; color: #fff; }
    .hero-sub { color: #aaa; font-size: 0.95rem; margin-top: 1rem; max-width: 380px; }
    .auth-panel { width: 460px; flex-shrink: 0; background: #0a0a0a; border-left: 1px solid #1a1a1a; display: flex; align-items: center; justify-content: center; padding: 2rem; }
    .auth-form-wrap { width: 100%; max-width: 360px; }
    .auth-brand { display: flex; align-items: baseline; gap: 0.2rem; margin-bottom: 2.5rem; }
    .brand-name { font-family: 'Bebas Neue', sans-serif; font-size: 1.8rem; color: #fff; letter-spacing: 0.1em; }
    .brand-sub  { font-size: 0.65rem; font-weight: 700; letter-spacing: 0.25em; color: #444; }
    .auth-title { font-family: 'Bebas Neue', sans-serif; font-size: 2rem; letter-spacing: 0.05em; color: #fff; margin-bottom: 0.4rem; }
    .auth-desc  { color: #666; font-size: 0.875rem; margin-bottom: 2rem; }
    .form-group { margin-bottom: 1.25rem; }
    .form-group label { display: block; font-size: 0.7rem; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; color: #666; margin-bottom: 0.4rem; }
    .form-control { width: 100%; padding: 0.875rem 1rem; background: #111; border: 1px solid #2a2a2a; border-radius: 2px; color: #fff; font-size: 0.95rem; box-sizing: border-box; }
    .form-control:focus { outline: none; border-color: #fff; }
    .form-control::placeholder { color: #444; }
    .btn-white { display: inline-flex; align-items: center; justify-content: center; width: 100%; padding: 0.875rem; background: #fff; color: #000; border: none; border-radius: 2px; font-weight: 700; font-size: 0.8rem; letter-spacing: 0.1em; text-transform: uppercase; cursor: pointer; transition: background 0.2s; margin-bottom: 1.5rem; }
    .btn-white:hover:not(:disabled) { background: #e0e0e0; }
    .btn-white:disabled { opacity: 0.4; cursor: not-allowed; }
    .btn-full { width: 100%; }
    .alert { padding: 0.75rem 1rem; border-radius: 2px; margin-bottom: 1rem; font-size: 0.875rem; }
    .alert-error { background: rgba(229,62,62,0.1); color: #fc8181; border: 1px solid rgba(229,62,62,0.3); }
    .alert-success { background: rgba(56,161,105,0.1); color: #68d391; border: 1px solid rgba(56,161,105,0.3); }
    .auth-switch { text-align: center; font-size: 0.8rem; color: #555; }
    .auth-switch a { color: #999; font-weight: 600; }
    .auth-switch a:hover { color: #fff; }
    @media (max-width: 900px) { .auth-hero { display: none; } .auth-panel { width: 100%; border-left: none; } }
  `]
})
export class ForgotPasswordComponent {
  email = ''; loading = false; error = ''; success = '';
  constructor(private auth: AuthService) {}
  onSubmit() {
    if (!this.email) { this.error = 'Please enter your email.'; return; }
    this.loading = true;
    this.auth.forgotPassword(this.email).subscribe({
      next: () => { this.loading = false; this.success = 'Reset link sent! Check your inbox.'; },
      error: (err) => { this.loading = false; this.error = err.error?.detail || 'Failed to send reset link.'; }
    });
  }
}
