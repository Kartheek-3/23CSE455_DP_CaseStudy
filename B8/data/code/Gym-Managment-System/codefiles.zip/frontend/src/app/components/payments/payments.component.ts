import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PaymentsService } from '../../services/payments.service';
import { MembersService } from '../../services/members.service';
import { AuthService } from '../../services/auth.service';
import { SubscriptionPlan, Payment } from '../../models/user.model';

@Component({
  selector: 'app-payments',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <div>
          <h1>Payments</h1>
          <p>{{ auth.isAdmin() ? 'Manage subscriptions and transactions' : 'View your subscription and payment history' }}</p>
        </div>
        <button class="btn btn-primary" *ngIf="auth.isAdmin()" (click)="openPlanModal()">+ New Plan</button>
      </div>

      <!-- MEMBER VIEW -->
      <ng-container *ngIf="auth.isMember()">
        <div class="section-title">Subscription Plans</div>
        <div class="plans-grid">
          <div class="plan-card" *ngFor="let plan of plans" [ngClass]="{ featured: plan.interval === 'monthly' }">
            <div class="plan-badge" *ngIf="plan.interval === 'monthly'">Most Popular</div>
            <h3 class="plan-name">{{ plan.name }}</h3>
            <div class="plan-price">
              <span class="price">\${{ plan.price }}</span>
              <span class="interval">/ {{ plan.interval }}</span>
            </div>
            <p class="plan-desc" *ngIf="plan.description">{{ plan.description }}</p>
            <div class="plan-features">
              <div>✅ {{ plan.duration_days }} days access</div>
              <div *ngIf="plan.trial_days > 0">🎁 {{ plan.trial_days }}-day free trial</div>
              <div>💳 {{ plan.currency }} billing</div>
            </div>
            <button class="btn btn-primary btn-full" (click)="subscribeToPlan(plan)" [disabled]="subscribing === plan.id">
              {{ subscribing === plan.id ? 'Processing...' : 'Subscribe Now' }}
            </button>
          </div>
        </div>

        <div class="section-title" style="margin-top:2rem">Payment History</div>
        <div class="table-wrapper">
          <table class="data-table">
            <thead><tr><th>Plan</th><th>Amount</th><th>Status</th><th>Gateway</th><th>Date</th></tr></thead>
            <tbody>
              <tr *ngFor="let p of myPayments">
                <td>{{ p.subscription_plan || '—' }}</td>
                <td><strong>{{ p.currency }} {{ p.amount }}</strong></td>
                <td><span class="status-badge" [ngClass]="p.status">{{ p.status | titlecase }}</span></td>
                <td>{{ p.gateway_name || '—' }}</td>
                <td>{{ p.created_at | date:'MMM d, yyyy' }}</td>
              </tr>
              <tr *ngIf="myPayments.length === 0"><td colspan="5" class="empty">No payment history.</td></tr>
            </tbody>
          </table>
        </div>
      </ng-container>

      <!-- ADMIN VIEW -->
      <ng-container *ngIf="auth.isAdmin()">
        <div class="stats-row" *ngIf="revenueStats">
          <div class="mini-stat green">
            <span class="mini-val">\${{ revenueStats.monthly_revenue?.toFixed(0) }}</span>
            <span class="mini-label">Monthly Revenue</span>
          </div>
          <div class="mini-stat blue">
            <span class="mini-val">\${{ revenueStats.total_revenue?.toFixed(0) }}</span>
            <span class="mini-label">Total Revenue</span>
          </div>
        </div>

        <div class="tabs">
          <button class="tab" [ngClass]="{ active: activeTab === 'transactions' }" (click)="activeTab = 'transactions'">Transactions</button>
          <button class="tab" [ngClass]="{ active: activeTab === 'plans' }" (click)="activeTab = 'plans'">Subscription Plans</button>
          <button class="tab" [ngClass]="{ active: activeTab === 'manual' }" (click)="activeTab = 'manual'">Manual Payment</button>
        </div>

        <div *ngIf="activeTab === 'transactions'">
          <div class="filter-bar">
            <select [(ngModel)]="statusFilter" (change)="loadAllPayments()" class="filter-select">
              <option value="">All Status</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="failed">Failed</option>
            </select>
          </div>
          <div class="table-wrapper">
            <table class="data-table">
              <thead><tr><th>Member</th><th>Plan</th><th>Amount</th><th>Status</th><th>Gateway</th><th>Date</th></tr></thead>
              <tbody>
                <tr *ngFor="let p of allPayments">
                  <td>{{ p.member_name || '—' }}</td>
                  <td>{{ p.subscription_plan || '—' }}</td>
                  <td><strong>{{ p.currency }} {{ p.amount }}</strong></td>
                  <td><span class="status-badge" [ngClass]="p.status">{{ p.status | titlecase }}</span></td>
                  <td>{{ p.gateway_name || '—' }}</td>
                  <td>{{ p.created_at | date:'MMM d, yyyy' }}</td>
                </tr>
                <tr *ngIf="allPayments.length === 0"><td colspan="6" class="empty">No transactions found.</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div *ngIf="activeTab === 'plans'">
          <div class="plans-grid">
            <div class="plan-card" *ngFor="let plan of plans">
              <h3 class="plan-name">{{ plan.name }}</h3>
              <div class="plan-price"><span class="price">\${{ plan.price }}</span><span class="interval">/ {{ plan.interval }}</span></div>
              <p class="plan-desc" *ngIf="plan.description">{{ plan.description }}</p>
              <div class="plan-features">
                <div>📅 {{ plan.duration_days }} days</div>
                <div *ngIf="plan.trial_days">🎁 {{ plan.trial_days }}-day trial</div>
              </div>
              <div class="plan-actions">
                <button class="btn btn-outline btn-sm" (click)="editPlan(plan)">Edit</button>
                <button class="btn btn-danger btn-sm" (click)="deletePlan(plan.id)">Remove</button>
              </div>
            </div>
          </div>
        </div>

        <div *ngIf="activeTab === 'manual'">
          <div class="manual-card card">
            <h3>Add Manual Payment</h3>
            <div class="form-row">
              <div class="form-group">
                <label>Member *</label>
                <select [(ngModel)]="manualForm.member_id" class="form-control">
                  <option [ngValue]="null">— Select Member —</option>
                  <option *ngFor="let m of members" [ngValue]="m.id">{{ m.full_name }}</option>
                </select>
              </div>
              <div class="form-group">
                <label>Amount *</label>
                <input type="number" [(ngModel)]="manualForm.amount" class="form-control" min="0" step="0.01" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Subscription Plan</label>
                <select [(ngModel)]="manualForm.subscription_plan" class="form-control">
                  <option value="">— Select Plan —</option>
                  <option *ngFor="let p of plans" [value]="p.name">{{ p.name }}</option>
                </select>
              </div>
              <div class="form-group">
                <label>Currency</label>
                <select [(ngModel)]="manualForm.currency" class="form-control">
                  <option value="USD">USD</option>
                  <option value="EUR">EUR</option>
                  <option value="GBP">GBP</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label>Notes</label>
              <input type="text" [(ngModel)]="manualForm.notes" class="form-control" placeholder="e.g. Cash payment" />
            </div>
            <div class="alert alert-error" *ngIf="manualError">{{ manualError }}</div>
            <div class="alert alert-success" *ngIf="manualSuccess">{{ manualSuccess }}</div>
            <button class="btn btn-primary" (click)="addManualPayment()" [disabled]="savingManual">
              {{ savingManual ? 'Processing...' : '💰 Record Payment' }}
            </button>
          </div>
        </div>
      </ng-container>

      <!-- Plan Modal -->
      <div class="modal-overlay" *ngIf="showPlanModal" (click)="showPlanModal = false">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>{{ editingPlan ? 'Edit Plan' : 'New Subscription Plan' }}</h2>
            <button class="modal-close" (click)="showPlanModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="form-row">
              <div class="form-group">
                <label>Plan Name *</label>
                <input type="text" [(ngModel)]="planForm.name" class="form-control" placeholder="e.g. Monthly Premium" />
              </div>
              <div class="form-group">
                <label>Interval *</label>
                <select [(ngModel)]="planForm.interval" class="form-control">
                  <option value="monthly">Monthly</option>
                  <option value="quarterly">Quarterly</option>
                  <option value="yearly">Yearly</option>
                  <option value="drop_in">Drop-in</option>
                </select>
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Price *</label>
                <input type="number" [(ngModel)]="planForm.price" class="form-control" min="0" step="0.01" />
              </div>
              <div class="form-group">
                <label>Duration (days) *</label>
                <input type="number" [(ngModel)]="planForm.duration_days" class="form-control" min="1" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Currency</label>
                <select [(ngModel)]="planForm.currency" class="form-control">
                  <option value="USD">USD</option><option value="EUR">EUR</option><option value="GBP">GBP</option>
                </select>
              </div>
              <div class="form-group">
                <label>Trial Days</label>
                <input type="number" [(ngModel)]="planForm.trial_days" class="form-control" min="0" />
              </div>
            </div>
            <div class="form-group">
              <label>Description</label>
              <textarea [(ngModel)]="planForm.description" class="form-control" rows="2"></textarea>
            </div>
            <div class="alert alert-error" *ngIf="planFormError">{{ planFormError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="showPlanModal = false">Cancel</button>
            <button class="btn btn-primary" (click)="savePlan()" [disabled]="savingPlan">{{ savingPlan ? 'Saving...' : (editingPlan ? 'Update' : 'Create') }}</button>
          </div>
        </div>
      </div>

      <div class="toast" *ngIf="toast" [ngClass]="toastType">{{ toast }}</div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; max-width: 1100px; margin: 0 auto; }
    .page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
    .page-header h1 { font-size: 1.75rem; font-weight: 700; color: #1a202c; margin: 0; }
    .page-header p { color: #718096; margin-top: 0.25rem; }
    .section-title { font-size: 1.1rem; font-weight: 700; color: #2d3748; margin-bottom: 1rem; }
    .plans-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1.25rem; margin-bottom: 1rem; }
    .plan-card { background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); position: relative; border: 2px solid transparent; display: flex; flex-direction: column; gap: 0.75rem; }
    .plan-card.featured { border-color: #667eea; }
    .plan-badge { position: absolute; top: -10px; left: 50%; transform: translateX(-50%); background: linear-gradient(135deg,#667eea,#764ba2); color: white; padding: 0.2rem 0.75rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; white-space: nowrap; }
    .plan-name { font-size: 1.1rem; font-weight: 700; color: #1a202c; margin: 0; }
    .plan-price { display: flex; align-items: baseline; gap: 0.25rem; }
    .price { font-size: 2rem; font-weight: 800; color: #667eea; }
    .interval { color: #718096; font-size: 0.9rem; }
    .plan-desc { font-size: 0.875rem; color: #718096; margin: 0; }
    .plan-features { display: flex; flex-direction: column; gap: 0.3rem; font-size: 0.875rem; color: #4a5568; }
    .btn-full { width: 100%; }
    .plan-actions { display: flex; gap: 0.5rem; }
    .stats-row { display: flex; gap: 1rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
    .mini-stat { background: white; border-radius: 10px; padding: 1rem 1.5rem; display: flex; flex-direction: column; align-items: center; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .mini-stat.green .mini-val { color: #276749; }
    .mini-stat.blue .mini-val { color: #3182ce; }
    .mini-val { font-size: 1.75rem; font-weight: 700; }
    .mini-label { font-size: 0.75rem; color: #718096; }
    .tabs { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; border-bottom: 2px solid #e2e8f0; }
    .tab { padding: 0.75rem 1.25rem; background: none; border: none; cursor: pointer; font-weight: 600; color: #718096; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all 0.2s; }
    .tab.active { color: #667eea; border-bottom-color: #667eea; }
    .filter-bar { margin-bottom: 1rem; }
    .filter-select { padding: 0.5rem 0.75rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.875rem; background: white; }
    .table-wrapper { background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.06); overflow-x: auto; margin-bottom: 1.5rem; }
    .data-table { width: 100%; border-collapse: collapse; min-width: 500px; }
    .data-table th { background: #f7fafc; padding: 0.75rem 1rem; text-align: left; font-size: 0.8rem; font-weight: 600; color: #718096; text-transform: uppercase; }
    .data-table td { padding: 0.875rem 1rem; border-top: 1px solid #f0f4f8; font-size: 0.9rem; color: #4a5568; }
    .status-badge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
    .status-badge.completed { background: #f0fff4; color: #276749; }
    .status-badge.pending { background: #fffbeb; color: #92400e; }
    .status-badge.failed { background: #fff5f5; color: #c53030; }
    .status-badge.refunded { background: #ebf4ff; color: #3182ce; }
    .empty { text-align: center; color: #a0aec0; padding: 2rem; }
    .card { background: white; border-radius: 12px; padding: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); margin-bottom: 1.5rem; }
    .manual-card h3 { font-size: 1.1rem; font-weight: 700; margin: 0 0 1rem; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .form-group { margin-bottom: 1rem; }
    .form-group label { display: block; font-weight: 600; color: #4a5568; margin-bottom: 0.4rem; font-size: 0.875rem; }
    .form-control { width: 100%; padding: 0.65rem 0.875rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; box-sizing: border-box; }
    .form-control:focus { outline: none; border-color: #667eea; }
    textarea.form-control { resize: vertical; }
    .btn { padding: 0.6rem 1.25rem; border-radius: 8px; border: none; cursor: pointer; font-weight: 600; font-size: 0.9rem; transition: all 0.2s; }
    .btn-primary { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .btn-outline { background: white; border: 2px solid #667eea; color: #667eea; }
    .btn-danger { background: #fff5f5; border: 2px solid #fc8181; color: #c53030; }
    .btn-sm { padding: 0.35rem 0.75rem; font-size: 0.8rem; }
    .alert { padding: 0.75rem 1rem; border-radius: 8px; margin-top: 1rem; font-size: 0.875rem; }
    .alert-error { background: #fff5f5; color: #c53030; border: 1px solid #fed7d7; }
    .alert-success { background: #f0fff4; color: #276749; border: 1px solid #c6f6d5; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 1rem; }
    .modal { background: white; border-radius: 16px; width: 100%; max-width: 520px; max-height: 90vh; overflow-y: auto; }
    .modal-header { display: flex; justify-content: space-between; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #e2e8f0; }
    .modal-header h2 { font-size: 1.25rem; font-weight: 700; margin: 0; }
    .modal-close { background: none; border: none; font-size: 1.25rem; cursor: pointer; color: #718096; }
    .modal-body { padding: 1.5rem; }
    .modal-footer { padding: 1rem 1.5rem; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 0.75rem; }
    .toast { position: fixed; bottom: 1.5rem; right: 1.5rem; padding: 0.875rem 1.5rem; border-radius: 10px; font-weight: 600; z-index: 2000; }
    .toast.success { background: #276749; color: white; }
    .toast.error { background: #c53030; color: white; }
    @media (max-width: 640px) { .form-row { grid-template-columns: 1fr; } .plans-grid { grid-template-columns: 1fr; } }
  `]
})
export class PaymentsComponent implements OnInit {
  plans: SubscriptionPlan[] = [];
  myPayments: Payment[] = [];
  allPayments: Payment[] = [];
  members: any[] = [];
  revenueStats: any = null;
  activeTab = 'transactions';
  statusFilter = '';
  subscribing: number | null = null;
  showPlanModal = false;
  editingPlan: SubscriptionPlan | null = null;
  savingPlan = false;
  planFormError = '';
  savingManual = false;
  manualError = '';
  manualSuccess = '';
  toast = '';
  toastType = 'success';

  planForm: any = { name: '', interval: 'monthly', price: 0, duration_days: 30, currency: 'USD', trial_days: 0, description: '' };
  manualForm: any = { member_id: null, amount: 0, currency: 'USD', subscription_plan: '', notes: '' };

  constructor(
    public auth: AuthService,
    private paymentsService: PaymentsService,
    private membersService: MembersService
  ) {}

  ngOnInit() {
    this.paymentsService.getPlans().subscribe(p => this.plans = p);
    if (this.auth.isMember()) {
      this.membersService.getMe().subscribe(m => {
        this.paymentsService.getHistory(m.id).subscribe(p => this.myPayments = p);
      });
    }
    if (this.auth.isAdmin()) {
      this.loadAllPayments();
      this.paymentsService.getRevenueStats().subscribe(s => this.revenueStats = s);
      this.membersService.getAll().subscribe(m => this.members = m);
    }
  }

  loadAllPayments() {
    this.paymentsService.getAllPayments(this.statusFilter).subscribe(p => this.allPayments = p);
  }

  subscribeToPlan(plan: SubscriptionPlan) {
    this.subscribing = plan.id;
    this.paymentsService.createCheckoutSession({ plan_id: plan.id, gateway: 'stripe' }).subscribe({
      next: (res) => {
        this.subscribing = null;
        if (res.checkout_url) window.open(res.checkout_url, '_blank');
        else this.showToast('Payment initiated (demo mode).', 'success');
      },
      error: (err) => { this.subscribing = null; this.showToast(err.error?.detail || 'Payment failed.', 'error'); }
    });
  }

  openPlanModal() {
    this.editingPlan = null;
    this.planForm = { name: '', interval: 'monthly', price: 0, duration_days: 30, currency: 'USD', trial_days: 0, description: '' };
    this.planFormError = '';
    this.showPlanModal = true;
  }

  editPlan(plan: SubscriptionPlan) {
    this.editingPlan = plan;
    this.planForm = { name: plan.name, interval: plan.interval, price: plan.price, duration_days: plan.duration_days, currency: plan.currency, trial_days: plan.trial_days, description: plan.description || '' };
    this.planFormError = '';
    this.showPlanModal = true;
  }

  savePlan() {
    this.savingPlan = true;
    this.planFormError = '';
    const obs = this.editingPlan
      ? this.paymentsService.updatePlan(this.editingPlan.id, this.planForm)
      : this.paymentsService.createPlan(this.planForm);
    obs.subscribe({
      next: () => { this.savingPlan = false; this.showPlanModal = false; this.paymentsService.getPlans().subscribe(p => this.plans = p); this.showToast('Plan saved!', 'success'); },
      error: (err) => { this.savingPlan = false; this.planFormError = err.error?.detail || 'Failed to save plan.'; }
    });
  }

  deletePlan(id: number) {
    if (!confirm('Remove this plan?')) return;
    this.paymentsService.deletePlan(id).subscribe({
      next: () => { this.paymentsService.getPlans().subscribe(p => this.plans = p); this.showToast('Plan removed.', 'success'); },
      error: () => this.showToast('Failed to remove plan.', 'error')
    });
  }

  addManualPayment() {
    this.savingManual = true; this.manualError = ''; this.manualSuccess = '';
    this.paymentsService.addManualPayment(this.manualForm).subscribe({
      next: () => { this.savingManual = false; this.manualSuccess = 'Payment recorded successfully!'; this.loadAllPayments(); this.manualForm = { member_id: null, amount: 0, currency: 'USD', subscription_plan: '', notes: '' }; },
      error: (err) => { this.savingManual = false; this.manualError = err.error?.detail || 'Failed to record payment.'; }
    });
  }

  showToast(msg: string, type: string) { this.toast = msg; this.toastType = type; setTimeout(() => this.toast = '', 3000); }
}
