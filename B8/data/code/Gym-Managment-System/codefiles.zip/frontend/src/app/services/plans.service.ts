import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { WorkoutPlan, DietPlan } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PlansService {
  private apiUrl = `${environment.apiUrl}/plans`;

  constructor(private http: HttpClient) {}

  // Workout Plans
  getWorkoutPlans(): Observable<WorkoutPlan[]> {
    return this.http.get<WorkoutPlan[]>(`${this.apiUrl}/workout`);
  }

  getWorkoutPlan(id: number): Observable<WorkoutPlan> {
    return this.http.get<WorkoutPlan>(`${this.apiUrl}/workout/${id}`);
  }

  createWorkoutPlan(data: any): Observable<WorkoutPlan> {
    return this.http.post<WorkoutPlan>(`${this.apiUrl}/workout`, data);
  }

  updateWorkoutPlan(id: number, data: any): Observable<WorkoutPlan> {
    return this.http.put<WorkoutPlan>(`${this.apiUrl}/workout/${id}`, data);
  }

  deleteWorkoutPlan(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/workout/${id}`);
  }

  // Diet Plans
  getDietPlans(): Observable<DietPlan[]> {
    return this.http.get<DietPlan[]>(`${this.apiUrl}/diet`);
  }

  getDietPlan(id: number): Observable<DietPlan> {
    return this.http.get<DietPlan>(`${this.apiUrl}/diet/${id}`);
  }

  createDietPlan(data: any): Observable<DietPlan> {
    return this.http.post<DietPlan>(`${this.apiUrl}/diet`, data);
  }

  updateDietPlan(id: number, data: any): Observable<DietPlan> {
    return this.http.put<DietPlan>(`${this.apiUrl}/diet/${id}`, data);
  }

  deleteDietPlan(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/diet/${id}`);
  }

  // Member Plans
  getMemberPlans(memberId: number): Observable<{ workout_plans: WorkoutPlan[]; diet_plans: DietPlan[] }> {
    return this.http.get<any>(`${this.apiUrl}/member/${memberId}`);
  }

  // Progress
  logProgress(data: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/progress`, data);
  }

  getMemberProgress(memberId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/progress/member/${memberId}`);
  }
}
