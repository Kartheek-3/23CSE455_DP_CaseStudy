import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AttendanceService {
  private apiUrl = `${environment.apiUrl}/attendance`;

  constructor(private http: HttpClient) {}

  generateQR(classId?: number): Observable<any> {
    let params = new HttpParams();
    if (classId) params = params.set('class_id', classId);
    return this.http.get(`${this.apiUrl}/qr/generate`, { params });
  }

  scanQR(qrToken: string, classId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/qr/scan`, { qr_token: qrToken, class_id: classId });
  }

  markManual(data: { member_id: number; class_id: number; booking_id?: number }): Observable<any> {
    return this.http.post(`${this.apiUrl}/manual`, data);
  }

  getReport(filters?: {
    from_date?: string;
    to_date?: string;
    class_id?: number;
    member_id?: number;
  }): Observable<any[]> {
    let params = new HttpParams();
    if (filters) {
      Object.entries(filters).forEach(([k, v]) => {
        if (v !== undefined && v !== null) params = params.set(k, String(v));
      });
    }
    return this.http.get<any[]>(`${this.apiUrl}/report`, { params });
  }

  getStats(): Observable<any> {
    return this.http.get(`${this.apiUrl}/stats/overview`);
  }

  getMemberStreak(memberId: number): Observable<any> {
    return this.http.get(`${this.apiUrl}/member/${memberId}/streak`);
  }
}
