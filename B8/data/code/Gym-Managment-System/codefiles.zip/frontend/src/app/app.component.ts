import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <ng-container *ngIf="auth.isLoggedIn(); else publicPage">
      <div class="layout">

        <!-- Sidebar -->
        <aside class="sidebar" [class.open]="sidebarOpen">
          <div class="sidebar-brand">
            <a routerLink="/dashboard" class="brand-link">
              <span class="brand-name">GYM</span>
              <span class="brand-sub">MANAGER</span>
            </a>
            <button class="sidebar-close-btn" (click)="sidebarOpen=false">X</button>
          </div>

          <div class="sidebar-role">
            <span class="role-pill">{{ auth.getRole() | uppercase }}</span>
          </div>

          <nav class="sidebar-nav">
            <div class="nav-group">
              <span class="nav-group-label">Main</span>
              <a routerLink="/dashboard" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Dashboard
              </a>
              <a routerLink="/classes" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Classes
              </a>
              <a routerLink="/attendance" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Attendance
              </a>
              <a routerLink="/plans" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Plans
              </a>
              <a routerLink="/payments" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Payments
              </a>
            </div>

            <div class="nav-group" *ngIf="auth.isAdmin()">
              <span class="nav-group-label">Admin</span>
              <a routerLink="/members" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Members
              </a>
              <a routerLink="/trainers" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Trainers
              </a>
            </div>

            <div class="nav-group" *ngIf="auth.isTrainer()">
              <span class="nav-group-label">Trainer</span>
              <a routerLink="/members" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                My Members
              </a>
            </div>
          </nav>

          <div class="sidebar-footer">
            <button class="sidebar-logout" (click)="logout()">
              Sign Out
            </button>
          </div>
        </aside>

        <!-- Backdrop -->
        <div class="backdrop" *ngIf="sidebarOpen" (click)="sidebarOpen=false"></div>

        <!-- Main -->
        <div class="main">
          <header class="topbar">
            <button class="topbar-menu" (click)="sidebarOpen=true">
              <span></span><span></span><span></span>
            </button>
            <span class="topbar-brand">GYMMANAGER</span>
            <span class="topbar-role">{{ auth.getRole() | uppercase }}</span>
          </header>
          <div class="content">
            <router-outlet></router-outlet>
          </div>
        </div>
      </div>
    </ng-container>

    <ng-template #publicPage>
      <router-outlet></router-outlet>
    </ng-template>
  `,
  styles: [`
    .layout { display: flex; min-height: 100vh; background: #0a0a0a; }

    /* ── Sidebar ── */
    .sidebar {
      width: 220px; flex-shrink: 0;
      background: #000; border-right: 1px solid #1a1a1a;
      display: flex; flex-direction: column;
      position: fixed; top: 0; left: 0; height: 100vh; z-index: 500;
      transition: transform 0.3s ease;
    }
    .sidebar-brand {
      padding: 1.75rem 1.5rem 1.25rem;
      border-bottom: 1px solid #1a1a1a;
      display: flex; align-items: center; justify-content: space-between;
    }
    .brand-link { display: flex; flex-direction: column; line-height: 1; text-decoration: none; }
    .brand-name { font-family: 'Bebas Neue', sans-serif; font-size: 1.6rem; color: #fff; letter-spacing: 0.1em; }
    .brand-sub  { font-size: 0.6rem; font-weight: 700; letter-spacing: 0.25em; color: #555; text-transform: uppercase; }
    .sidebar-close-btn { display: none; background: none; border: none; color: #555; cursor: pointer; font-size: 1rem; font-weight: 700; }

    .sidebar-role { padding: 1rem 1.5rem; border-bottom: 1px solid #1a1a1a; }
    .role-pill { font-size: 0.65rem; font-weight: 700; letter-spacing: 0.15em; color: #777; background: #111; border: 1px solid #2a2a2a; padding: 0.3rem 0.75rem; border-radius: 2px; }

    .sidebar-nav { flex: 1; padding: 1.25rem 0; overflow-y: auto; }
    .nav-group { margin-bottom: 1.5rem; }
    .nav-group-label { display: block; padding: 0 1.5rem 0.5rem; font-size: 0.6rem; font-weight: 700; letter-spacing: 0.2em; color: #444; text-transform: uppercase; }
    .nav-link {
      display: block; padding: 0.7rem 1.5rem;
      font-size: 0.8rem; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase;
      color: #666; text-decoration: none; transition: all 0.2s;
      border-left: 2px solid transparent;
    }
    .nav-link:hover { color: #ccc; background: #111; }
    .nav-link.active { color: #fff; background: #111; border-left-color: #fff; }

    .sidebar-footer { padding: 1.5rem; border-top: 1px solid #1a1a1a; }
    .sidebar-logout {
      width: 100%; padding: 0.65rem;
      background: transparent; border: 1px solid #2a2a2a;
      color: #666; font-size: 0.75rem; font-weight: 700;
      letter-spacing: 0.1em; text-transform: uppercase;
      cursor: pointer; border-radius: 2px; transition: all 0.2s;
    }
    .sidebar-logout:hover { border-color: #fff; color: #fff; background: #111; }

    /* ── Main ── */
    .main { flex: 1; margin-left: 220px; display: flex; flex-direction: column; min-height: 100vh; }
    .backdrop { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 400; }

    /* ── Topbar (mobile) ── */
    .topbar {
      display: none; align-items: center; gap: 1rem;
      padding: 1rem 1.25rem; background: #000;
      border-bottom: 1px solid #1a1a1a; position: sticky; top: 0; z-index: 100;
    }
    .topbar-menu {
      display: flex; flex-direction: column; gap: 4px;
      background: none; border: none; cursor: pointer; padding: 4px;
    }
    .topbar-menu span { display: block; width: 22px; height: 2px; background: #fff; }
    .topbar-brand { font-family: 'Bebas Neue', sans-serif; font-size: 1.2rem; letter-spacing: 0.12em; color: #fff; }
    .topbar-role { margin-left: auto; font-size: 0.65rem; font-weight: 700; letter-spacing: 0.15em; color: #555; }

    .content { flex: 1; }

    @media (max-width: 1023px) {
      .sidebar { transform: translateX(-100%); }
      .sidebar.open { transform: translateX(0); }
      .sidebar-close-btn { display: block; }
      .backdrop { display: block; }
      .main { margin-left: 0; }
      .topbar { display: flex; }
    }
  `]
})
export class AppComponent {
  sidebarOpen = false;
  constructor(public auth: AuthService, private router: Router) {}
  logout() { this.auth.logout(); }
}
