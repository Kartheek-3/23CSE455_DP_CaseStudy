export interface User {
  id: number;
  email: string;
  full_name: string;
  phone: string;
  role: 'admin' | 'trainer' | 'member';
  is_active: boolean;
  profile_picture?: string;
  sms_opt_in?: boolean;
}

export interface AuthResponse {
  access_token: string;
  refresh_token: string;
  token_type: string;
  user_id: number;
  role: string;
}

export interface Member {
  id: number;
  user_id: number;
  full_name: string;
  email: string;
  phone: string;
  emergency_contact?: string;
  emergency_phone?: string;
  fitness_goals?: string;
  subscription_status: 'active' | 'expired' | 'cancelled' | 'pending';
  subscription_expiry?: string;
  membership_type: string;
  is_active: boolean;
  created_at?: string;
}

export interface Trainer {
  id: number;
  user_id: number;
  full_name: string;
  email: string;
  phone: string;
  specialization: string;
  bio?: string;
  hourly_rate: number;
  years_experience: number;
  rating: number;
  rating_count: number;
  is_active: boolean;
  profile_picture?: string;
}

export interface GymClass {
  id: number;
  name: string;
  description?: string;
  trainer_id: number;
  trainer_name?: string;
  max_capacity: number;
  current_enrolled: number;
  duration_minutes: number;
  start_time: string;
  end_time: string;
  class_type?: string;
  difficulty_level: string;
  location: string;
  is_recurring: boolean;
  recurring_rule?: string;
  is_active: boolean;
}

export interface Booking {
  id: number;
  class_id: number;
  member_id: number;
  status: string;
  booked_at: string;
  cancelled_at?: string;
  class_name?: string;
  class_start_time?: string;
}

export interface Attendance {
  id: number;
  member_id: number;
  class_id: number;
  marked_by: number;
  marked_at: string;
  method: string;
  member_name?: string;
  class_name?: string;
}

export interface SubscriptionPlan {
  id: number;
  name: string;
  description?: string;
  price: number;
  currency: string;
  interval: string;
  duration_days: number;
  trial_days: number;
  is_active: boolean;
}

export interface Payment {
  id: number;
  member_id: number;
  member_name?: string;
  amount: number;
  currency: string;
  status: string;
  payment_method?: string;
  gateway_txn_id?: string;
  gateway_name?: string;
  subscription_plan?: string;
  created_at: string;
  paid_at?: string;
}

export interface WorkoutPlan {
  id: number;
  trainer_id: number;
  trainer_name?: string;
  member_id?: number;
  title: string;
  description?: string;
  exercises: Exercise[];
  difficulty: string;
  duration_weeks: number;
  is_public: boolean;
  created_at: string;
}

export interface Exercise {
  name: string;
  sets?: number;
  reps?: number;
  duration_seconds?: number;
  video_url?: string;
  notes?: string;
}

export interface DietPlan {
  id: number;
  trainer_id: number;
  trainer_name?: string;
  member_id?: number;
  title: string;
  description?: string;
  meals: { [key: string]: any[] };
  total_calories: number;
  macros: { protein?: number; carbs?: number; fats?: number };
  duration_weeks: number;
  is_public: boolean;
  created_at: string;
}

export interface Notification {
  id: number;
  user_id: number;
  type: string;
  channel: string;
  subject?: string;
  content: string;
  status: string;
  sent_at?: string;
  created_at: string;
}
