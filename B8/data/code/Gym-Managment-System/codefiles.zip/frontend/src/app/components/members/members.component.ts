import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MembersService } from '../../services/members.service';
import { AuthService } from '../../services/auth.service';
import { Member } from '../../models/user.model';

@Component({
  selector: 'app-members',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <div>
          <h1>Members</h1>
          <p>Manage gym members and subscriptions</p>
        </div>
        <button class="btn btn-primary" (click)="openModal()">+ Add Member</button>
      </div>

      <!-- Search & Filter -->
      <div class="filters-bar">
        <input type="text" [(ngModel)]="search" (input)="onSearch()" placeholder="Search by name or email..." class="search-input" />
        <select [(ngModel)]="statusFilter" (change)="loadMembers()" class="filter-select">
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="expired">Expired</option>
          <option value="pending">Pending</option>
        </select>
      </div>

      <!-- Stats -->
      <div class="stats-row" *ngIf="stats">
        <div class="mini-stat">
          <span class="mini-val">{{ stats.total }}</span>
          <span class="mini-label">Total</span>
        </div>
        <div class="mini-stat green">
          <span class="mini-val">{{ stats.active }}</span>
          <span class="mini-label">Active</span>
        </div>
        <div class="mini-stat orange">
          <span class="mini-val">{{ stats.expired }}</span>
          <span class="mini-label">Expired</span>
        </div>
        <div class="mini-stat gray">
          <span class="mini-val">{{ stats.pending }}</span>
          <span class="mini-label">Pending</span>
        </div>
      </div>

      <div class="loading" *ngIf="loading">Loading members...</div>

      <div class="table-wrapper" *ngIf="!loading">
        <table class="data-table">
          <thead>
            <tr>
              <th>Member</th>
              <th>Phone</th>
              <th>Status</th>
              <th>Membership</th>
              <th>Expiry</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let m of members">
              <td>
                <div class="member-cell">
                  <div class="avatar">{{ m.full_name[0] }}</div>
                  <div>
                    <div class="member-name">{{ m.full_name }}</div>
                    <div class="member-email">{{ m.email }}</div>
                  </div>
                </div>
              </td>
              <td>{{ m.phone }}</td>
              <td>
                <span class="status-badge" [ngClass]="m.subscription_status">
                  {{ m.subscription_status | titlecase }}
                </span>
              </td>
              <td>{{ m.membership_type | titlecase }}</td>
              <td>{{ m.subscription_expiry ? (m.subscription_expiry | date:'MMM d, yyyy') : '—' }}</td>
              <td>
                <div class="action-btns">
                  <button class="btn-icon" title="Edit" (click)="editMember(m)">Edit</button>
                  <button class="btn-icon btn-icon-del" title="Delete" (click)="deleteMember(m.id)">Remove</button>
                </div>
              </td>
            </tr>
            <tr *ngIf="members.length === 0">
              <td colspan="6" class="empty">No members found.</td>
            </tr>
          </tbody>
        </table>
      </div>

      <!-- Modal -->
      <div class="modal-overlay" *ngIf="showModal" (click)="closeModal()">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>{{ editingMember ? 'Edit Member' : 'Add New Member' }}</h2>
            <button class="modal-close" (click)="closeModal()">✕</button>
          </div>
          <div class="modal-body">
            <ng-container *ngIf="!editingMember">
              <div class="form-row">
                <div class="form-group">
                  <label>Full Name *</label>
                  <input type="text" [(ngModel)]="form.full_name" class="form-control" />
                </div>
                <div class="form-group">
                  <label>Email *</label>
                  <input type="email" [(ngModel)]="form.email" class="form-control" />
                </div>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>Phone *</label>
                  <input type="tel" [(ngModel)]="form.phone" class="form-control" />
                </div>
                <div class="form-group">
                  <label>Password *</label>
                  <input type="password" [(ngModel)]="form.password" class="form-control" />
                </div>
              </div>
            </ng-container>
            <ng-container *ngIf="editingMember">
              <div class="form-row">
                <div class="form-group">
                  <label>Full Name</label>
                  <input type="text" [(ngModel)]="form.full_name" class="form-control" />
                </div>
                <div class="form-group">
                  <label>Phone</label>
                  <input type="tel" [(ngModel)]="form.phone" class="form-control" />
                </div>
              </div>
            </ng-container>
            <div class="form-row">
              <div class="form-group">
                <label>Emergency Contact</label>
                <input type="text" [(ngModel)]="form.emergency_contact" class="form-control" />
              </div>
              <div class="form-group">
                <label>Emergency Phone</label>
                <input type="tel" [(ngModel)]="form.emergency_phone" class="form-control" />
              </div>
            </div>
            <div class="form-group">
              <label>Fitness Goals</label>
              <textarea [(ngModel)]="form.fitness_goals" class="form-control" rows="2"></textarea>
            </div>
            <div class="alert alert-error" *ngIf="formError">{{ formError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="closeModal()">Cancel</button>
            <button class="btn btn-primary" (click)="saveMember()" [disabled]="saving">
              {{ saving ? 'Saving...' : (editingMember ? 'Update' : 'Add Member') }}
            </button>
          </div>
        </div>
      </div>

      <div class="toast" *ngIf="toast" [ngClass]="toastType">{{ toast }}</div>
    </div>
  `,
  styles: [`
    .page-container { padding: 2rem; max-width: 1280px; margin: 0 auto; background: #0a0a0a; min-height: 100vh; }
    .page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
    .page-header h1 { font-family: 'Bebas Neue', sans-serif; font-size: 2.5rem; letter-spacing: 0.05em; color: #fff; margin: 0; line-height: 1; }
    .page-header p { color: #666; margin-top: 0.4rem; font-size: 0.875rem; }
    .filters-bar { display: flex; gap: 0.75rem; margin-bottom: 1rem; flex-wrap: wrap; }
    .search-input { flex: 1; min-width: 200px; padding: 0.65rem 1rem; background: #111; border: 1px solid #2a2a2a; border-radius: 2px; color: #fff; font-size: 0.875rem; }
    .search-input:focus { outline: none; border-color: #fff; }
    .search-input::placeholder { color: #444; }
    .filter-select { padding: 0.65rem 0.875rem; background: #111; border: 1px solid #2a2a2a; border-radius: 2px; color: #ccc; font-size: 0.875rem; }
    .filter-select:focus { outline: none; border-color: #fff; }
    .stats-row { display: flex; gap: 1px; margin-bottom: 1.5rem; background: #1a1a1a; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; flex-wrap: wrap; }
    .mini-stat { background: #0f0f0f; padding: 1.25rem 1.75rem; display: flex; flex-direction: column; align-items: center; min-width: 100px; flex: 1; }
    .mini-stat.green .mini-val { color: #68d391; }
    .mini-stat.orange .mini-val { color: #f6e05e; }
    .mini-stat.gray .mini-val { color: #777; }
    .mini-val { font-family: 'Bebas Neue', sans-serif; font-size: 2rem; color: #fff; line-height: 1; }
    .mini-label { font-size: 0.65rem; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; color: #555; margin-top: 0.3rem; }
    .loading { text-align: center; padding: 4rem; color: #444; font-size: 0.8rem; letter-spacing: 0.1em; text-transform: uppercase; }
    .table-wrapper { background: #0f0f0f; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; overflow-x: auto; }
    .data-table { width: 100%; border-collapse: collapse; min-width: 600px; }
    .data-table th { background: #111; padding: 0.875rem 1rem; text-align: left; font-size: 0.65rem; font-weight: 700; color: #555; text-transform: uppercase; letter-spacing: 0.12em; border-bottom: 1px solid #1a1a1a; }
    .data-table td { padding: 1rem; border-bottom: 1px solid #161616; font-size: 0.875rem; color: #ccc; }
    .data-table tr:last-child td { border-bottom: none; }
    .data-table tr:hover td { background: #141414; }
    .member-cell { display: flex; align-items: center; gap: 0.875rem; }
    .avatar { width: 36px; height: 36px; border-radius: 2px; background: #1a1a1a; border: 1px solid #2a2a2a; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.9rem; flex-shrink: 0; font-family: 'Bebas Neue', sans-serif; }
    .member-name { font-weight: 600; color: #fff; font-size: 0.875rem; }
    .member-email { font-size: 0.75rem; color: #555; }
    .status-badge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 2px; font-size: 0.65rem; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; }
    .status-badge.active { background: rgba(56,161,105,0.15); color: #68d391; border: 1px solid rgba(56,161,105,0.3); }
    .status-badge.expired { background: rgba(229,62,62,0.1); color: #fc8181; border: 1px solid rgba(229,62,62,0.3); }
    .status-badge.pending { background: rgba(236,201,75,0.1); color: #f6e05e; border: 1px solid rgba(236,201,75,0.3); }
    .status-badge.cancelled { background: #111; color: #555; border: 1px solid #2a2a2a; }
    .action-btns { display: flex; gap: 0.4rem; }
    .btn-icon { background: none; border: 1px solid #1a1a1a; color: #555; cursor: pointer; padding: 0.3rem 0.65rem; border-radius: 2px; font-size: 0.7rem; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; transition: all 0.2s; }
    .btn-icon:hover { border-color: #fff; color: #fff; background: #1a1a1a; }
    .btn-icon-del:hover { border-color: #fc8181; color: #fc8181; }
    .empty { text-align: center; color: #444; padding: 3rem; font-size: 0.8rem; letter-spacing: 0.08em; text-transform: uppercase; }
    .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.65rem 1.5rem; border-radius: 2px; border: none; cursor: pointer; font-weight: 700; font-size: 0.75rem; letter-spacing: 0.08em; text-transform: uppercase; transition: all 0.2s; }
    .btn-primary { background: #fff; color: #000; }
    .btn-primary:hover:not(:disabled) { background: #e0e0e0; }
    .btn-primary:disabled { opacity: 0.4; cursor: not-allowed; }
    .btn-outline { background: transparent; border: 1px solid #2a2a2a; color: #888; }
    .btn-outline:hover { border-color: #fff; color: #fff; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.88); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 1rem; }
    .modal { background: #111; border: 1px solid #2a2a2a; border-radius: 4px; width: 100%; max-width: 520px; max-height: 90vh; overflow-y: auto; }
    .modal-header { display: flex; justify-content: space-between; align-items: center; padding: 1.5rem; border-bottom: 1px solid #1a1a1a; }
    .modal-header h2 { font-family: 'Bebas Neue', sans-serif; font-size: 1.4rem; letter-spacing: 0.06em; color: #fff; margin: 0; }
    .modal-close { background: none; border: none; color: #555; cursor: pointer; font-size: 1.1rem; }
    .modal-close:hover { color: #fff; }
    .modal-body { padding: 1.5rem; }
    .modal-footer { padding: 1rem 1.5rem; border-top: 1px solid #1a1a1a; display: flex; justify-content: flex-end; gap: 0.75rem; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .form-group { margin-bottom: 1rem; }
    .form-group label { display: block; font-size: 0.7rem; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; color: #666; margin-bottom: 0.4rem; }
    .form-control { width: 100%; padding: 0.75rem 0.875rem; background: #0a0a0a; border: 1px solid #2a2a2a; border-radius: 2px; color: #fff; font-size: 0.9rem; box-sizing: border-box; }
    .form-control:focus { outline: none; border-color: #fff; }
    textarea.form-control { resize: vertical; }
    .alert { padding: 0.75rem 1rem; border-radius: 2px; margin-bottom: 1rem; font-size: 0.85rem; }
    .alert-error { background: rgba(229,62,62,0.1); color: #fc8181; border: 1px solid rgba(229,62,62,0.3); }
    .toast { position: fixed; bottom: 2rem; right: 2rem; padding: 0.875rem 1.5rem; border-radius: 2px; font-weight: 700; font-size: 0.8rem; letter-spacing: 0.06em; z-index: 2000; }
    .toast.success { background: #111; color: #68d391; border: 1px solid rgba(56,161,105,0.4); }
    .toast.error   { background: #111; color: #fc8181; border: 1px solid rgba(229,62,62,0.4); }
    @media (max-width: 640px) { .form-row { grid-template-columns: 1fr; } }
  `]
})
export class MembersComponent implements OnInit {
  members: Member[] = [];
  stats: any = null;
  loading = false;
  showModal = false;
  editingMember: Member | null = null;
  saving = false;
  formError = '';
  toast = '';
  toastType = 'success';
  search = '';
  statusFilter = '';
  searchTimeout: any;

  form: any = { full_name: '', email: '', phone: '', password: '', emergency_contact: '', emergency_phone: '', fitness_goals: '' };

  constructor(public auth: AuthService, private membersService: MembersService) {}

  ngOnInit() { this.loadMembers(); this.membersService.getStats().subscribe(s => this.stats = s); }

  loadMembers() {
    this.loading = true;
    this.membersService.getAll(this.search, this.statusFilter).subscribe({
      next: m => { this.members = m; this.loading = false; },
      error: () => this.loading = false
    });
  }

  onSearch() {
    clearTimeout(this.searchTimeout);
    this.searchTimeout = setTimeout(() => this.loadMembers(), 400);
  }

  openModal() {
    this.editingMember = null;
    this.form = { full_name: '', email: '', phone: '', password: '', emergency_contact: '', emergency_phone: '', fitness_goals: '' };
    this.formError = '';
    this.showModal = true;
  }

  editMember(m: Member) {
    this.editingMember = m;
    this.form = { full_name: m.full_name, phone: m.phone, emergency_contact: m.emergency_contact || '', emergency_phone: m.emergency_phone || '', fitness_goals: m.fitness_goals || '' };
    this.formError = '';
    this.showModal = true;
  }

  closeModal() { this.showModal = false; }

  saveMember() {
    this.saving = true;
    this.formError = '';
    const obs = this.editingMember
      ? this.membersService.update(this.editingMember.id, this.form)
      : this.membersService.create(this.form);
    obs.subscribe({
      next: () => { this.saving = false; this.showToast(this.editingMember ? 'Member updated!' : 'Member added!', 'success'); this.closeModal(); this.loadMembers(); },
      error: (err) => { this.saving = false; this.formError = err.error?.detail || 'Failed to save.'; }
    });
  }

  deleteMember(id: number) {
    if (!confirm('Deactivate this member?')) return;
    this.membersService.delete(id).subscribe({
      next: () => { this.showToast('Member deactivated.', 'success'); this.loadMembers(); },
      error: () => this.showToast('Failed to deactivate.', 'error')
    });
  }

  showToast(msg: string, type: string) { this.toast = msg; this.toastType = type; setTimeout(() => this.toast = '', 3000); }
}
