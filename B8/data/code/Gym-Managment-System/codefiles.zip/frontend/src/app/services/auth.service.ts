import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { AuthResponse, User } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private apiUrl = environment.apiUrl;
  private currentUserSubject = new BehaviorSubject<User | null>(this.loadUser());
  currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient, private router: Router) {}

  private loadUser(): User | null {
    const stored = localStorage.getItem('gym_user');
    return stored ? JSON.parse(stored) : null;
  }

  login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/auth/login`, { email, password }).pipe(
      tap(res => this.handleAuthResponse(res))
    );
  }

  signup(data: any): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiUrl}/auth/signup`, data).pipe(
      tap(res => this.handleAuthResponse(res))
    );
  }

  private handleAuthResponse(res: AuthResponse): void {
    localStorage.setItem('gym_token', res.access_token);
    localStorage.setItem('gym_refresh_token', res.refresh_token);
    const user: User = {
      id: res.user_id,
      role: res.role as any,
      email: '',
      full_name: '',
      phone: '',
      is_active: true,
    };
    localStorage.setItem('gym_user', JSON.stringify(user));
    this.currentUserSubject.next(user);
  }

  logout(): void {
    localStorage.removeItem('gym_token');
    localStorage.removeItem('gym_refresh_token');
    localStorage.removeItem('gym_user');
    this.currentUserSubject.next(null);
    this.router.navigate(['/login']);
  }

  getToken(): string | null {
    return localStorage.getItem('gym_token');
  }

  isLoggedIn(): boolean {
    return !!this.getToken();
  }

  getRole(): string {
    const user = this.currentUserSubject.value;
    return user?.role || '';
  }

  getUserId(): number {
    const user = this.currentUserSubject.value;
    return user?.id || 0;
  }

  isAdmin(): boolean { return this.getRole() === 'admin'; }
  isTrainer(): boolean { return this.getRole() === 'trainer'; }
  isMember(): boolean { return this.getRole() === 'member'; }

  forgotPassword(email: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/auth/forgot-password`, { email });
  }

  refreshToken(): Observable<any> {
    const refresh = localStorage.getItem('gym_refresh_token');
    return this.http.post(`${this.apiUrl}/auth/refresh`, { refresh_token: refresh }).pipe(
      tap((res: any) => {
        if (res.access_token) {
          localStorage.setItem('gym_token', res.access_token);
        }
      })
    );
  }
}
