import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="auth-page">
      <!-- Left: Hero -->
      <div class="auth-hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
          <h1 class="hero-title">PUSH<br>YOUR<br>LIMITS</h1>
          <p class="hero-sub">Your fitness journey starts here. Track progress, book classes, achieve goals.</p>
        </div>
        <div class="hero-badge">EST. 2024</div>
      </div>

      <!-- Right: Form -->
      <div class="auth-panel">
        <div class="auth-form-wrap">
          <div class="auth-brand">
            <span class="brand-name">GYM</span><span class="brand-sub">MANAGER</span>
          </div>

          <h2 class="auth-title">Sign In</h2>
          <p class="auth-desc">Access your account to continue your training.</p>

          <form (ngSubmit)="onLogin()">
            <div class="form-group">
              <label>Email Address</label>
              <input type="email" [(ngModel)]="email" name="email" required
                     class="form-control" placeholder="you@example.com" />
            </div>
            <div class="form-group">
              <label>Password</label>
              <div class="pw-wrap">
                <input [type]="showPw ? 'text' : 'password'"
                       [(ngModel)]="password" name="password" required
                       class="form-control" placeholder="••••••••" />
                <button type="button" class="pw-toggle" (click)="showPw=!showPw">
                  {{ showPw ? 'HIDE' : 'SHOW' }}
                </button>
              </div>
            </div>

            <div class="form-row-end">
              <a routerLink="/forgot-password" class="forgot-link">Forgot password?</a>
            </div>

            <div class="alert alert-error" *ngIf="error">{{ error }}</div>

            <button type="submit" class="btn btn-white btn-full" [disabled]="loading">
              <span class="spinner" *ngIf="loading"></span>
              {{ loading ? 'SIGNING IN...' : 'SIGN IN' }}
            </button>
          </form>

          <div class="auth-divider"><span>OR TRY DEMO</span></div>

          <div class="demo-btns">
            <button class="demo-btn" (click)="fillDemo('admin')">ADMIN</button>
            <button class="demo-btn" (click)="fillDemo('trainer')">TRAINER</button>
            <button class="demo-btn" (click)="fillDemo('member')">MEMBER</button>
          </div>

          <p class="auth-switch">New member? <a routerLink="/signup">Create account</a></p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-page { display: flex; min-height: 100vh; background: #000; }

    /* Hero */
    .auth-hero {
      flex: 1; position: relative; overflow: hidden;
      background-image: url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&q=80');
      background-size: cover; background-position: center;
      display: flex; flex-direction: column; justify-content: flex-end; padding: 3rem;
    }
    .hero-overlay {
      position: absolute; inset: 0;
      background: linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.3) 60%, rgba(0,0,0,0.1) 100%);
    }
    .hero-content { position: relative; z-index: 1; }
    .hero-title {
      font-family: 'Bebas Neue', sans-serif; font-size: clamp(4rem, 8vw, 7rem);
      line-height: 0.9; letter-spacing: 0.02em; color: #fff;
      text-shadow: 0 4px 32px rgba(0,0,0,0.5);
    }
    .hero-sub { color: #aaa; font-size: 0.95rem; margin-top: 1rem; max-width: 380px; line-height: 1.6; }
    .hero-badge {
      position: absolute; top: 2rem; right: 2rem;
      font-size: 0.65rem; font-weight: 700; letter-spacing: 0.2em;
      color: #555; border: 1px solid #333; padding: 0.4rem 0.75rem;
      border-radius: 2px; z-index: 1;
    }

    /* Panel */
    .auth-panel {
      width: 460px; flex-shrink: 0; background: #0a0a0a;
      border-left: 1px solid #1a1a1a;
      display: flex; align-items: center; justify-content: center;
      padding: 2rem;
    }
    .auth-form-wrap { width: 100%; max-width: 360px; }

    .auth-brand { display: flex; align-items: baseline; gap: 0.2rem; margin-bottom: 2.5rem; }
    .brand-name { font-family: 'Bebas Neue', sans-serif; font-size: 1.8rem; color: #fff; letter-spacing: 0.1em; }
    .brand-sub  { font-size: 0.65rem; font-weight: 700; letter-spacing: 0.25em; color: #444; text-transform: uppercase; }

    .auth-title { font-family: 'Bebas Neue', sans-serif; font-size: 2rem; letter-spacing: 0.05em; color: #fff; margin-bottom: 0.4rem; }
    .auth-desc  { color: #666; font-size: 0.875rem; margin-bottom: 2rem; }

    .pw-wrap    { position: relative; }
    .pw-toggle  {
      position: absolute; right: 0.875rem; top: 50%; transform: translateY(-50%);
      background: none; border: none; color: #555; cursor: pointer;
      font-size: 0.65rem; font-weight: 700; letter-spacing: 0.1em;
    }
    .pw-toggle:hover { color: #fff; }

    .form-row-end { display: flex; justify-content: flex-end; margin-bottom: 1.25rem; margin-top: -0.5rem; }
    .forgot-link { font-size: 0.75rem; color: #555; text-decoration: none; letter-spacing: 0.05em; }
    .forgot-link:hover { color: #fff; }

    .auth-divider { display: flex; align-items: center; gap: 0.75rem; margin: 1.5rem 0; }
    .auth-divider::before, .auth-divider::after { content: ''; flex: 1; height: 1px; background: #1a1a1a; }
    .auth-divider span { font-size: 0.65rem; font-weight: 700; letter-spacing: 0.15em; color: #444; }

    .demo-btns { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; }
    .demo-btn  {
      flex: 1; padding: 0.6rem; background: transparent;
      border: 1px solid #2a2a2a; color: #555;
      font-size: 0.7rem; font-weight: 700; letter-spacing: 0.1em;
      cursor: pointer; border-radius: 2px; transition: all 0.2s;
    }
    .demo-btn:hover { border-color: #fff; color: #fff; background: #111; }

    .auth-switch { text-align: center; font-size: 0.8rem; color: #555; }
    .auth-switch a { color: #999; font-weight: 600; }
    .auth-switch a:hover { color: #fff; }

    @media (max-width: 900px) {
      .auth-hero { display: none; }
      .auth-panel { width: 100%; border-left: none; }
    }
  `]
})
export class LoginComponent {
  email = ''; password = ''; loading = false; error = ''; showPw = false;

  constructor(private auth: AuthService, private router: Router) {}

  fillDemo(role: string) {
    const c: any = { admin: ['admin@gym.com','admin123'], trainer: ['trainer@gym.com','trainer123'], member: ['member@gym.com','member123'] };
    [this.email, this.password] = c[role];
  }

  onLogin() {
    if (!this.email || !this.password) { this.error = 'Please enter your email and password.'; return; }
    this.loading = true; this.error = '';
    this.auth.login(this.email, this.password).subscribe({
      next: () => { this.loading = false; this.router.navigate(['/dashboard']); },
      error: (err) => { this.loading = false; this.error = err.error?.detail || 'Invalid credentials.'; }
    });
  }
}
