import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ClassesService } from '../../services/classes.service';
import { TrainersService } from '../../services/trainers.service';
import { AuthService } from '../../services/auth.service';
import { GymClass, Trainer } from '../../models/user.model';

@Component({
  selector: 'app-classes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="pg">
      <div class="pg-head">
        <div>
          <h1 class="pg-title">{{ auth.isAdmin() || auth.isTrainer() ? 'MANAGE CLASSES' : 'BROWSE CLASSES' }}</h1>
          <p class="pg-sub">{{ auth.isMember() ? 'Find and book your next class' : 'Schedule and manage fitness classes' }}</p>
        </div>
        <button class="btn-w" *ngIf="auth.isAdmin() || auth.isTrainer()" (click)="openModal()">
          NEW CLASS
        </button>
      </div>

      <!-- Filters -->
      <div class="filters">
        <select [(ngModel)]="filters.class_type" (change)="loadClasses()" class="fsel">
          <option value="">ALL TYPES</option>
          <option *ngFor="let t of classTypes" [value]="t">{{ t | uppercase }}</option>
        </select>
        <select [(ngModel)]="filters.difficulty" (change)="loadClasses()" class="fsel">
          <option value="">ALL LEVELS</option>
          <option value="Beginner">BEGINNER</option>
          <option value="Intermediate">INTERMEDIATE</option>
          <option value="Advanced">ADVANCED</option>
        </select>
        <select [(ngModel)]="filters.trainer_id" (change)="loadClasses()" class="fsel">
          <option value="">ALL TRAINERS</option>
          <option *ngFor="let t of trainers" [value]="t.id">{{ t.full_name | uppercase }}</option>
        </select>
        <label class="fcheck" *ngIf="auth.isMember()">
          <input type="checkbox" [(ngModel)]="filters.available_only" (change)="loadClasses()" />
          AVAILABLE ONLY
        </label>
      </div>

      <div class="loading-msg" *ngIf="loading">LOADING...</div>

      <!-- Classes Grid -->
      <div class="grid" *ngIf="!loading">
        <div class="card" *ngFor="let cls of classes">
          <div class="card-top">
            <span class="type-tag">{{ cls.class_type || 'GENERAL' }}</span>
            <span class="diff-tag" [ngClass]="getDifficultyClass(cls.difficulty_level)">
              {{ cls.difficulty_level | uppercase }}
            </span>
          </div>
          <h3 class="card-name">{{ cls.name | uppercase }}</h3>
          <p class="card-desc" *ngIf="cls.description">{{ cls.description }}</p>

          <div class="card-meta">
            <div class="meta-row">
              <span class="meta-key">DATE</span>
              <span class="meta-val">{{ cls.start_time | date:'EEE, MMM d · h:mm a' }}</span>
            </div>
            <div class="meta-row">
              <span class="meta-key">DURATION</span>
              <span class="meta-val">{{ cls.duration_minutes }} min</span>
            </div>
            <div class="meta-row">
              <span class="meta-key">LOCATION</span>
              <span class="meta-val">{{ cls.location }}</span>
            </div>
            <div class="meta-row">
              <span class="meta-key">TRAINER</span>
              <span class="meta-val">{{ cls.trainer_name }}</span>
            </div>
          </div>

          <div class="cap-wrap">
            <div class="cap-bar">
              <div class="cap-fill"
                   [style.width.%]="(cls.current_enrolled / cls.max_capacity) * 100"
                   [ngClass]="cls.current_enrolled >= cls.max_capacity ? 'cap-full' : ''"></div>
            </div>
            <span class="cap-txt">{{ cls.current_enrolled }}/{{ cls.max_capacity }} enrolled</span>
          </div>

          <div class="card-actions">
            <ng-container *ngIf="auth.isMember()">
              <button class="btn-w btn-full" (click)="bookClass(cls)"
                      [disabled]="cls.current_enrolled >= cls.max_capacity">
                {{ cls.current_enrolled >= cls.max_capacity ? 'JOIN WAITLIST' : 'BOOK NOW' }}
              </button>
            </ng-container>
            <ng-container *ngIf="auth.isAdmin() || auth.isTrainer()">
              <button class="btn-ghost btn-sm" (click)="editClass(cls)">EDIT</button>
              <button class="btn-red btn-sm" (click)="deleteClass(cls.id)">CANCEL</button>
            </ng-container>
          </div>
        </div>

        <div class="no-results" *ngIf="classes.length === 0">
          <p>NO CLASSES FOUND</p>
          <span>Try adjusting your filters</span>
        </div>
      </div>

      <!-- Modal -->
      <div class="overlay" *ngIf="showModal" (click)="closeModal()">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-hd">
            <h2>{{ editingClass ? 'EDIT CLASS' : 'NEW CLASS' }}</h2>
            <button class="x-btn" (click)="closeModal()">&#215;</button>
          </div>
          <div class="modal-bd">
            <div class="f2">
              <div class="fg"><label>CLASS NAME *</label>
                <input type="text" [(ngModel)]="form.name" class="fi" placeholder="e.g. Morning Yoga" /></div>
              <div class="fg"><label>TYPE</label>
                <select [(ngModel)]="form.class_type" class="fi">
                  <option *ngFor="let t of classTypes" [value]="t">{{ t }}</option>
                </select></div>
            </div>
            <div class="fg"><label>DESCRIPTION</label>
              <textarea [(ngModel)]="form.description" class="fi" rows="2"></textarea></div>
            <div class="f2">
              <div class="fg"><label>TRAINER *</label>
                <select [(ngModel)]="form.trainer_id" class="fi">
                  <option *ngFor="let t of trainers" [value]="t.id">{{ t.full_name }}</option>
                </select></div>
              <div class="fg"><label>DIFFICULTY</label>
                <select [(ngModel)]="form.difficulty_level" class="fi">
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select></div>
            </div>
            <div class="f2">
              <div class="fg"><label>START TIME *</label>
                <input type="datetime-local" [(ngModel)]="form.start_time" class="fi" /></div>
              <div class="fg"><label>END TIME *</label>
                <input type="datetime-local" [(ngModel)]="form.end_time" class="fi" /></div>
            </div>
            <div class="f2">
              <div class="fg"><label>MAX CAPACITY</label>
                <input type="number" [(ngModel)]="form.max_capacity" class="fi" min="1" /></div>
              <div class="fg"><label>DURATION (MIN)</label>
                <input type="number" [(ngModel)]="form.duration_minutes" class="fi" min="15" /></div>
            </div>
            <div class="fg"><label>LOCATION</label>
              <input type="text" [(ngModel)]="form.location" class="fi" placeholder="Main Studio" /></div>
            <div class="err" *ngIf="formError">{{ formError }}</div>
            <div class="ok"  *ngIf="formSuccess">{{ formSuccess }}</div>
          </div>
          <div class="modal-ft">
            <button class="btn-ghost" (click)="closeModal()">CANCEL</button>
            <button class="btn-w" (click)="saveClass()" [disabled]="saving">
              <span class="spin" *ngIf="saving"></span>
              {{ saving ? 'SAVING...' : (editingClass ? 'UPDATE' : 'CREATE') }}
            </button>
          </div>
        </div>
      </div>

      <div class="toast" *ngIf="toast" [ngClass]="toastType">{{ toast }}</div>
    </div>
  `,
  styles: [`
    /* Page shell */
    .pg    { padding: 2rem; max-width: 1280px; margin: 0 auto; min-height: 100vh; }
    .pg-head { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
    .pg-title { font-family: 'Bebas Neue', sans-serif; font-size: 2.5rem; letter-spacing: 0.05em; color: #fff; margin: 0; line-height: 1; }
    .pg-sub   { color: #555; margin-top: 0.4rem; font-size: 0.875rem; }

    /* Buttons */
    .btn-w    { display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem; padding: 0.7rem 1.75rem; background: #fff; color: #000; border: none; border-radius: 2px; font-weight: 800; font-size: 0.75rem; letter-spacing: 0.1em; text-transform: uppercase; cursor: pointer; transition: background 0.2s; }
    .btn-w:hover:not(:disabled) { background: #e0e0e0; }
    .btn-w:disabled { opacity: 0.4; cursor: not-allowed; }
    .btn-full  { width: 100%; }
    .btn-ghost { display: inline-flex; align-items: center; justify-content: center; padding: 0.6rem 1.25rem; background: transparent; border: 1px solid #333; color: #888; border-radius: 2px; font-weight: 700; font-size: 0.72rem; letter-spacing: 0.1em; cursor: pointer; transition: all 0.2s; }
    .btn-ghost:hover { border-color: #fff; color: #fff; }
    .btn-red   { display: inline-flex; align-items: center; justify-content: center; padding: 0.6rem 1.25rem; background: transparent; border: 1px solid rgba(229,62,62,0.4); color: #fc8181; border-radius: 2px; font-weight: 700; font-size: 0.72rem; letter-spacing: 0.1em; cursor: pointer; transition: all 0.2s; }
    .btn-red:hover { background: rgba(229,62,62,0.1); border-color: #fc8181; }
    .btn-sm   { padding: 0.45rem 0.875rem; font-size: 0.68rem; }

    /* Filters */
    .filters  { display: flex; gap: 0.75rem; margin-bottom: 2rem; flex-wrap: wrap; align-items: center; }
    .fsel     { padding: 0.6rem 0.875rem; background: #111; border: 1px solid #2a2a2a; border-radius: 2px; color: #888; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.08em; cursor: pointer; transition: border-color 0.2s; }
    .fsel:focus { outline: none; border-color: #fff; color: #fff; }
    .fsel option { background: #111; }
    .fcheck   { display: flex; align-items: center; gap: 0.5rem; font-size: 0.72rem; font-weight: 700; letter-spacing: 0.1em; color: #555; cursor: pointer; }
    .fcheck:hover { color: #fff; }
    .fcheck input { accent-color: #fff; width: 14px; height: 14px; }

    .loading-msg { text-align: center; padding: 4rem; color: #333; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.2em; }

    /* Grid */
    .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1px; background: #1a1a1a; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; }

    /* Card — ALL DARK, no white */
    .card { background: #0f0f0f; padding: 1.5rem; display: flex; flex-direction: column; gap: 1rem; transition: background 0.2s; }
    .card:hover { background: #141414; }
    .card-top  { display: flex; justify-content: space-between; align-items: center; }
    .type-tag  { font-size: 0.65rem; font-weight: 800; letter-spacing: 0.15em; text-transform: uppercase; color: #666; background: #161616; border: 1px solid #2a2a2a; padding: 0.25rem 0.65rem; border-radius: 2px; }
    .diff-tag  { font-size: 0.65rem; font-weight: 800; letter-spacing: 0.12em; text-transform: uppercase; padding: 0.25rem 0.65rem; border-radius: 2px; }
    .diff-tag.beginner     { color: #68d391; background: rgba(56,161,105,0.1); border: 1px solid rgba(56,161,105,0.25); }
    .diff-tag.intermediate { color: #f6e05e; background: rgba(236,201,75,0.08); border: 1px solid rgba(236,201,75,0.25); }
    .diff-tag.advanced     { color: #fc8181; background: rgba(229,62,62,0.08); border: 1px solid rgba(229,62,62,0.25); }
    .card-name { font-family: 'Bebas Neue', sans-serif; font-size: 1.4rem; letter-spacing: 0.05em; color: #fff; margin: 0; line-height: 1.1; }
    .card-desc { font-size: 0.8rem; color: #555; line-height: 1.6; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }

    /* Meta table style — clean and professional */
    .card-meta { display: flex; flex-direction: column; gap: 0; border-top: 1px solid #1a1a1a; border-bottom: 1px solid #1a1a1a; }
    .meta-row  { display: flex; justify-content: space-between; align-items: center; padding: 0.45rem 0; border-bottom: 1px solid #161616; }
    .meta-row:last-child { border-bottom: none; }
    .meta-key  { font-size: 0.62rem; font-weight: 800; letter-spacing: 0.14em; color: #444; text-transform: uppercase; }
    .meta-val  { font-size: 0.78rem; color: #ccc; text-align: right; }

    /* Capacity */
    .cap-wrap  { display: flex; align-items: center; gap: 0.75rem; }
    .cap-bar   { flex: 1; height: 2px; background: #1a1a1a; border-radius: 1px; }
    .cap-fill  { height: 100%; background: #fff; border-radius: 1px; transition: width 0.4s; }
    .cap-fill.cap-full { background: #fc8181; }
    .cap-txt   { font-size: 0.7rem; color: #555; white-space: nowrap; letter-spacing: 0.04em; }

    .card-actions { display: flex; gap: 0.5rem; padding-top: 0.25rem; }

    /* Empty state */
    .no-results { grid-column: 1/-1; text-align: center; padding: 5rem 2rem; }
    .no-results p    { font-family: 'Bebas Neue', sans-serif; font-size: 1.5rem; letter-spacing: 0.1em; color: #333; margin: 0 0 0.5rem; }
    .no-results span { font-size: 0.8rem; color: #333; }

    /* Modal */
    .overlay   { position: fixed; inset: 0; background: rgba(0,0,0,0.9); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 1rem; }
    .modal     { background: #111; border: 1px solid #2a2a2a; border-radius: 4px; width: 100%; max-width: 560px; max-height: 90vh; overflow-y: auto; }
    .modal-hd  { display: flex; justify-content: space-between; align-items: center; padding: 1.5rem; border-bottom: 1px solid #1a1a1a; }
    .modal-hd h2 { font-family: 'Bebas Neue', sans-serif; font-size: 1.4rem; letter-spacing: 0.06em; color: #fff; margin: 0; }
    .x-btn     { background: none; border: none; color: #444; cursor: pointer; font-size: 1.4rem; line-height: 1; transition: color 0.2s; }
    .x-btn:hover { color: #fff; }
    .modal-bd  { padding: 1.5rem; }
    .modal-ft  { padding: 1rem 1.5rem; border-top: 1px solid #1a1a1a; display: flex; justify-content: flex-end; gap: 0.75rem; }

    /* Form elements inside modal */
    .f2  { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 0; }
    .fg  { margin-bottom: 1rem; }
    .fg label { display: block; font-size: 0.65rem; font-weight: 800; letter-spacing: 0.14em; color: #555; margin-bottom: 0.4rem; }
    .fi  { width: 100%; padding: 0.75rem 0.875rem; background: #0a0a0a; border: 1px solid #2a2a2a; border-radius: 2px; color: #fff; font-size: 0.875rem; box-sizing: border-box; transition: border-color 0.2s; }
    .fi:focus { outline: none; border-color: #fff; }
    .fi::placeholder { color: #333; }
    select.fi option { background: #111; }
    textarea.fi { resize: vertical; font-family: inherit; }
    .err { padding: 0.75rem 1rem; background: rgba(229,62,62,0.08); color: #fc8181; border: 1px solid rgba(229,62,62,0.25); border-radius: 2px; font-size: 0.825rem; margin-top: 0.5rem; }
    .ok  { padding: 0.75rem 1rem; background: rgba(56,161,105,0.08); color: #68d391; border: 1px solid rgba(56,161,105,0.25); border-radius: 2px; font-size: 0.825rem; margin-top: 0.5rem; }

    /* Spinner */
    .spin { display: inline-block; width: 12px; height: 12px; border: 2px solid rgba(0,0,0,0.2); border-top-color: #000; border-radius: 50%; animation: sp 0.7s linear infinite; }
    @keyframes sp { to { transform: rotate(360deg); } }

    /* Toast */
    .toast { position: fixed; bottom: 2rem; right: 2rem; padding: 0.875rem 1.5rem; border-radius: 2px; font-weight: 700; font-size: 0.78rem; letter-spacing: 0.08em; z-index: 2000; }
    .toast.success { background: #0f0f0f; color: #68d391; border: 1px solid rgba(56,161,105,0.3); }
    .toast.error   { background: #0f0f0f; color: #fc8181; border: 1px solid rgba(229,62,62,0.3); }

    @media (max-width: 640px) {
      .pg { padding: 1rem; }
      .f2 { grid-template-columns: 1fr; }
      .grid { grid-template-columns: 1fr; }
    }
  `]
})
export class ClassesComponent implements OnInit {
  classes: GymClass[] = [];
  trainers: Trainer[] = [];
  loading = false;
  showModal = false;
  editingClass: GymClass | null = null;
  saving = false;
  formError = '';
  formSuccess = '';
  toast = '';
  toastType = 'success';

  classTypes = ['Yoga', 'HIIT', 'Strength', 'Zumba', 'Pilates', 'Cardio', 'CrossFit', 'Spinning', 'Boxing'];
  filters: any = { class_type: '', difficulty: '', trainer_id: '', available_only: false };
  form: any = { name: '', description: '', trainer_id: null, max_capacity: 20, duration_minutes: 60, start_time: '', end_time: '', class_type: 'Yoga', difficulty_level: 'Intermediate', location: 'Main Studio', is_recurring: false };

  constructor(public auth: AuthService, private classesService: ClassesService, private trainersService: TrainersService) {}

  ngOnInit() {
    this.loadClasses();
    this.trainersService.getAll().subscribe(t => this.trainers = t);
  }

  loadClasses() {
    this.loading = true;
    const f: any = {};
    if (this.filters.class_type) f.class_type = this.filters.class_type;
    if (this.filters.difficulty) f.difficulty = this.filters.difficulty;
    if (this.filters.trainer_id) f.trainer_id = this.filters.trainer_id;
    if (this.filters.available_only) f.available_only = true;
    this.classesService.getAll(f).subscribe({
      next: c => { this.classes = c; this.loading = false; },
      error: () => this.loading = false
    });
  }

  openModal() {
    this.editingClass = null;
    this.form = { name: '', description: '', trainer_id: this.trainers[0]?.id || null, max_capacity: 20, duration_minutes: 60, start_time: '', end_time: '', class_type: 'Yoga', difficulty_level: 'Intermediate', location: 'Main Studio', is_recurring: false };
    this.formError = ''; this.formSuccess = ''; this.showModal = true;
  }

  editClass(cls: GymClass) {
    this.editingClass = cls;
    this.form = { name: cls.name, description: cls.description || '', trainer_id: cls.trainer_id, max_capacity: cls.max_capacity, duration_minutes: cls.duration_minutes, start_time: this.toLocalDatetime(cls.start_time), end_time: this.toLocalDatetime(cls.end_time), class_type: cls.class_type || 'Yoga', difficulty_level: cls.difficulty_level, location: cls.location, is_recurring: cls.is_recurring };
    this.formError = ''; this.formSuccess = ''; this.showModal = true;
  }

  closeModal() { this.showModal = false; }

  saveClass() {
    if (!this.form.name || !this.form.start_time || !this.form.end_time) { this.formError = 'Name, start time and end time are required.'; return; }
    this.saving = true; this.formError = '';
    const payload = { ...this.form, trainer_id: Number(this.form.trainer_id) };
    const obs = this.editingClass ? this.classesService.update(this.editingClass.id, payload) : this.classesService.create(payload);
    obs.subscribe({
      next: () => { this.saving = false; this.showToast(this.editingClass ? 'Class updated!' : 'Class created!', 'success'); this.closeModal(); this.loadClasses(); },
      error: (err) => { this.saving = false; this.formError = err.error?.detail || 'Failed to save class.'; }
    });
  }

  bookClass(cls: GymClass) {
    this.classesService.bookClass(cls.id).subscribe({
      next: () => { this.showToast('Class booked!', 'success'); this.loadClasses(); },
      error: (err) => this.showToast(err.error?.detail || 'Booking failed.', 'error')
    });
  }

  deleteClass(id: number) {
    if (!confirm('Cancel this class? All members will be notified.')) return;
    this.classesService.delete(id).subscribe({
      next: () => { this.showToast('Class cancelled.', 'success'); this.loadClasses(); },
      error: () => this.showToast('Failed to cancel class.', 'error')
    });
  }

  getDifficultyClass(level: string) { return level?.toLowerCase() || 'intermediate'; }
  toLocalDatetime(dt: string): string { if (!dt) return ''; return new Date(dt).toISOString().slice(0, 16); }
  showToast(msg: string, type: string) { this.toast = msg; this.toastType = type; setTimeout(() => this.toast = '', 3000); }
  getTypeClass(type?: string) { return type?.toLowerCase().replace(' ', '-') || 'general'; }
}
