import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../services/auth.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="auth-page">
      <div class="auth-hero">
        <div class="hero-overlay"></div>
        <div class="hero-content">
          <h1 class="hero-title">START<br>YOUR<br>JOURNEY</h1>
          <p class="hero-sub">Join thousands of members transforming their lives every day.</p>
        </div>
      </div>

      <div class="auth-panel">
        <div class="auth-form-wrap">
          <div class="auth-brand">
            <span class="brand-name">GYM</span><span class="brand-sub">MANAGER</span>
          </div>

          <h2 class="auth-title">Create Account</h2>
          <p class="auth-desc">Fill in your details to get started.</p>

          <form (ngSubmit)="onSignup()">
            <div class="form-row">
              <div class="form-group">
                <label>Full Name *</label>
                <input type="text" [(ngModel)]="form.full_name" name="full_name" required class="form-control" placeholder="John Doe" />
              </div>
              <div class="form-group">
                <label>Phone *</label>
                <input type="tel" [(ngModel)]="form.phone" name="phone" required class="form-control" placeholder="+1 234 567 8900" />
              </div>
            </div>
            <div class="form-group">
              <label>Email Address *</label>
              <input type="email" [(ngModel)]="form.email" name="email" required class="form-control" placeholder="you@example.com" />
            </div>
            <div class="form-group">
              <label>Password *</label>
              <input type="password" [(ngModel)]="form.password" name="password" required class="form-control" placeholder="Min. 8 characters" />
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Emergency Contact</label>
                <input type="text" [(ngModel)]="form.emergency_contact" name="ec" class="form-control" placeholder="Contact name" />
              </div>
              <div class="form-group">
                <label>Emergency Phone</label>
                <input type="tel" [(ngModel)]="form.emergency_phone" name="ep" class="form-control" placeholder="+1 234 567 8900" />
              </div>
            </div>
            <div class="form-group">
              <label>Fitness Goals</label>
              <textarea [(ngModel)]="form.fitness_goals" name="goals" class="form-control" rows="2" placeholder="e.g. Lose weight, build muscle..."></textarea>
            </div>

            <div class="alert alert-error" *ngIf="error">{{ error }}</div>
            <div class="alert alert-success" *ngIf="success">{{ success }}</div>

            <button type="submit" class="btn btn-white btn-full" [disabled]="loading">
              <span class="spinner" *ngIf="loading"></span>
              {{ loading ? 'CREATING...' : 'CREATE ACCOUNT' }}
            </button>
          </form>

          <p class="auth-switch">Already a member? <a routerLink="/login">Sign in</a></p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .auth-page { display: flex; min-height: 100vh; background: #000; }
    .auth-hero {
      flex: 1; position: relative; overflow: hidden;
      background-image: url('https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=1200&q=80');
      background-size: cover; background-position: center;
      display: flex; flex-direction: column; justify-content: flex-end; padding: 3rem;
    }
    .hero-overlay { position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.2) 100%); }
    .hero-content { position: relative; z-index: 1; }
    .hero-title { font-family: 'Bebas Neue', sans-serif; font-size: clamp(4rem,8vw,7rem); line-height: 0.9; letter-spacing: 0.02em; color: #fff; }
    .hero-sub { color: #aaa; font-size: 0.95rem; margin-top: 1rem; max-width: 380px; }
    .auth-panel { width: 520px; flex-shrink: 0; background: #0a0a0a; border-left: 1px solid #1a1a1a; display: flex; align-items: center; justify-content: center; padding: 2rem; }
    .auth-form-wrap { width: 100%; max-width: 420px; }
    .auth-brand { display: flex; align-items: baseline; gap: 0.2rem; margin-bottom: 2rem; }
    .brand-name { font-family: 'Bebas Neue', sans-serif; font-size: 1.8rem; color: #fff; letter-spacing: 0.1em; }
    .brand-sub  { font-size: 0.65rem; font-weight: 700; letter-spacing: 0.25em; color: #444; }
    .auth-title { font-family: 'Bebas Neue', sans-serif; font-size: 2rem; letter-spacing: 0.05em; color: #fff; margin-bottom: 0.4rem; }
    .auth-desc  { color: #666; font-size: 0.875rem; margin-bottom: 1.75rem; }
    .form-row   { display: grid; grid-template-columns: 1fr 1fr; gap: 0.875rem; }
    .auth-switch { text-align: center; font-size: 0.8rem; color: #555; margin-top: 1.25rem; }
    .auth-switch a { color: #999; font-weight: 600; }
    .auth-switch a:hover { color: #fff; }
    @media (max-width: 900px) { .auth-hero { display: none; } .auth-panel { width: 100%; border-left: none; } .form-row { grid-template-columns: 1fr; } }
  `]
})
export class SignupComponent {
  form = { full_name:'', email:'', phone:'', password:'', emergency_contact:'', emergency_phone:'', fitness_goals:'' };
  loading = false; error = ''; success = '';
  constructor(private auth: AuthService, private router: Router) {}
  onSignup() {
    if (!this.form.full_name || !this.form.email || !this.form.phone || !this.form.password) { this.error = 'Please fill all required fields.'; return; }
    this.loading = true; this.error = '';
    this.auth.signup(this.form).subscribe({
      next: () => { this.loading = false; this.success = 'Account created! Redirecting...'; setTimeout(() => this.router.navigate(['/dashboard']), 1500); },
      error: (err) => { this.loading = false; this.error = err.error?.detail || 'Signup failed.'; }
    });
  }
}
