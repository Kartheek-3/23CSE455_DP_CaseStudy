import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { GymClass, Booking } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ClassesService {
  private apiUrl = `${environment.apiUrl}/classes`;

  constructor(private http: HttpClient) {}

  getAll(filters?: {
    class_type?: string;
    difficulty?: string;
    trainer_id?: number;
    from_date?: string;
    to_date?: string;
    available_only?: boolean;
  }): Observable<GymClass[]> {
    let params = new HttpParams();
    if (filters) {
      Object.entries(filters).forEach(([k, v]) => {
        if (v !== undefined && v !== null && v !== '') params = params.set(k, String(v));
      });
    }
    return this.http.get<GymClass[]>(this.apiUrl, { params });
  }

  getById(id: number): Observable<GymClass> {
    return this.http.get<GymClass>(`${this.apiUrl}/${id}`);
  }

  create(data: any): Observable<GymClass> {
    return this.http.post<GymClass>(this.apiUrl, data);
  }

  update(id: number, data: any): Observable<GymClass> {
    return this.http.put<GymClass>(`${this.apiUrl}/${id}`, data);
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }

  bookClass(classId: number): Observable<any> {
    return this.http.post(`${this.apiUrl}/${classId}/book`, {});
  }

  cancelBooking(classId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${classId}/book`);
  }

  getMemberSchedule(memberId: number): Observable<Booking[]> {
    return this.http.get<Booking[]>(`${this.apiUrl}/schedule/member/${memberId}`);
  }

  getTrainerSchedule(trainerId: number): Observable<GymClass[]> {
    return this.http.get<GymClass[]>(`${this.apiUrl}/schedule/trainer/${trainerId}`);
  }

  getRoster(classId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/${classId}/roster`);
  }
}
