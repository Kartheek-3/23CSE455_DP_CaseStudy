import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { SubscriptionPlan, Payment } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class PaymentsService {
  private apiUrl = `${environment.apiUrl}/payments`;

  constructor(private http: HttpClient) {}

  getPlans(): Observable<SubscriptionPlan[]> {
    return this.http.get<SubscriptionPlan[]>(`${this.apiUrl}/plans`);
  }

  createPlan(data: any): Observable<SubscriptionPlan> {
    return this.http.post<SubscriptionPlan>(`${this.apiUrl}/plans`, data);
  }

  updatePlan(id: number, data: any): Observable<SubscriptionPlan> {
    return this.http.put<SubscriptionPlan>(`${this.apiUrl}/plans/${id}`, data);
  }

  deletePlan(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/plans/${id}`);
  }

  createCheckoutSession(data: {
    plan_id: number;
    gateway: string;
    success_url?: string;
    cancel_url?: string;
  }): Observable<any> {
    return this.http.post(`${this.apiUrl}/create-checkout-session`, data);
  }

  addManualPayment(data: any): Observable<Payment> {
    return this.http.post<Payment>(`${this.apiUrl}/manual`, data);
  }

  getHistory(memberId: number): Observable<Payment[]> {
    return this.http.get<Payment[]>(`${this.apiUrl}/history/${memberId}`);
  }

  getAllPayments(status?: string): Observable<Payment[]> {
    let params = new HttpParams();
    if (status) params = params.set('status', status);
    return this.http.get<Payment[]>(`${this.apiUrl}/all`, { params });
  }

  getRevenueStats(): Observable<any> {
    return this.http.get(`${this.apiUrl}/stats/revenue`);
  }
}
