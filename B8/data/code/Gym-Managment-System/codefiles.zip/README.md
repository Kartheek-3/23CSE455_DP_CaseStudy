# 💪 GymManager – Full-Stack Fitness Center Management System

A complete gym management web application with role-based dashboards for **Admin**, **Trainer**, and **Member**.

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Angular 17 (standalone components, lazy loading) |
| Backend | Python 3.10+ / FastAPI |
| Database | SQLite (via SQLAlchemy + aiosqlite) |
| Auth | JWT (access + refresh tokens) |
| Payments | Stripe / PayPal (sandbox) |
| SMS | Twilio |
| Email | SMTP (Gmail / SendGrid) |
| QR Code | libqrcode (Python) + html5-qrcode (Angular) |

## Features

- ✅ JWT Authentication with role-based access (Admin / Trainer / Member)
- ✅ Member signup, trainer creation (admin only), forgot password
- ✅ Class scheduling with conflict detection, booking & cancellation
- ✅ Waitlist with automatic slot promotion notifications
- ✅ QR code attendance (30-second expiry, ±15 min class window)
- ✅ Manual attendance marking with class roster
- ✅ Workout & diet plan management with progress tracking
- ✅ Stripe & PayPal subscription payment integration
- ✅ Email (SMTP) & SMS (Twilio) notifications
- ✅ Fully responsive UI (mobile / tablet / desktop)

## Quick Start

### Backend

```bash
cd backend

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env   # edit .env with your keys

# Seed demo data
python seed.py

# Start server
python run.py
# API available at http://localhost:8000
# Swagger docs at http://localhost:8000/docs
```

### Frontend

```bash
cd frontend

# Install dependencies
npm install

# Start dev server
npm start
# App available at http://localhost:4200
```

## Demo Credentials

| Role | Email | Password |
|---|---|---|
| Admin | admin@gym.com | admin123 |
| Trainer | trainer@gym.com | trainer123 |
| Member | member@gym.com | member123 |

## Environment Variables (backend/.env)

```env
DATABASE_URL=sqlite+aiosqlite:///./gym_system.db
SECRET_KEY=your-super-secret-key
ALGORITHM=HS256
ACCESS_TOKEN_EXPIRE_MINUTES=30
REFRESH_TOKEN_EXPIRE_DAYS=7

# Stripe (sandbox)
STRIPE_SECRET_KEY=sk_test_xxx
STRIPE_PUBLISHABLE_KEY=pk_test_xxx

# Twilio SMS
TWILIO_ACCOUNT_SID=ACxxx
TWILIO_AUTH_TOKEN=xxx
TWILIO_PHONE_NUMBER=+1234567890

# Email SMTP
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your-email@gmail.com
SMTP_PASSWORD=your-app-password
```

## API Documentation

FastAPI auto-generates interactive Swagger UI at:
- **http://localhost:8000/docs**

### Key Endpoints

| Method | Endpoint | Description |
|---|---|---|
| POST | /api/auth/login | Login (returns JWT) |
| POST | /api/auth/signup | Member self-registration |
| GET | /api/classes | List all classes (with filters) |
| POST | /api/classes/{id}/book | Book a class |
| DELETE | /api/classes/{id}/book | Cancel booking |
| GET | /api/attendance/qr/generate | Generate QR code |
| POST | /api/attendance/qr/scan | Scan & validate QR |
| POST | /api/attendance/manual | Mark manual attendance |
| GET | /api/payments/plans | List subscription plans |
| POST | /api/payments/create-checkout-session | Stripe / PayPal checkout |
| POST | /api/plans/workout | Create workout plan |
| POST | /api/plans/diet | Create diet plan |

## Project Structure

```
GymWeb/
├── backend/
│   ├── app/
│   │   ├── core/          # config, security
│   │   ├── routers/       # auth, members, trainers, classes, attendance, payments, plans, notifications
│   │   ├── schemas/       # Pydantic models
│   │   ├── utils/         # QR generator, notifications
│   │   ├── database.py
│   │   ├── models.py      # SQLAlchemy ORM models
│   │   └── main.py
│   ├── seed.py            # Demo data seed
│   ├── run.py
│   └── requirements.txt
└── frontend/
    └── src/
        └── app/
            ├── components/   # auth, dashboard, classes, members, trainers, attendance, payments, plans
            ├── services/     # API services
            ├── guards/       # auth, admin, trainer guards
            ├── interceptors/ # JWT token interceptor
            └── models/       # TypeScript interfaces
```
