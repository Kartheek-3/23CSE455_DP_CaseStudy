"""
Seed script – creates demo Admin, Trainer, Member accounts
plus sample subscription plans and a sample class.
Run: python seed.py
"""
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from app.database import SessionLocal, engine, Base
from app.models import (
    User, Member, Trainer, SubscriptionPlan, Class, UserRole,
    SubscriptionStatus
)
from app.core.security import get_password_hash
from datetime import datetime, timedelta

Base.metadata.create_all(bind=engine)
db = SessionLocal()

def seed():
    # ── Admin ──────────────────────────────────────────────
    if not db.query(User).filter(User.email == "admin@gym.com").first():
        admin = User(
            email="admin@gym.com",
            password_hash=get_password_hash("admin123"),
            full_name="Gym Administrator",
            phone="+1-555-0001",
            role=UserRole.ADMIN,
        )
        db.add(admin)
        db.flush()
        print("✅ Admin created: admin@gym.com / admin123")

    # ── Trainer ────────────────────────────────────────────
    if not db.query(User).filter(User.email == "trainer@gym.com").first():
        trainer_user = User(
            email="trainer@gym.com",
            password_hash=get_password_hash("trainer123"),
            full_name="Alex Trainer",
            phone="+1-555-0002",
            role=UserRole.TRAINER,
        )
        db.add(trainer_user)
        db.flush()
        trainer = Trainer(
            user_id=trainer_user.id,
            specialization="HIIT & Strength",
            bio="Certified personal trainer with 8 years of experience.",
            hourly_rate=60.0,
            years_experience=8,
        )
        db.add(trainer)
        db.flush()
        print("✅ Trainer created: trainer@gym.com / trainer123")
    else:
        trainer = db.query(Trainer).join(User).filter(User.email == "trainer@gym.com").first()

    # ── Member ─────────────────────────────────────────────
    if not db.query(User).filter(User.email == "member@gym.com").first():
        member_user = User(
            email="member@gym.com",
            password_hash=get_password_hash("member123"),
            full_name="Jane Member",
            phone="+1-555-0003",
            role=UserRole.MEMBER,
        )
        db.add(member_user)
        db.flush()
        member = Member(
            user_id=member_user.id,
            emergency_contact="John Member",
            emergency_phone="+1-555-0099",
            fitness_goals="Lose 10kg, build core strength",
            subscription_status=SubscriptionStatus.ACTIVE,
            subscription_expiry=datetime.utcnow() + timedelta(days=30),
            membership_type="monthly",
        )
        db.add(member)
        print("✅ Member created: member@gym.com / member123")

    # ── Subscription Plans ────────────────────────────────
    if db.query(SubscriptionPlan).count() == 0:
        plans = [
            SubscriptionPlan(name="Monthly", description="Full access for 1 month", price=49.99, currency="USD", interval="monthly", duration_days=30, trial_days=7),
            SubscriptionPlan(name="Quarterly", description="3 months at a discount", price=129.99, currency="USD", interval="quarterly", duration_days=90, trial_days=0),
            SubscriptionPlan(name="Yearly", description="Best value – 12 months", price=449.99, currency="USD", interval="yearly", duration_days=365, trial_days=0),
            SubscriptionPlan(name="Drop-in", description="Single class pass", price=15.00, currency="USD", interval="drop_in", duration_days=1, trial_days=0),
        ]
        db.add_all(plans)
        print("✅ Subscription plans created (4 plans)")

    # ── Sample Classes ────────────────────────────────────
    if trainer and db.query(Class).count() == 0:
        now = datetime.utcnow()
        classes = [
            Class(name="Morning HIIT", description="High-intensity interval training to kickstart your day", trainer_id=trainer.id, max_capacity=20, duration_minutes=45, start_time=now + timedelta(days=1, hours=7), end_time=now + timedelta(days=1, hours=7, minutes=45), class_type="HIIT", difficulty_level="Intermediate", location="Studio A"),
            Class(name="Yoga Flow", description="Relaxing yoga session for all levels", trainer_id=trainer.id, max_capacity=15, duration_minutes=60, start_time=now + timedelta(days=1, hours=9), end_time=now + timedelta(days=1, hours=10), class_type="Yoga", difficulty_level="Beginner", location="Studio B"),
            Class(name="Strength Training", description="Build muscle with compound lifts", trainer_id=trainer.id, max_capacity=12, duration_minutes=60, start_time=now + timedelta(days=2, hours=18), end_time=now + timedelta(days=2, hours=19), class_type="Strength", difficulty_level="Advanced", location="Weight Room"),
            Class(name="Zumba Party", description="Fun cardio dance workout", trainer_id=trainer.id, max_capacity=25, duration_minutes=50, start_time=now + timedelta(days=3, hours=17), end_time=now + timedelta(days=3, hours=17, minutes=50), class_type="Zumba", difficulty_level="Beginner", location="Main Hall"),
        ]
        db.add_all(classes)
        print("✅ Sample classes created (4 classes)")

    db.commit()
    print("\n🎉 Database seeded successfully!")
    print("\nDemo credentials:")
    print("  Admin:   admin@gym.com   / admin123")
    print("  Trainer: trainer@gym.com / trainer123")
    print("  Member:  member@gym.com  / member123")

if __name__ == "__main__":
    try:
        seed()
    finally:
        db.close()
