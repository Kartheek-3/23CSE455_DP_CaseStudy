#!/usr/bin/env python3
import uvicorn
import os
import socket
from dotenv import load_dotenv

load_dotenv()


def is_port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def find_free_port(start: int = 8000) -> int:
    for port in range(start, start + 20):
        if is_port_free(port):
            return port
    return start


if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))

    if not is_port_free(port):
        print(f"⚠️  Port {port} is in use, trying next available port...")
        port = find_free_port(port + 1)
        print(f"✅ Using port {port}")

    print(f"🚀 Starting GymManager API on http://localhost:{port}")
    print(f"📖 Swagger docs: http://localhost:{port}/docs")

    uvicorn.run(
        "app.main:app",
        host="127.0.0.1",
        port=port,
        reload=True,
        log_level="info",
    )
