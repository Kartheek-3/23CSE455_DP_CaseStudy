from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, ForeignKey, Text, JSON, Enum
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .database import Base
import enum


class UserRole(str, enum.Enum):
    ADMIN = "admin"
    TRAINER = "trainer"
    MEMBER = "member"


class SubscriptionStatus(str, enum.Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    CANCELLED = "cancelled"
    PENDING = "pending"


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    REFUNDED = "refunded"


class AttendanceMethod(str, enum.Enum):
    MANUAL = "manual"
    QR = "qr"


class BookingStatus(str, enum.Enum):
    BOOKED = "booked"
    CANCELLED = "cancelled"
    ATTENDED = "attended"
    NO_SHOW = "no_show"
    WAITLISTED = "waitlisted"


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    password_hash = Column(String, nullable=False)
    full_name = Column(String, nullable=False)
    phone = Column(String, nullable=False)
    role = Column(Enum(UserRole), default=UserRole.MEMBER)
    is_active = Column(Boolean, default=True)
    profile_picture = Column(String, nullable=True)
    sms_opt_in = Column(Boolean, default=True)
    email_class_reminder = Column(Boolean, default=True)
    sms_class_reminder = Column(Boolean, default=True)
    reset_token = Column(String, nullable=True)
    reset_token_expiry = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    member_profile = relationship("Member", back_populates="user", uselist=False)
    trainer_profile = relationship("Trainer", back_populates="user", uselist=False)
    notifications = relationship("Notification", back_populates="user")


class Member(Base):
    __tablename__ = "members"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    emergency_contact = Column(String, nullable=True)
    emergency_phone = Column(String, nullable=True)
    fitness_goals = Column(Text, nullable=True)
    date_of_birth = Column(DateTime, nullable=True)
    subscription_status = Column(Enum(SubscriptionStatus), default=SubscriptionStatus.PENDING)
    subscription_expiry = Column(DateTime, nullable=True)
    membership_type = Column(String, default="monthly")

    # Relationships
    user = relationship("User", back_populates="member_profile")
    bookings = relationship("Booking", back_populates="member")
    attendance_records = relationship("Attendance", back_populates="member")
    payments = relationship("Payment", back_populates="member")
    assigned_workout_plans = relationship("WorkoutPlan", back_populates="member")
    assigned_diet_plans = relationship("DietPlan", back_populates="member")
    progress_logs = relationship("PlanProgress", back_populates="member")
    waitlist_entries = relationship("Waitlist", back_populates="member")


class Trainer(Base):
    __tablename__ = "trainers"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True)
    specialization = Column(String, nullable=False)
    bio = Column(Text, nullable=True)
    hourly_rate = Column(Float, default=0)
    years_experience = Column(Integer, default=0)
    rating = Column(Float, default=0)
    rating_count = Column(Integer, default=0)

    # Relationships
    user = relationship("User", back_populates="trainer_profile")
    classes = relationship("Class", back_populates="trainer")
    created_workout_plans = relationship("WorkoutPlan", back_populates="trainer")
    created_diet_plans = relationship("DietPlan", back_populates="trainer")
    availability = relationship("TrainerAvailability", back_populates="trainer")


class TrainerAvailability(Base):
    __tablename__ = "trainer_availability"

    id = Column(Integer, primary_key=True, index=True)
    trainer_id = Column(Integer, ForeignKey("trainers.id"))
    day_of_week = Column(Integer, nullable=False)  # 0=Monday, 6=Sunday
    start_time = Column(String, nullable=False)    # "09:00"
    end_time = Column(String, nullable=False)      # "17:00"

    trainer = relationship("Trainer", back_populates="availability")


class Class(Base):
    __tablename__ = "classes"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    trainer_id = Column(Integer, ForeignKey("trainers.id"))
    max_capacity = Column(Integer, default=20)
    current_enrolled = Column(Integer, default=0)
    duration_minutes = Column(Integer, default=60)
    start_time = Column(DateTime, nullable=False)
    end_time = Column(DateTime, nullable=False)
    class_type = Column(String, nullable=True)
    difficulty_level = Column(String, default="Intermediate")
    location = Column(String, default="Main Studio")
    is_recurring = Column(Boolean, default=False)
    recurring_rule = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # Relationships
    trainer = relationship("Trainer", back_populates="classes")
    bookings = relationship("Booking", back_populates="class_obj")
    attendance_records = relationship("Attendance", back_populates="class_obj")
    waitlist = relationship("Waitlist", back_populates="class_obj")


class Booking(Base):
    __tablename__ = "bookings"

    id = Column(Integer, primary_key=True, index=True)
    class_id = Column(Integer, ForeignKey("classes.id"))
    member_id = Column(Integer, ForeignKey("members.id"))
    status = Column(Enum(BookingStatus), default=BookingStatus.BOOKED)
    booked_at = Column(DateTime(timezone=True), server_default=func.now())
    cancelled_at = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    class_obj = relationship("Class", back_populates="bookings")
    member = relationship("Member", back_populates="bookings")
    attendance = relationship("Attendance", back_populates="booking", uselist=False)


class Waitlist(Base):
    __tablename__ = "waitlist"

    id = Column(Integer, primary_key=True, index=True)
    class_id = Column(Integer, ForeignKey("classes.id"))
    member_id = Column(Integer, ForeignKey("members.id"))
    position = Column(Integer, nullable=False)
    joined_at = Column(DateTime(timezone=True), server_default=func.now())
    notified = Column(Boolean, default=False)

    class_obj = relationship("Class", back_populates="waitlist")
    member = relationship("Member", back_populates="waitlist_entries")


class Attendance(Base):
    __tablename__ = "attendance"

    id = Column(Integer, primary_key=True, index=True)
    booking_id = Column(Integer, ForeignKey("bookings.id"), nullable=True)
    member_id = Column(Integer, ForeignKey("members.id"))
    class_id = Column(Integer, ForeignKey("classes.id"))
    marked_by = Column(Integer, ForeignKey("users.id"))
    marked_at = Column(DateTime(timezone=True), server_default=func.now())
    method = Column(Enum(AttendanceMethod), default=AttendanceMethod.MANUAL)
    check_in_time = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    booking = relationship("Booking", back_populates="attendance")
    member = relationship("Member", back_populates="attendance_records")
    class_obj = relationship("Class", back_populates="attendance_records")
    marked_by_user = relationship("User")


class SubscriptionPlan(Base):
    __tablename__ = "subscription_plans"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    price = Column(Float, nullable=False)
    currency = Column(String, default="USD")
    interval = Column(String, nullable=False)  # monthly, quarterly, yearly, drop_in
    duration_days = Column(Integer, nullable=False)
    trial_days = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    gateway_plan_id = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Payment(Base):
    __tablename__ = "payments"

    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id"))
    amount = Column(Float, nullable=False)
    currency = Column(String, default="USD")
    status = Column(Enum(PaymentStatus), default=PaymentStatus.PENDING)
    payment_method = Column(String, nullable=True)
    gateway_txn_id = Column(String, unique=True, nullable=True)
    gateway_name = Column(String, nullable=True)
    subscription_plan = Column(String, nullable=True)
    invoice_url = Column(String, nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    paid_at = Column(DateTime(timezone=True), nullable=True)

    # Relationships
    member = relationship("Member", back_populates="payments")


class WorkoutPlan(Base):
    __tablename__ = "workout_plans"

    id = Column(Integer, primary_key=True, index=True)
    trainer_id = Column(Integer, ForeignKey("trainers.id"))
    member_id = Column(Integer, ForeignKey("members.id"), nullable=True)
    class_id = Column(Integer, ForeignKey("classes.id"), nullable=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    exercises = Column(JSON, default=list)
    difficulty = Column(String, default="Intermediate")
    duration_weeks = Column(Integer, default=4)
    is_public = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    trainer = relationship("Trainer", back_populates="created_workout_plans")
    member = relationship("Member", back_populates="assigned_workout_plans")


class DietPlan(Base):
    __tablename__ = "diet_plans"

    id = Column(Integer, primary_key=True, index=True)
    trainer_id = Column(Integer, ForeignKey("trainers.id"))
    member_id = Column(Integer, ForeignKey("members.id"), nullable=True)
    class_id = Column(Integer, ForeignKey("classes.id"), nullable=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    meals = Column(JSON, default=dict)
    total_calories = Column(Integer, default=2000)
    macros = Column(JSON, default=dict)
    duration_weeks = Column(Integer, default=4)
    is_public = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # Relationships
    trainer = relationship("Trainer", back_populates="created_diet_plans")
    member = relationship("Member", back_populates="assigned_diet_plans")


class PlanProgress(Base):
    __tablename__ = "plan_progress"

    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id"))
    plan_id = Column(Integer, nullable=False)
    plan_type = Column(String, nullable=False)  # workout or diet
    exercise_name = Column(String, nullable=True)
    completed = Column(Boolean, default=True)
    feedback = Column(Text, nullable=True)
    rating = Column(Integer, nullable=True)
    logged_at = Column(DateTime(timezone=True), server_default=func.now())

    member = relationship("Member", back_populates="progress_logs")


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    type = Column(String, nullable=False)
    channel = Column(String, nullable=False)  # email, sms
    subject = Column(String, nullable=True)
    content = Column(Text, nullable=False)
    status = Column(String, default="pending")  # pending, sent, failed
    sent_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    user = relationship("User", back_populates="notifications")
