import qrcode
from io import BytesIO
import base64
import json
from datetime import datetime, timedelta
from ..core.security import create_access_token

def generate_qr_code(member_id: int, class_id: int = None) -> str:
    data = {
        "member_id": member_id,
        "timestamp": datetime.utcnow().isoformat(),
        "class_id": class_id
    }
    
    # Create a signed token for the QR
    token = create_access_token(data, expires_delta=timedelta(minutes=5))
    
    # Generate QR code
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(token)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Convert to base64
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    
    return f"data:image/png;base64,{img_str}"