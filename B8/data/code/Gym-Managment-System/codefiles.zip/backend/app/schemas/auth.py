from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime

class LoginRequest(BaseModel):
    email: str
    password: str

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: str
    emergency_contact: Optional[str] = None
    emergency_phone: Optional[str] = None
    fitness_goals: Optional[str] = None

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str
    user_id: int
    role: str

class RefreshTokenRequest(BaseModel):
    refresh_token: str