from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class ClassCreate(BaseModel):
    name: str
    description: Optional[str] = None
    trainer_id: int
    max_capacity: int = 20
    duration_minutes: int = 60
    start_time: datetime
    end_time: datetime
    class_type: Optional[str] = None
    difficulty_level: str = "Intermediate"
    location: str = "Main Studio"
    is_recurring: bool = False
    recurring_rule: Optional[str] = None


class ClassUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    trainer_id: Optional[int] = None
    max_capacity: Optional[int] = None
    duration_minutes: Optional[int] = None
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    class_type: Optional[str] = None
    difficulty_level: Optional[str] = None
    location: Optional[str] = None
    is_recurring: Optional[bool] = None
    recurring_rule: Optional[str] = None
    is_active: Optional[bool] = None


class ClassResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    trainer_id: int
    max_capacity: int
    current_enrolled: int
    duration_minutes: int
    start_time: datetime
    end_time: datetime
    class_type: Optional[str]
    difficulty_level: str
    location: str
    is_recurring: bool
    recurring_rule: Optional[str]
    is_active: bool
    trainer_name: Optional[str] = None

    class Config:
        from_attributes = True


class BookingCreate(BaseModel):
    class_id: int


class BookingResponse(BaseModel):
    id: int
    class_id: int
    member_id: int
    status: str
    booked_at: datetime
    cancelled_at: Optional[datetime]
    class_name: Optional[str] = None
    class_start_time: Optional[datetime] = None

    class Config:
        from_attributes = True


class WaitlistResponse(BaseModel):
    id: int
    class_id: int
    member_id: int
    position: int
    joined_at: datetime

    class Config:
        from_attributes = True
