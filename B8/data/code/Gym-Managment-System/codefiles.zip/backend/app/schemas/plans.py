from pydantic import BaseModel
from typing import Optional, List, Any, Dict
from datetime import datetime


class ExerciseItem(BaseModel):
    name: str
    sets: Optional[int] = None
    reps: Optional[int] = None
    duration_seconds: Optional[int] = None
    video_url: Optional[str] = None
    notes: Optional[str] = None


class WorkoutPlanCreate(BaseModel):
    title: str
    description: Optional[str] = None
    exercises: List[Dict[str, Any]] = []
    difficulty: str = "Intermediate"
    duration_weeks: int = 4
    member_id: Optional[int] = None
    class_id: Optional[int] = None
    is_public: bool = False


class WorkoutPlanUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    exercises: Optional[List[Dict[str, Any]]] = None
    difficulty: Optional[str] = None
    duration_weeks: Optional[int] = None
    is_public: Optional[bool] = None


class WorkoutPlanResponse(BaseModel):
    id: int
    trainer_id: int
    member_id: Optional[int]
    title: str
    description: Optional[str]
    exercises: List[Dict[str, Any]]
    difficulty: str
    duration_weeks: int
    is_public: bool
    created_at: datetime
    trainer_name: Optional[str] = None

    class Config:
        from_attributes = True


class MealItem(BaseModel):
    name: str
    calories: Optional[int] = None
    protein_g: Optional[float] = None
    carbs_g: Optional[float] = None
    fats_g: Optional[float] = None
    notes: Optional[str] = None


class DietPlanCreate(BaseModel):
    title: str
    description: Optional[str] = None
    meals: Dict[str, Any] = {}
    total_calories: int = 2000
    macros: Dict[str, Any] = {}
    duration_weeks: int = 4
    member_id: Optional[int] = None
    class_id: Optional[int] = None
    is_public: bool = False


class DietPlanUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    meals: Optional[Dict[str, Any]] = None
    total_calories: Optional[int] = None
    macros: Optional[Dict[str, Any]] = None
    duration_weeks: Optional[int] = None
    is_public: Optional[bool] = None


class DietPlanResponse(BaseModel):
    id: int
    trainer_id: int
    member_id: Optional[int]
    title: str
    description: Optional[str]
    meals: Dict[str, Any]
    total_calories: int
    macros: Dict[str, Any]
    duration_weeks: int
    is_public: bool
    created_at: datetime
    trainer_name: Optional[str] = None

    class Config:
        from_attributes = True


class PlanProgressCreate(BaseModel):
    plan_id: int
    plan_type: str  # workout or diet
    exercise_name: Optional[str] = None
    completed: bool = True
    feedback: Optional[str] = None
    rating: Optional[int] = None  # 1-5


class PlanProgressResponse(BaseModel):
    id: int
    member_id: int
    plan_id: int
    plan_type: str
    exercise_name: Optional[str]
    completed: bool
    feedback: Optional[str]
    rating: Optional[int]
    logged_at: datetime

    class Config:
        from_attributes = True
