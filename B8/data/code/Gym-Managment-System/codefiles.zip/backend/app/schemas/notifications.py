from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class NotificationResponse(BaseModel):
    id: int
    user_id: int
    type: str
    channel: str
    subject: Optional[str]
    content: str
    status: str
    sent_at: Optional[datetime]
    created_at: datetime

    class Config:
        from_attributes = True


class NotificationSettingsUpdate(BaseModel):
    sms_opt_in: Optional[bool] = None
    email_class_reminder: Optional[bool] = None
    sms_class_reminder: Optional[bool] = None
    email_payment_receipt: Optional[bool] = None
    sms_attendance: Optional[bool] = None
