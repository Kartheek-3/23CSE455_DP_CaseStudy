from pydantic import BaseModel, EmailStr
from typing import Optional
from datetime import datetime
from ..models import SubscriptionStatus, UserRole


class MemberBase(BaseModel):
    emergency_contact: Optional[str] = None
    emergency_phone: Optional[str] = None
    fitness_goals: Optional[str] = None
    date_of_birth: Optional[datetime] = None


class MemberCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: str
    emergency_contact: Optional[str] = None
    emergency_phone: Optional[str] = None
    fitness_goals: Optional[str] = None


class MemberUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    emergency_contact: Optional[str] = None
    emergency_phone: Optional[str] = None
    fitness_goals: Optional[str] = None
    date_of_birth: Optional[datetime] = None


class MemberResponse(BaseModel):
    id: int
    user_id: int
    emergency_contact: Optional[str]
    emergency_phone: Optional[str]
    fitness_goals: Optional[str]
    subscription_status: SubscriptionStatus
    subscription_expiry: Optional[datetime]
    membership_type: str
    full_name: str
    email: str
    phone: str
    is_active: bool
    created_at: Optional[datetime]

    class Config:
        from_attributes = True
