from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime
from ..models import PaymentStatus


class SubscriptionPlanCreate(BaseModel):
    name: str
    description: Optional[str] = None
    price: float
    currency: str = "USD"
    interval: str  # monthly, quarterly, yearly, drop_in
    duration_days: int
    trial_days: int = 0
    is_active: bool = True
    gateway_plan_id: Optional[str] = None


class SubscriptionPlanUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    is_active: Optional[bool] = None


class SubscriptionPlanResponse(BaseModel):
    id: int
    name: str
    description: Optional[str]
    price: float
    currency: str
    interval: str
    duration_days: int
    trial_days: int
    is_active: bool

    class Config:
        from_attributes = True


class CheckoutSessionCreate(BaseModel):
    plan_id: int
    gateway: str = "stripe"  # stripe or paypal
    success_url: Optional[str] = None
    cancel_url: Optional[str] = None


class ManualPaymentCreate(BaseModel):
    member_id: int
    amount: float
    currency: str = "USD"
    subscription_plan: Optional[str] = None
    notes: Optional[str] = None


class PaymentResponse(BaseModel):
    id: int
    member_id: int
    amount: float
    currency: str
    status: PaymentStatus
    payment_method: Optional[str]
    gateway_txn_id: Optional[str]
    gateway_name: Optional[str]
    subscription_plan: Optional[str]
    created_at: datetime
    paid_at: Optional[datetime]
    member_name: Optional[str] = None

    class Config:
        from_attributes = True
