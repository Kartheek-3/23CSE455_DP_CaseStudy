from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime


class TrainerCreate(BaseModel):
    email: EmailStr
    password: str
    full_name: str
    phone: str
    specialization: str
    bio: Optional[str] = None
    hourly_rate: float = 0.0
    years_experience: int = 0


class TrainerUpdate(BaseModel):
    full_name: Optional[str] = None
    phone: Optional[str] = None
    specialization: Optional[str] = None
    bio: Optional[str] = None
    hourly_rate: Optional[float] = None
    years_experience: Optional[int] = None


class TrainerAvailabilityCreate(BaseModel):
    day_of_week: int  # 0=Monday, 6=Sunday
    start_time: str   # "09:00"
    end_time: str     # "17:00"


class TrainerAvailabilityResponse(BaseModel):
    id: int
    trainer_id: int
    day_of_week: int
    start_time: str
    end_time: str

    class Config:
        from_attributes = True


class TrainerResponse(BaseModel):
    id: int
    user_id: int
    specialization: str
    bio: Optional[str]
    hourly_rate: float
    years_experience: int
    rating: float
    rating_count: int
    full_name: str
    email: str
    phone: str
    is_active: bool
    profile_picture: Optional[str]

    class Config:
        from_attributes = True


class TrainerRatingCreate(BaseModel):
    trainer_id: int
    rating: int  # 1-5
    comment: Optional[str] = None
