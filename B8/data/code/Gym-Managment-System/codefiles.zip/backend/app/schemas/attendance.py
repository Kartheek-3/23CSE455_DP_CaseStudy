from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime


class AttendanceManualCreate(BaseModel):
    member_id: int
    class_id: int
    booking_id: Optional[int] = None


class AttendanceQRScan(BaseModel):
    qr_token: str
    class_id: int


class AttendanceResponse(BaseModel):
    id: int
    member_id: int
    class_id: int
    marked_by: int
    marked_at: datetime
    method: str
    member_name: Optional[str] = None
    class_name: Optional[str] = None

    class Config:
        from_attributes = True


class AttendanceReportItem(BaseModel):
    date: str
    total_checkins: int
    class_name: Optional[str] = None
    member_name: Optional[str] = None


class QRGenerateResponse(BaseModel):
    qr_image: str
    token: str
    expires_at: datetime
