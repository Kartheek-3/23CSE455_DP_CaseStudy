from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .database import engine, Base
from .routers import auth, members, trainers, classes, attendance, payments, plans, notifications
from .core.config import settings

# Create tables
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Gym Management System API",
    description="Complete fitness center management system",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(members.router, prefix="/api/members", tags=["Members"])
app.include_router(trainers.router, prefix="/api/trainers", tags=["Trainers"])
app.include_router(classes.router, prefix="/api/classes", tags=["Classes"])
app.include_router(attendance.router, prefix="/api/attendance", tags=["Attendance"])
app.include_router(payments.router, prefix="/api/payments", tags=["Payments"])
app.include_router(plans.router, prefix="/api/plans", tags=["Plans"])
app.include_router(notifications.router, prefix="/api/notifications", tags=["Notifications"])

@app.get("/")
async def root():
    return {"message": "Gym Management System API", "status": "running"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}