from fastapi import APIRouter, Depends, HTTPException, Request, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta
import stripe
import uuid

from ..database import get_db
from ..models import User, Member, Payment, SubscriptionPlan, PaymentStatus, SubscriptionStatus, UserRole
from ..schemas.payments import (
    SubscriptionPlanCreate, SubscriptionPlanUpdate, SubscriptionPlanResponse,
    CheckoutSessionCreate, ManualPaymentCreate, PaymentResponse
)
from ..routers.auth import get_current_user, get_current_admin
from ..core.config import settings
from ..utils.notifications import send_email

router = APIRouter()


@router.get("/plans", response_model=List[SubscriptionPlanResponse])
def list_plans(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return db.query(SubscriptionPlan).filter(SubscriptionPlan.is_active == True).all()


@router.post("/plans", response_model=SubscriptionPlanResponse)
def create_plan(
    plan_data: SubscriptionPlanCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    plan = SubscriptionPlan(**plan_data.model_dump())
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan


@router.put("/plans/{plan_id}", response_model=SubscriptionPlanResponse)
def update_plan(
    plan_id: int,
    update_data: SubscriptionPlanUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    for field, value in update_data.model_dump(exclude_unset=True).items():
        setattr(plan, field, value)
    db.commit()
    db.refresh(plan)
    return plan


@router.delete("/plans/{plan_id}")
def delete_plan(
    plan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    plan.is_active = False
    db.commit()
    return {"message": "Plan deactivated"}


@router.post("/create-checkout-session")
def create_checkout_session(
    session_data: CheckoutSessionCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == session_data.plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")

    member = db.query(Member).filter(Member.user_id == current_user.id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member profile not found")

    if session_data.gateway == "stripe" and settings.STRIPE_SECRET_KEY:
        stripe.api_key = settings.STRIPE_SECRET_KEY
        try:
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=["card"],
                line_items=[{
                    "price_data": {
                        "currency": plan.currency.lower(),
                        "product_data": {"name": plan.name},
                        "unit_amount": int(plan.price * 100),
                    },
                    "quantity": 1,
                }],
                mode="payment",
                success_url=session_data.success_url or "http://localhost:4200/payments?success=true",
                cancel_url=session_data.cancel_url or "http://localhost:4200/payments?cancelled=true",
                metadata={"member_id": member.id, "plan_id": plan.id},
            )
            return {"checkout_url": checkout_session.url, "session_id": checkout_session.id}
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Stripe error: {str(e)}")

    # Fallback: create a pending payment record (for demo/cash)
    payment = Payment(
        member_id=member.id,
        amount=plan.price,
        currency=plan.currency,
        status=PaymentStatus.PENDING,
        gateway_name=session_data.gateway,
        subscription_plan=plan.name,
        gateway_txn_id=str(uuid.uuid4()),
    )
    db.add(payment)
    db.commit()
    return {"message": "Payment initiated", "payment_id": payment.id, "amount": plan.price}


@router.post("/webhook/stripe")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature")

    try:
        if settings.STRIPE_SECRET_KEY:
            stripe.api_key = settings.STRIPE_SECRET_KEY
            event = stripe.Webhook.construct_event(payload, sig_header, "whsec_test")
        else:
            import json
            event = json.loads(payload)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid webhook")

    if event.get("type") == "checkout.session.completed":
        session = event["data"]["object"]
        metadata = session.get("metadata", {})
        member_id = int(metadata.get("member_id", 0))
        plan_id = int(metadata.get("plan_id", 0))

        plan = db.query(SubscriptionPlan).filter(SubscriptionPlan.id == plan_id).first()
        member = db.query(Member).filter(Member.id == member_id).first()

        if member and plan:
            payment = Payment(
                member_id=member_id,
                amount=plan.price,
                currency=plan.currency,
                status=PaymentStatus.COMPLETED,
                gateway_name="stripe",
                gateway_txn_id=session.get("id"),
                subscription_plan=plan.name,
                paid_at=datetime.utcnow(),
            )
            db.add(payment)

            member.subscription_status = SubscriptionStatus.ACTIVE
            member.subscription_expiry = datetime.utcnow() + timedelta(days=plan.duration_days)
            member.membership_type = plan.interval
            db.commit()

    return {"status": "ok"}


@router.post("/manual", response_model=PaymentResponse)
def add_manual_payment(
    payment_data: ManualPaymentCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    member = db.query(Member).filter(Member.id == payment_data.member_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")

    payment = Payment(
        member_id=payment_data.member_id,
        amount=payment_data.amount,
        currency=payment_data.currency,
        status=PaymentStatus.COMPLETED,
        payment_method="cash",
        gateway_name="manual",
        gateway_txn_id=str(uuid.uuid4()),
        subscription_plan=payment_data.subscription_plan,
        notes=payment_data.notes,
        paid_at=datetime.utcnow(),
    )
    db.add(payment)

    # Update subscription
    if payment_data.subscription_plan:
        plan = db.query(SubscriptionPlan).filter(
            SubscriptionPlan.name == payment_data.subscription_plan
        ).first()
        if plan:
            member.subscription_status = SubscriptionStatus.ACTIVE
            member.subscription_expiry = datetime.utcnow() + timedelta(days=plan.duration_days)

    db.commit()
    db.refresh(payment)

    background_tasks.add_task(
        send_email,
        member.user.email,
        "Payment Receipt",
        f"<h3>Payment Received</h3><p>Amount: {payment.currency} {payment.amount}</p><p>Plan: {payment.subscription_plan or 'N/A'}</p><p>Thank you!</p>",
    )

    return {
        **payment.__dict__,
        "member_name": member.user.full_name if member.user else None,
    }


@router.get("/history/{member_id}", response_model=List[PaymentResponse])
def payment_history(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role == UserRole.MEMBER:
        member = db.query(Member).filter(Member.user_id == current_user.id).first()
        if not member or member.id != member_id:
            raise HTTPException(status_code=403, detail="Access denied")

    payments = db.query(Payment).filter(Payment.member_id == member_id).order_by(Payment.created_at.desc()).all()
    result = []
    for p in payments:
        result.append({
            **p.__dict__,
            "member_name": p.member.user.full_name if p.member and p.member.user else None,
        })
    return result


@router.get("/all", response_model=List[PaymentResponse])
def all_payments(
    skip: int = 0,
    limit: int = 100,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    query = db.query(Payment)
    if status:
        query = query.filter(Payment.status == status)
    payments = query.order_by(Payment.created_at.desc()).offset(skip).limit(limit).all()
    result = []
    for p in payments:
        result.append({
            **p.__dict__,
            "member_name": p.member.user.full_name if p.member and p.member.user else None,
        })
    return result


@router.get("/stats/revenue")
def revenue_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    from sqlalchemy import extract, func
    now = datetime.utcnow()

    monthly = db.query(func.sum(Payment.amount)).filter(
        Payment.status == PaymentStatus.COMPLETED,
        extract("month", Payment.paid_at) == now.month,
        extract("year", Payment.paid_at) == now.year,
    ).scalar() or 0

    total = db.query(func.sum(Payment.amount)).filter(
        Payment.status == PaymentStatus.COMPLETED
    ).scalar() or 0

    return {"monthly_revenue": monthly, "total_revenue": total}
