from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from pydantic import BaseModel
from datetime import timedelta
from ..database import get_db
from ..models import User, Member, UserRole
from ..schemas import auth as auth_schemas
from ..core.security import verify_password, get_password_hash, create_access_token, create_refresh_token, decode_token
from ..core.config import settings

router = APIRouter()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

@router.post("/signup", response_model=auth_schemas.TokenResponse)
def signup(user_data: auth_schemas.UserCreate, db: Session = Depends(get_db)):
    # Check if user exists
    existing_user = db.query(User).filter(User.email == user_data.email).first()
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    
    # Create user
    hashed_password = get_password_hash(user_data.password)
    new_user = User(
        email=user_data.email,
        password_hash=hashed_password,
        full_name=user_data.full_name,
        phone=user_data.phone,
        role=UserRole.MEMBER
    )
    db.add(new_user)
    db.flush()
    
    # Create member profile
    new_member = Member(
        user_id=new_user.id,
        emergency_contact=user_data.emergency_contact,
        emergency_phone=user_data.emergency_phone,
        fitness_goals=user_data.fitness_goals
    )
    db.add(new_member)
    db.commit()
    
    # Create tokens
    access_token = create_access_token(data={"sub": new_user.email, "user_id": new_user.id, "role": new_user.role})
    refresh_token = create_refresh_token(data={"sub": new_user.email, "user_id": new_user.id})
    
    return auth_schemas.TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        user_id=new_user.id,
        role=new_user.role
    )

@router.post("/login", response_model=auth_schemas.TokenResponse)
def login(login_data: auth_schemas.LoginRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == login_data.email).first()
    if not user or not verify_password(login_data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if not user.is_active:
        raise HTTPException(status_code=401, detail="Account is inactive")

    access_token = create_access_token(data={"sub": user.email, "user_id": user.id, "role": user.role})
    refresh_token = create_refresh_token(data={"sub": user.email, "user_id": user.id})

    return auth_schemas.TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",
        user_id=user.id,
        role=user.role
    )

@router.post("/refresh")
def refresh_token(refresh_data: auth_schemas.RefreshTokenRequest, db: Session = Depends(get_db)):
    payload = decode_token(refresh_data.refresh_token)
    if not payload or payload.get("type") != "refresh":
        raise HTTPException(status_code=401, detail="Invalid refresh token")
    
    user_email = payload.get("sub")
    user = db.query(User).filter(User.email == user_email).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    new_access_token = create_access_token(data={"sub": user.email, "user_id": user.id, "role": user.role})
    return {"access_token": new_access_token, "token_type": "bearer"}

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    payload = decode_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid token")
    
    user_email = payload.get("sub")
    user = db.query(User).filter(User.email == user_email).first()
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    
    return user

def get_current_admin(current_user: User = Depends(get_current_user)):
    if current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user

def get_current_trainer(current_user: User = Depends(get_current_user)):
    if current_user.role not in [UserRole.ADMIN, UserRole.TRAINER]:
        raise HTTPException(status_code=403, detail="Trainer access required")
    return current_user

def get_current_member(current_user: User = Depends(get_current_user)):
    if current_user.role not in [UserRole.ADMIN, UserRole.MEMBER]:
        raise HTTPException(status_code=403, detail="Member access required")
    return current_user


class ForgotPasswordRequest(BaseModel):
    email: str

@router.post("/forgot-password")
def forgot_password(data: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()
    # Always return 200 to prevent email enumeration
    if user:
        from datetime import datetime, timedelta
        import secrets
        token = secrets.token_urlsafe(32)
        user.reset_token = token
        user.reset_token_expiry = datetime.utcnow() + timedelta(hours=1)
        db.commit()
        # In production: send email with reset link
        # send_email(user.email, "Password Reset", f"Reset link: http://localhost:4200/reset-password?token={token}")
    return {"message": "If this email exists, a reset link has been sent."}