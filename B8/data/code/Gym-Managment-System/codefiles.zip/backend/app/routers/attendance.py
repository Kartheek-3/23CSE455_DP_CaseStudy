from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List, Optional
from datetime import datetime, timedelta
import csv
import io

from ..database import get_db
from ..models import User, Attendance, Booking, Member, Class, AttendanceMethod, BookingStatus, UserRole
from ..schemas.attendance import (
    AttendanceManualCreate, AttendanceQRScan,
    AttendanceResponse, QRGenerateResponse
)
from ..routers.auth import get_current_user, get_current_admin, get_current_trainer
from ..utils.qr_generator import generate_qr_code
from ..core.security import decode_token, create_access_token

router = APIRouter()

QR_WINDOW_MINUTES = 15  # ±15 minutes from class start


@router.get("/qr/generate", response_model=QRGenerateResponse)
def generate_qr(
    class_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    member = db.query(Member).filter(Member.user_id == current_user.id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member profile not found")

    expires_at = datetime.utcnow() + timedelta(seconds=30)
    qr_image = generate_qr_code(member.id, class_id)

    from datetime import timedelta as td
    token = create_access_token(
        data={"member_id": member.id, "class_id": class_id, "type": "qr_checkin"},
        expires_delta=td(seconds=30),
    )

    return QRGenerateResponse(qr_image=qr_image, token=token, expires_at=expires_at)


@router.post("/qr/scan")
def scan_qr(
    scan_data: AttendanceQRScan,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    payload = decode_token(scan_data.qr_token)
    if not payload or payload.get("type") != "qr_checkin":
        raise HTTPException(status_code=400, detail="Invalid or expired QR code")

    member_id = payload.get("member_id")
    class_id = scan_data.class_id

    cls = db.query(Class).filter(Class.id == class_id).first()
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")

    # Anti-spoofing: check class time window
    now = datetime.utcnow()
    window_start = cls.start_time - timedelta(minutes=QR_WINDOW_MINUTES)
    window_end = cls.start_time + timedelta(minutes=QR_WINDOW_MINUTES)
    if not (window_start <= now <= window_end):
        raise HTTPException(
            status_code=400,
            detail=f"QR scan only allowed within ±{QR_WINDOW_MINUTES} minutes of class start time"
        )

    # Check for duplicate attendance
    existing = db.query(Attendance).filter(
        Attendance.member_id == member_id,
        Attendance.class_id == class_id,
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Attendance already recorded")

    # Find booking
    booking = db.query(Booking).filter(
        Booking.member_id == member_id,
        Booking.class_id == class_id,
        Booking.status == BookingStatus.BOOKED,
    ).first()

    attendance = Attendance(
        booking_id=booking.id if booking else None,
        member_id=member_id,
        class_id=class_id,
        marked_by=current_user.id,
        method=AttendanceMethod.QR,
        check_in_time=now,
    )
    db.add(attendance)

    if booking:
        booking.status = BookingStatus.ATTENDED

    db.commit()
    db.refresh(attendance)

    member = db.query(Member).filter(Member.id == member_id).first()
    return {
        "message": "Attendance recorded successfully",
        "member_name": member.user.full_name if member and member.user else "Unknown",
        "class_name": cls.name,
        "checked_in_at": attendance.check_in_time,
    }


@router.post("/manual")
def mark_manual_attendance(
    data: AttendanceManualCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    existing = db.query(Attendance).filter(
        Attendance.member_id == data.member_id,
        Attendance.class_id == data.class_id,
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Attendance already recorded")

    booking = db.query(Booking).filter(
        Booking.member_id == data.member_id,
        Booking.class_id == data.class_id,
        Booking.status == BookingStatus.BOOKED,
    ).first()

    attendance = Attendance(
        booking_id=data.booking_id or (booking.id if booking else None),
        member_id=data.member_id,
        class_id=data.class_id,
        marked_by=current_user.id,
        method=AttendanceMethod.MANUAL,
        check_in_time=datetime.utcnow(),
    )
    db.add(attendance)

    if booking:
        booking.status = BookingStatus.ATTENDED

    db.commit()
    db.refresh(attendance)

    member = db.query(Member).filter(Member.id == data.member_id).first()
    cls = db.query(Class).filter(Class.id == data.class_id).first()

    return {
        "id": attendance.id,
        "member_id": attendance.member_id,
        "class_id": attendance.class_id,
        "marked_by": attendance.marked_by,
        "marked_at": attendance.marked_at,
        "method": attendance.method,
        "member_name": member.user.full_name if member and member.user else None,
        "class_name": cls.name if cls else None,
    }


@router.get("/report")
def attendance_report(
    from_date: Optional[datetime] = Query(None),
    to_date: Optional[datetime] = Query(None),
    class_id: Optional[int] = Query(None),
    member_id: Optional[int] = Query(None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    query = db.query(Attendance)
    if from_date:
        query = query.filter(Attendance.marked_at >= from_date)
    if to_date:
        query = query.filter(Attendance.marked_at <= to_date)
    if class_id:
        query = query.filter(Attendance.class_id == class_id)
    if member_id:
        query = query.filter(Attendance.member_id == member_id)

    records = query.order_by(Attendance.marked_at.desc()).all()

    result = []
    for r in records:
        result.append({
            "id": r.id,
            "member_id": r.member_id,
            "class_id": r.class_id,
            "marked_at": r.marked_at,
            "method": r.method,
            "member_name": r.member.user.full_name if r.member and r.member.user else None,
            "class_name": r.class_obj.name if r.class_obj else None,
        })
    return result


@router.get("/stats/overview")
def attendance_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    today = datetime.utcnow().date()
    today_start = datetime.combine(today, datetime.min.time())
    today_end = datetime.combine(today, datetime.max.time())

    today_count = db.query(Attendance).filter(
        Attendance.marked_at >= today_start,
        Attendance.marked_at <= today_end,
    ).count()

    week_start = today_start - timedelta(days=today.weekday())
    week_count = db.query(Attendance).filter(Attendance.marked_at >= week_start).count()

    total = db.query(Attendance).count()

    return {
        "today": today_count,
        "this_week": week_count,
        "total": total,
    }


@router.get("/member/{member_id}/streak")
def member_streak(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    records = (
        db.query(Attendance)
        .filter(Attendance.member_id == member_id)
        .order_by(Attendance.marked_at.desc())
        .all()
    )
    if not records:
        return {"streak": 0, "total_attended": 0}

    dates = sorted(set(r.marked_at.date() for r in records), reverse=True)
    streak = 1
    for i in range(1, len(dates)):
        if (dates[i - 1] - dates[i]).days == 1:
            streak += 1
        else:
            break

    return {"streak": streak, "total_attended": len(records)}
