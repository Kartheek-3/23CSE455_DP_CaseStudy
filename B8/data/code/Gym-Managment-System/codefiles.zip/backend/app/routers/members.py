from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Optional
from datetime import datetime, timedelta

from ..database import get_db
from ..models import User, Member, UserRole, SubscriptionStatus
from ..schemas.members import MemberCreate, MemberUpdate, MemberResponse
from ..core.security import get_password_hash
from ..routers.auth import get_current_user, get_current_admin
from ..utils.notifications import send_email

router = APIRouter()


def _build_member_response(member: Member) -> dict:
    return {
        "id": member.id,
        "user_id": member.user_id,
        "emergency_contact": member.emergency_contact,
        "emergency_phone": member.emergency_phone,
        "fitness_goals": member.fitness_goals,
        "subscription_status": member.subscription_status,
        "subscription_expiry": member.subscription_expiry,
        "membership_type": member.membership_type,
        "full_name": member.user.full_name,
        "email": member.user.email,
        "phone": member.user.phone,
        "is_active": member.user.is_active,
        "created_at": member.user.created_at,
    }


@router.get("/", response_model=List[MemberResponse])
def list_members(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    status: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    query = db.query(Member).join(User)
    if search:
        query = query.filter(
            User.full_name.ilike(f"%{search}%") | User.email.ilike(f"%{search}%")
        )
    if status:
        query = query.filter(Member.subscription_status == status)
    members = query.offset(skip).limit(limit).all()
    return [_build_member_response(m) for m in members]


@router.post("/", response_model=MemberResponse)
def create_member(
    member_data: MemberCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    existing = db.query(User).filter(User.email == member_data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    new_user = User(
        email=member_data.email,
        password_hash=get_password_hash(member_data.password),
        full_name=member_data.full_name,
        phone=member_data.phone,
        role=UserRole.MEMBER,
    )
    db.add(new_user)
    db.flush()

    new_member = Member(
        user_id=new_user.id,
        emergency_contact=member_data.emergency_contact,
        emergency_phone=member_data.emergency_phone,
        fitness_goals=member_data.fitness_goals,
    )
    db.add(new_member)
    db.commit()
    db.refresh(new_member)

    background_tasks.add_task(
        send_email,
        new_user.email,
        "Welcome to GymManager!",
        f"<h2>Welcome {new_user.full_name}!</h2><p>Your account has been created. Login with your email and the password provided by your admin.</p>",
    )

    return _build_member_response(new_member)


@router.get("/me", response_model=MemberResponse)
def get_my_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    member = db.query(Member).filter(Member.user_id == current_user.id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member profile not found")
    return _build_member_response(member)


@router.get("/{member_id}", response_model=MemberResponse)
def get_member(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    member = db.query(Member).filter(Member.id == member_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    # Members can only view their own profile; admins/trainers can view all
    if current_user.role == UserRole.MEMBER and member.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    return _build_member_response(member)


@router.put("/{member_id}", response_model=MemberResponse)
def update_member(
    member_id: int,
    update_data: MemberUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    member = db.query(Member).filter(Member.id == member_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    if current_user.role == UserRole.MEMBER and member.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")

    if update_data.full_name:
        member.user.full_name = update_data.full_name
    if update_data.phone:
        member.user.phone = update_data.phone
    if update_data.emergency_contact is not None:
        member.emergency_contact = update_data.emergency_contact
    if update_data.emergency_phone is not None:
        member.emergency_phone = update_data.emergency_phone
    if update_data.fitness_goals is not None:
        member.fitness_goals = update_data.fitness_goals
    if update_data.date_of_birth is not None:
        member.date_of_birth = update_data.date_of_birth

    db.commit()
    db.refresh(member)
    return _build_member_response(member)


@router.delete("/{member_id}")
def delete_member(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    member = db.query(Member).filter(Member.id == member_id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member not found")
    member.user.is_active = False
    db.commit()
    return {"message": "Member deactivated successfully"}


@router.get("/stats/overview")
def member_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    total = db.query(Member).count()
    active = db.query(Member).filter(Member.subscription_status == SubscriptionStatus.ACTIVE).count()
    expired = db.query(Member).filter(Member.subscription_status == SubscriptionStatus.EXPIRED).count()
    pending = db.query(Member).filter(Member.subscription_status == SubscriptionStatus.PENDING).count()
    return {
        "total": total,
        "active": active,
        "expired": expired,
        "pending": pending,
    }
