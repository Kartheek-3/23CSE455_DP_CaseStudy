from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Optional

from ..database import get_db
from ..models import User, WorkoutPlan, DietPlan, Member, Trainer, PlanProgress, UserRole
from ..schemas.plans import (
    WorkoutPlanCreate, WorkoutPlanUpdate, WorkoutPlanResponse,
    DietPlanCreate, DietPlanUpdate, DietPlanResponse,
    PlanProgressCreate, PlanProgressResponse
)
from ..routers.auth import get_current_user, get_current_trainer
from ..utils.notifications import send_email

router = APIRouter()


def _build_workout_response(plan: WorkoutPlan) -> dict:
    return {
        "id": plan.id,
        "trainer_id": plan.trainer_id,
        "member_id": plan.member_id,
        "title": plan.title,
        "description": plan.description,
        "exercises": plan.exercises or [],
        "difficulty": plan.difficulty,
        "duration_weeks": plan.duration_weeks,
        "is_public": plan.is_public,
        "created_at": plan.created_at,
        "trainer_name": plan.trainer.user.full_name if plan.trainer and plan.trainer.user else None,
    }


def _build_diet_response(plan: DietPlan) -> dict:
    return {
        "id": plan.id,
        "trainer_id": plan.trainer_id,
        "member_id": plan.member_id,
        "title": plan.title,
        "description": plan.description,
        "meals": plan.meals or {},
        "total_calories": plan.total_calories,
        "macros": plan.macros or {},
        "duration_weeks": plan.duration_weeks,
        "is_public": plan.is_public,
        "created_at": plan.created_at,
        "trainer_name": plan.trainer.user.full_name if plan.trainer and plan.trainer.user else None,
    }


# ── Workout Plans ──────────────────────────────────────────────────────────────

@router.post("/workout", response_model=WorkoutPlanResponse)
def create_workout_plan(
    plan_data: WorkoutPlanCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    trainer = db.query(Trainer).filter(Trainer.user_id == current_user.id).first()
    if not trainer and current_user.role != UserRole.ADMIN:
        raise HTTPException(status_code=404, detail="Trainer profile not found")

    trainer_id = trainer.id if trainer else 1

    plan = WorkoutPlan(
        trainer_id=trainer_id,
        member_id=plan_data.member_id,
        class_id=plan_data.class_id,
        title=plan_data.title,
        description=plan_data.description,
        exercises=plan_data.exercises,
        difficulty=plan_data.difficulty,
        duration_weeks=plan_data.duration_weeks,
        is_public=plan_data.is_public,
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)

    # Notify assigned member
    if plan_data.member_id:
        member = db.query(Member).filter(Member.id == plan_data.member_id).first()
        if member and member.user:
            background_tasks.add_task(
                send_email,
                member.user.email,
                f"New Workout Plan: {plan.title}",
                f"<p>Your trainer has assigned you a new workout plan: <strong>{plan.title}</strong>. Check your dashboard to view it.</p>",
            )

    return _build_workout_response(plan)


@router.get("/workout", response_model=List[WorkoutPlanResponse])
def list_workout_plans(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role == UserRole.TRAINER:
        trainer = db.query(Trainer).filter(Trainer.user_id == current_user.id).first()
        plans = db.query(WorkoutPlan).filter(WorkoutPlan.trainer_id == trainer.id).all() if trainer else []
    elif current_user.role == UserRole.MEMBER:
        member = db.query(Member).filter(Member.user_id == current_user.id).first()
        plans = db.query(WorkoutPlan).filter(
            (WorkoutPlan.member_id == member.id) | (WorkoutPlan.is_public == True)
        ).all() if member else []
    else:
        plans = db.query(WorkoutPlan).all()
    return [_build_workout_response(p) for p in plans]


@router.get("/workout/{plan_id}", response_model=WorkoutPlanResponse)
def get_workout_plan(
    plan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    plan = db.query(WorkoutPlan).filter(WorkoutPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    return _build_workout_response(plan)


@router.put("/workout/{plan_id}", response_model=WorkoutPlanResponse)
def update_workout_plan(
    plan_id: int,
    update_data: WorkoutPlanUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    plan = db.query(WorkoutPlan).filter(WorkoutPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    for field, value in update_data.model_dump(exclude_unset=True).items():
        setattr(plan, field, value)
    db.commit()
    db.refresh(plan)
    return _build_workout_response(plan)


@router.delete("/workout/{plan_id}")
def delete_workout_plan(
    plan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    plan = db.query(WorkoutPlan).filter(WorkoutPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    db.delete(plan)
    db.commit()
    return {"message": "Plan deleted"}


# ── Diet Plans ─────────────────────────────────────────────────────────────────

@router.post("/diet", response_model=DietPlanResponse)
def create_diet_plan(
    plan_data: DietPlanCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    trainer = db.query(Trainer).filter(Trainer.user_id == current_user.id).first()
    trainer_id = trainer.id if trainer else 1

    plan = DietPlan(
        trainer_id=trainer_id,
        member_id=plan_data.member_id,
        class_id=plan_data.class_id,
        title=plan_data.title,
        description=plan_data.description,
        meals=plan_data.meals,
        total_calories=plan_data.total_calories,
        macros=plan_data.macros,
        duration_weeks=plan_data.duration_weeks,
        is_public=plan_data.is_public,
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)

    if plan_data.member_id:
        member = db.query(Member).filter(Member.id == plan_data.member_id).first()
        if member and member.user:
            background_tasks.add_task(
                send_email,
                member.user.email,
                f"New Diet Plan: {plan.title}",
                f"<p>Your trainer has assigned you a new diet plan: <strong>{plan.title}</strong>. Check your dashboard to view it.</p>",
            )

    return _build_diet_response(plan)


@router.get("/diet", response_model=List[DietPlanResponse])
def list_diet_plans(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role == UserRole.TRAINER:
        trainer = db.query(Trainer).filter(Trainer.user_id == current_user.id).first()
        plans = db.query(DietPlan).filter(DietPlan.trainer_id == trainer.id).all() if trainer else []
    elif current_user.role == UserRole.MEMBER:
        member = db.query(Member).filter(Member.user_id == current_user.id).first()
        plans = db.query(DietPlan).filter(
            (DietPlan.member_id == member.id) | (DietPlan.is_public == True)
        ).all() if member else []
    else:
        plans = db.query(DietPlan).all()
    return [_build_diet_response(p) for p in plans]


@router.get("/diet/{plan_id}", response_model=DietPlanResponse)
def get_diet_plan(
    plan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    plan = db.query(DietPlan).filter(DietPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    return _build_diet_response(plan)


@router.put("/diet/{plan_id}", response_model=DietPlanResponse)
def update_diet_plan(
    plan_id: int,
    update_data: DietPlanUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    plan = db.query(DietPlan).filter(DietPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    for field, value in update_data.model_dump(exclude_unset=True).items():
        setattr(plan, field, value)
    db.commit()
    db.refresh(plan)
    return _build_diet_response(plan)


@router.delete("/diet/{plan_id}")
def delete_diet_plan(
    plan_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    plan = db.query(DietPlan).filter(DietPlan.id == plan_id).first()
    if not plan:
        raise HTTPException(status_code=404, detail="Plan not found")
    db.delete(plan)
    db.commit()
    return {"message": "Plan deleted"}


# ── Member Plans ───────────────────────────────────────────────────────────────

@router.get("/member/{member_id}")
def get_member_plans(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    workout_plans = db.query(WorkoutPlan).filter(
        (WorkoutPlan.member_id == member_id) | (WorkoutPlan.is_public == True)
    ).all()
    diet_plans = db.query(DietPlan).filter(
        (DietPlan.member_id == member_id) | (DietPlan.is_public == True)
    ).all()
    return {
        "workout_plans": [_build_workout_response(p) for p in workout_plans],
        "diet_plans": [_build_diet_response(p) for p in diet_plans],
    }


# ── Progress Tracking ──────────────────────────────────────────────────────────

@router.post("/progress", response_model=PlanProgressResponse)
def log_progress(
    progress_data: PlanProgressCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    member = db.query(Member).filter(Member.user_id == current_user.id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member profile not found")

    progress = PlanProgress(
        member_id=member.id,
        plan_id=progress_data.plan_id,
        plan_type=progress_data.plan_type,
        exercise_name=progress_data.exercise_name,
        completed=progress_data.completed,
        feedback=progress_data.feedback,
        rating=progress_data.rating,
    )
    db.add(progress)
    db.commit()
    db.refresh(progress)
    return progress


@router.get("/progress/member/{member_id}", response_model=List[PlanProgressResponse])
def get_member_progress(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return db.query(PlanProgress).filter(PlanProgress.member_id == member_id).order_by(PlanProgress.logged_at.desc()).all()
