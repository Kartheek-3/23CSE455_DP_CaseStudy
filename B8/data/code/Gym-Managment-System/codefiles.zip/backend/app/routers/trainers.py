from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from typing import List, Optional

from ..database import get_db
from ..models import User, Trainer, TrainerAvailability, UserRole
from ..schemas.trainers import (
    TrainerCreate, TrainerUpdate, TrainerResponse,
    TrainerAvailabilityCreate, TrainerAvailabilityResponse, TrainerRatingCreate
)
from ..core.security import get_password_hash
from ..routers.auth import get_current_user, get_current_admin
from ..utils.notifications import send_email

router = APIRouter()


def _build_trainer_response(trainer: Trainer) -> dict:
    return {
        "id": trainer.id,
        "user_id": trainer.user_id,
        "specialization": trainer.specialization,
        "bio": trainer.bio,
        "hourly_rate": trainer.hourly_rate,
        "years_experience": trainer.years_experience,
        "rating": trainer.rating,
        "rating_count": trainer.rating_count,
        "full_name": trainer.user.full_name,
        "email": trainer.user.email,
        "phone": trainer.user.phone,
        "is_active": trainer.user.is_active,
        "profile_picture": trainer.user.profile_picture,
    }


@router.get("/", response_model=List[TrainerResponse])
def list_trainers(
    skip: int = 0,
    limit: int = 100,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Trainer).join(User).filter(User.is_active == True)
    if search:
        query = query.filter(
            User.full_name.ilike(f"%{search}%") | Trainer.specialization.ilike(f"%{search}%")
        )
    trainers = query.offset(skip).limit(limit).all()
    return [_build_trainer_response(t) for t in trainers]


@router.post("/", response_model=TrainerResponse)
def create_trainer(
    trainer_data: TrainerCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    existing = db.query(User).filter(User.email == trainer_data.email).first()
    if existing:
        raise HTTPException(status_code=400, detail="Email already registered")

    new_user = User(
        email=trainer_data.email,
        password_hash=get_password_hash(trainer_data.password),
        full_name=trainer_data.full_name,
        phone=trainer_data.phone,
        role=UserRole.TRAINER,
    )
    db.add(new_user)
    db.flush()

    new_trainer = Trainer(
        user_id=new_user.id,
        specialization=trainer_data.specialization,
        bio=trainer_data.bio,
        hourly_rate=trainer_data.hourly_rate,
        years_experience=trainer_data.years_experience,
    )
    db.add(new_trainer)
    db.commit()
    db.refresh(new_trainer)

    background_tasks.add_task(
        send_email,
        new_user.email,
        "Welcome to GymManager – Trainer Account",
        f"<h2>Welcome {new_user.full_name}!</h2><p>Your trainer account has been created. Login with your email and the password provided by the admin.</p>",
    )

    return _build_trainer_response(new_trainer)


@router.get("/me")
def get_my_trainer_profile(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    trainer = db.query(Trainer).filter(Trainer.user_id == current_user.id).first()
    if not trainer:
        raise HTTPException(status_code=404, detail="Trainer profile not found")
    return _build_trainer_response(trainer)


@router.get("/{trainer_id}", response_model=TrainerResponse)
def get_trainer(
    trainer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    trainer = db.query(Trainer).filter(Trainer.id == trainer_id).first()
    if not trainer:
        raise HTTPException(status_code=404, detail="Trainer not found")
    return _build_trainer_response(trainer)


@router.put("/{trainer_id}", response_model=TrainerResponse)
def update_trainer(
    trainer_id: int,
    update_data: TrainerUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    trainer = db.query(Trainer).filter(Trainer.id == trainer_id).first()
    if not trainer:
        raise HTTPException(status_code=404, detail="Trainer not found")

    # Only admin or the trainer themselves
    if current_user.role not in [UserRole.ADMIN] and trainer.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")

    if update_data.full_name:
        trainer.user.full_name = update_data.full_name
    if update_data.phone:
        trainer.user.phone = update_data.phone
    if update_data.specialization is not None:
        trainer.specialization = update_data.specialization
    if update_data.bio is not None:
        trainer.bio = update_data.bio
    if update_data.hourly_rate is not None:
        trainer.hourly_rate = update_data.hourly_rate
    if update_data.years_experience is not None:
        trainer.years_experience = update_data.years_experience

    db.commit()
    db.refresh(trainer)
    return _build_trainer_response(trainer)


@router.delete("/{trainer_id}")
def delete_trainer(
    trainer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    trainer = db.query(Trainer).filter(Trainer.id == trainer_id).first()
    if not trainer:
        raise HTTPException(status_code=404, detail="Trainer not found")
    trainer.user.is_active = False
    db.commit()
    return {"message": "Trainer deactivated successfully"}


@router.post("/{trainer_id}/availability", response_model=TrainerAvailabilityResponse)
def set_availability(
    trainer_id: int,
    avail_data: TrainerAvailabilityCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    trainer = db.query(Trainer).filter(Trainer.id == trainer_id).first()
    if not trainer:
        raise HTTPException(status_code=404, detail="Trainer not found")
    if current_user.role not in [UserRole.ADMIN] and trainer.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")

    avail = TrainerAvailability(
        trainer_id=trainer_id,
        day_of_week=avail_data.day_of_week,
        start_time=avail_data.start_time,
        end_time=avail_data.end_time,
    )
    db.add(avail)
    db.commit()
    db.refresh(avail)
    return avail


@router.get("/{trainer_id}/availability", response_model=List[TrainerAvailabilityResponse])
def get_availability(
    trainer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return db.query(TrainerAvailability).filter(TrainerAvailability.trainer_id == trainer_id).all()


@router.post("/rate")
def rate_trainer(
    rating_data: TrainerRatingCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != UserRole.MEMBER:
        raise HTTPException(status_code=403, detail="Only members can rate trainers")
    trainer = db.query(Trainer).filter(Trainer.id == rating_data.trainer_id).first()
    if not trainer:
        raise HTTPException(status_code=404, detail="Trainer not found")

    # Recalculate average rating
    total = trainer.rating * trainer.rating_count + rating_data.rating
    trainer.rating_count += 1
    trainer.rating = round(total / trainer.rating_count, 2)
    db.commit()
    return {"message": "Rating submitted", "new_rating": trainer.rating}
