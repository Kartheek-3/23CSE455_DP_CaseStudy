from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from ..database import get_db
from ..models import User, Notification, UserRole
from ..schemas.notifications import NotificationResponse, NotificationSettingsUpdate
from ..routers.auth import get_current_user, get_current_admin

router = APIRouter()


@router.get("/", response_model=List[NotificationResponse])
def get_my_notifications(
    skip: int = 0,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return (
        db.query(Notification)
        .filter(Notification.user_id == current_user.id)
        .order_by(Notification.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


@router.get("/all", response_model=List[NotificationResponse])
def get_all_notifications(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin),
):
    return (
        db.query(Notification)
        .order_by(Notification.created_at.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


@router.put("/settings")
def update_notification_settings(
    settings_data: NotificationSettingsUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if settings_data.sms_opt_in is not None:
        current_user.sms_opt_in = settings_data.sms_opt_in
    if settings_data.email_class_reminder is not None:
        current_user.email_class_reminder = settings_data.email_class_reminder
    if settings_data.sms_class_reminder is not None:
        current_user.sms_class_reminder = settings_data.sms_class_reminder
    db.commit()
    return {"message": "Notification settings updated"}


@router.get("/settings")
def get_notification_settings(
    current_user: User = Depends(get_current_user),
):
    return {
        "sms_opt_in": current_user.sms_opt_in,
        "email_class_reminder": current_user.email_class_reminder,
        "sms_class_reminder": current_user.sms_class_reminder,
    }
