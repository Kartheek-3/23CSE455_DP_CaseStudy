from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks, Query
from sqlalchemy.orm import Session
from sqlalchemy import and_
from typing import List, Optional
from datetime import datetime, timedelta

from ..database import get_db
from ..models import User, Class, Booking, Member, Trainer, Waitlist, BookingStatus, UserRole
from ..schemas.classes import (
    ClassCreate, ClassUpdate, ClassResponse,
    BookingCreate, BookingResponse, WaitlistResponse
)
from ..routers.auth import get_current_user, get_current_admin, get_current_trainer
from ..utils.notifications import send_email, send_sms

router = APIRouter()


def _build_class_response(cls: Class) -> dict:
    trainer_name = cls.trainer.user.full_name if cls.trainer and cls.trainer.user else None
    return {
        "id": cls.id,
        "name": cls.name,
        "description": cls.description,
        "trainer_id": cls.trainer_id,
        "max_capacity": cls.max_capacity,
        "current_enrolled": cls.current_enrolled,
        "duration_minutes": cls.duration_minutes,
        "start_time": cls.start_time,
        "end_time": cls.end_time,
        "class_type": cls.class_type,
        "difficulty_level": cls.difficulty_level,
        "location": cls.location,
        "is_recurring": cls.is_recurring,
        "recurring_rule": cls.recurring_rule,
        "is_active": cls.is_active,
        "trainer_name": trainer_name,
    }


@router.get("/", response_model=List[ClassResponse])
def list_classes(
    skip: int = 0,
    limit: int = 100,
    class_type: Optional[str] = None,
    difficulty: Optional[str] = None,
    trainer_id: Optional[int] = None,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    available_only: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    query = db.query(Class).filter(Class.is_active == True)
    if class_type:
        query = query.filter(Class.class_type == class_type)
    if difficulty:
        query = query.filter(Class.difficulty_level == difficulty)
    if trainer_id:
        query = query.filter(Class.trainer_id == trainer_id)
    if from_date:
        query = query.filter(Class.start_time >= from_date)
    if to_date:
        query = query.filter(Class.start_time <= to_date)
    if available_only:
        query = query.filter(Class.current_enrolled < Class.max_capacity)

    classes = query.order_by(Class.start_time).offset(skip).limit(limit).all()
    return [_build_class_response(c) for c in classes]


@router.post("/", response_model=ClassResponse)
def create_class(
    class_data: ClassCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    # Conflict check: trainer cannot have two classes at same time
    conflict = db.query(Class).filter(
        and_(
            Class.trainer_id == class_data.trainer_id,
            Class.is_active == True,
            Class.start_time < class_data.end_time,
            Class.end_time > class_data.start_time,
        )
    ).first()
    if conflict:
        raise HTTPException(status_code=400, detail=f"Trainer has a conflicting class: {conflict.name}")

    new_class = Class(**class_data.model_dump())
    db.add(new_class)
    db.commit()
    db.refresh(new_class)
    return _build_class_response(new_class)


@router.get("/schedule/trainer/{trainer_id}", response_model=List[ClassResponse])
def trainer_schedule(
    trainer_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    classes = (
        db.query(Class)
        .filter(Class.trainer_id == trainer_id, Class.is_active == True)
        .order_by(Class.start_time)
        .all()
    )
    return [_build_class_response(c) for c in classes]


@router.get("/schedule/member/{member_id}", response_model=List[BookingResponse])
def member_schedule(
    member_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    bookings = (
        db.query(Booking)
        .filter(
            Booking.member_id == member_id,
            Booking.status == BookingStatus.BOOKED,
        )
        .all()
    )
    result = []
    for b in bookings:
        result.append({
            "id": b.id,
            "class_id": b.class_id,
            "member_id": b.member_id,
            "status": b.status,
            "booked_at": b.booked_at,
            "cancelled_at": b.cancelled_at,
            "class_name": b.class_obj.name if b.class_obj else None,
            "class_start_time": b.class_obj.start_time if b.class_obj else None,
        })
    return result


@router.get("/{class_id}", response_model=ClassResponse)
def get_class(
    class_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    cls = db.query(Class).filter(Class.id == class_id).first()
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")
    return _build_class_response(cls)


@router.put("/{class_id}", response_model=ClassResponse)
def update_class(
    class_id: int,
    update_data: ClassUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    cls = db.query(Class).filter(Class.id == class_id).first()
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")

    for field, value in update_data.model_dump(exclude_unset=True).items():
        setattr(cls, field, value)

    db.commit()
    db.refresh(cls)
    return _build_class_response(cls)


@router.delete("/{class_id}")
def delete_class(
    class_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    cls = db.query(Class).filter(Class.id == class_id).first()
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")

    cls.is_active = False

    # Notify booked members
    bookings = db.query(Booking).filter(
        Booking.class_id == class_id,
        Booking.status == BookingStatus.BOOKED
    ).all()
    for booking in bookings:
        booking.status = BookingStatus.CANCELLED
        if booking.member and booking.member.user:
            background_tasks.add_task(
                send_email,
                booking.member.user.email,
                f"Class Cancelled: {cls.name}",
                f"<p>We're sorry, the class <strong>{cls.name}</strong> scheduled for {cls.start_time} has been cancelled.</p>",
            )

    db.commit()
    return {"message": "Class cancelled and members notified"}


@router.post("/{class_id}/book", response_model=BookingResponse)
def book_class(
    class_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    cls = db.query(Class).filter(Class.id == class_id, Class.is_active == True).first()
    if not cls:
        raise HTTPException(status_code=404, detail="Class not found")

    if cls.start_time < datetime.utcnow():
        raise HTTPException(status_code=400, detail="Cannot book a past class")

    member = db.query(Member).filter(Member.user_id == current_user.id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member profile not found")

    # Check existing booking
    existing = db.query(Booking).filter(
        Booking.class_id == class_id,
        Booking.member_id == member.id,
        Booking.status == BookingStatus.BOOKED,
    ).first()
    if existing:
        raise HTTPException(status_code=400, detail="Already booked for this class")

    # Check overlap with other bookings
    member_bookings = db.query(Booking).filter(
        Booking.member_id == member.id,
        Booking.status == BookingStatus.BOOKED,
    ).all()
    for b in member_bookings:
        if b.class_obj and b.class_obj.start_time < cls.end_time and b.class_obj.end_time > cls.start_time:
            raise HTTPException(status_code=400, detail=f"Overlaps with existing booking: {b.class_obj.name}")

    # Check capacity
    if cls.current_enrolled >= cls.max_capacity:
        # Add to waitlist
        position = db.query(Waitlist).filter(Waitlist.class_id == class_id).count() + 1
        waitlist_entry = Waitlist(class_id=class_id, member_id=member.id, position=position)
        db.add(waitlist_entry)
        db.commit()
        raise HTTPException(status_code=200, detail=f"Class full. Added to waitlist at position {position}")

    booking = Booking(class_id=class_id, member_id=member.id, status=BookingStatus.BOOKED)
    db.add(booking)
    cls.current_enrolled += 1
    db.commit()
    db.refresh(booking)

    # Notifications
    background_tasks.add_task(
        send_email,
        current_user.email,
        f"Booking Confirmed: {cls.name}",
        f"<h3>Booking Confirmed!</h3><p>You're booked for <strong>{cls.name}</strong> on {cls.start_time.strftime('%B %d, %Y at %I:%M %p')}.</p><p>Location: {cls.location}</p>",
    )
    if current_user.sms_opt_in and current_user.phone:
        background_tasks.add_task(
            send_sms,
            current_user.phone,
            f"Booking confirmed: {cls.name} on {cls.start_time.strftime('%b %d at %I:%M %p')}",
        )

    return {
        "id": booking.id,
        "class_id": booking.class_id,
        "member_id": booking.member_id,
        "status": booking.status,
        "booked_at": booking.booked_at,
        "cancelled_at": booking.cancelled_at,
        "class_name": cls.name,
        "class_start_time": cls.start_time,
    }


@router.delete("/{class_id}/book")
def cancel_booking(
    class_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    member = db.query(Member).filter(Member.user_id == current_user.id).first()
    if not member:
        raise HTTPException(status_code=404, detail="Member profile not found")

    booking = db.query(Booking).filter(
        Booking.class_id == class_id,
        Booking.member_id == member.id,
        Booking.status == BookingStatus.BOOKED,
    ).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")

    cls = booking.class_obj
    booking.status = BookingStatus.CANCELLED
    booking.cancelled_at = datetime.utcnow()
    cls.current_enrolled = max(0, cls.current_enrolled - 1)

    # Promote from waitlist
    next_in_line = (
        db.query(Waitlist)
        .filter(Waitlist.class_id == class_id, Waitlist.notified == False)
        .order_by(Waitlist.position)
        .first()
    )
    if next_in_line:
        next_in_line.notified = True
        waitlist_member = next_in_line.member
        if waitlist_member and waitlist_member.user:
            background_tasks.add_task(
                send_email,
                waitlist_member.user.email,
                f"Spot Available: {cls.name}",
                f"<p>A spot has opened in <strong>{cls.name}</strong>. Book now before it fills up!</p>",
            )

    db.commit()
    return {"message": "Booking cancelled successfully"}


@router.get("/{class_id}/roster")
def get_class_roster(
    class_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_trainer),
):
    bookings = db.query(Booking).filter(
        Booking.class_id == class_id,
        Booking.status == BookingStatus.BOOKED,
    ).all()
    return [
        {
            "booking_id": b.id,
            "member_id": b.member_id,
            "member_name": b.member.user.full_name if b.member and b.member.user else None,
            "email": b.member.user.email if b.member and b.member.user else None,
            "booked_at": b.booked_at,
        }
        for b in bookings
    ]
