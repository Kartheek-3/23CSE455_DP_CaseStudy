# Prompt 02 — Architecture Reconstruction and Component Collaboration Map

## Role and context

Act as a software architecture reverse engineer. Analyze the original B10 Gym Management System at `data/code/Gym-Managment-System/`, not an assumed evolved version.

## Objective

Reconstruct the real architecture from the source and show how a request moves through the Angular frontend, HTTP API, FastAPI router, dependency layer, ORM model, and database.

## Required source inspection

At minimum, inspect and cite exact file paths and line ranges for:
- `backend/app/main.py`
- `backend/app/database.py`
- `backend/app/models.py`
- `backend/app/routers/auth.py`
- `backend/app/routers/members.py`
- `backend/app/routers/trainers.py`
- `backend/app/routers/classes.py`
- `backend/app/routers/attendance.py`
- `backend/app/routers/plans.py`
- `backend/app/routers/notifications.py`
- `backend/app/utils/notifications.py`
- `frontend/src/app/app.config.ts`
- `frontend/src/app/app.routes.ts`
- representative components under `frontend/src/app/components/`
- representative services under `frontend/src/app/services/`

## Questions to answer

1. How are routers registered and what URL prefixes are used?
2. How do FastAPI endpoints obtain a database session and current-user/role information?
3. Which SQLAlchemy entities and relationships form the core domain?
4. How do Angular components obtain services and call the API?
5. How is authentication state held and shared?
6. What notification paths are visible in the baseline (database notification endpoints, email/SMS utilities, background tasks)?
7. Which behavior lives in routers versus models, schemas, services, or utilities?
8. Where does the architecture mix transport, authorization, persistence, and business logic?
9. What is observed versus inferred? Mark uncertain edges in the architecture diagram.

## Required outputs

- Layered architecture diagram in Mermaid.
- Request-sequence example for one existing feature, preferably workout-plan creation or QR attendance.
- Component/collaboration table with exact source paths and line ranges.
- Data model summary.
- Architectural strengths, risks, and unresolved questions.

Do not claim a service/repository layer exists unless the source actually contains it. Do not infer event-driven Observer architecture merely because email/SMS notifications exist.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
