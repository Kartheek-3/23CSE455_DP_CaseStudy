# Prompt 01 — Baseline Repository Identification and Reproducibility

## Role

Act as a senior software architect, code archaeologist, design-pattern researcher, and reproducibility auditor. Investigate the **Gym Management System** supplied in the B10 team archive.

## Project identity

- Case study: 23CSE455 Design Pattern Case Study, Team B10.
- Application: `Gym-Managment-System`.
- Backend: Python FastAPI with SQLAlchemy and a database session dependency.
- Frontend: Angular 17 standalone components, RxJS, Angular dependency injection.
- Original source location in the team folder: `data/code/Gym-Managment-System/`.
- The source archive contains a Git repository and baseline application files. Inspect the actual history/metadata before claiming a specific commit is the official baseline.

## Objective

Establish a reproducible record of the original application before discussing patterns or implementing changes.

## Required investigation

1. Identify the repository root, source version/commit, and whether the included `.git` data can establish the exact version.
2. Inspect `README.md`, `backend/requirements.txt`, `frontend/package.json`, `frontend/package-lock.json`, configuration files, and the requirements document at `.kiro/specs/gym-management-system/requirements.md`.
3. Record the application scope: users/roles, members, trainers, classes/bookings, attendance, workout/diet plans, payments, and notifications.
4. Identify setup prerequisites and commands from the repository itself. If a command is not documented or cannot be tested, mark it unverified rather than guessing.
5. Identify database configuration and whether the default runtime database is SQLite or another configured database. Do not print secrets.
6. Inventory source modules inspected and files omitted from analysis.
7. Preserve the baseline unchanged and propose a reproducible way to compare it with `Part2/code/Gym-Managment-System`.

## Deliverables

- Baseline identification table.
- Environment/version table.
- Source/module inventory.
- Setup and test commands with verification status.
- Limitations and missing evidence.
- A short baseline freeze procedure.

## Output constraints

Do not identify design patterns in this prompt; that belongs to the separate pattern-discovery task. Do not claim the app ran successfully unless a run was performed and recorded.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
