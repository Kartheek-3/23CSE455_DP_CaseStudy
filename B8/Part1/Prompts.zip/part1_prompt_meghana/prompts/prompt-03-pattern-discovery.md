# Prompt 03 — Baseline Pattern Discovery With Source-Code Proof

## Role

Act as a skeptical design-pattern analyst. Your task is to identify patterns that are genuinely implemented in the original Gym Management System, not patterns that would be convenient to add later.

## Source boundary

Only inspect `data/code/Gym-Managment-System/`. The baseline includes Angular 17 frontend services/components and a FastAPI/SQLAlchemy backend. Treat all Part 2 feature descriptions as future changes unless the baseline source itself proves they already exist.

## Pattern families to examine

- GoF creational, structural, and behavioral patterns.
- GRASP principles where relevant.
- Framework/architectural mechanisms such as dependency injection, ORM/Active Record-like mapping, routing, interceptors, guards, and reactive streams. Keep these categories separate from GoF patterns.

## Mandatory candidate protocol

For each candidate:
1. Name one specific collaboration/instance, not just a general technology.
2. Map every applicable pattern role to the real class/interface/function.
3. Give exact file path and line range for each participant.
4. Explain the interaction sequence that proves the pattern.
5. Explain which defining properties are present and which are absent.
6. Assign `confirmed`, `rejected`, or `uncertain`.
7. Record a concise reason and what additional evidence could change the verdict.

## Candidates worth investigating (not pre-approved)

- FastAPI `Depends(get_db)` and current-user dependencies.
- Angular services decorated with `@Injectable({ providedIn: 'root' })` and constructor injection.
- `AuthService`'s `BehaviorSubject` / `currentUser$` state publication.
- `PlansService` and `NotificationsService`.
- `BackgroundTasks` plus direct `send_email`/`send_sms` calls.
- Any reusable workflow or polymorphic behavior actually found in source.

## Required outputs

- `patterns.csv` rows using the required assignment columns.
- A separate candidate-review table that includes rejected and uncertain candidates without counting them as confirmed.
- A source-evidence index.
- A pattern architecture/collaboration diagram for confirmed candidates only.
- A confidence/limitation statement.

Do not count every Angular service as a separate GoF Singleton just because it is root-provided. Do not call the notification implementation Observer unless the source shows publisher/subscriber registration or an equivalent independent event-reaction mechanism. Do not call FastAPI dependency injection a GoF pattern without explaining the classification boundary.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
