# Prompt 04 — Build and Audit Part 1 Pattern Inventory and Counts

## Objective

Create the Part 1 pattern inventory and count summary for the **original source version only**. This is a data-quality task; do not invent pattern instances to make the table look complete.

## Required files and schemas

### `patterns.csv`

Use exactly these columns from the assignment:
- `source_version`
- `pattern_name`
- `pattern_type`
- `instance_name`
- `participant_roles`
- `source_locations`
- `intent_and_evidence`

One row represents one confirmed pattern collaboration in one source version. Include all applicable participants, not only a central class. Use actual relative paths and line ranges.

### `pattern_counts.csv`

Use exactly:
- `source_version`
- `summary`
- `pattern_name`
- `count`

Use `summary=per_pattern` for each confirmed pattern's instance count. Add `total_pattern_types` and `total_pattern_instances` rows as specified in the course instructions. Count collaborations, not participant classes. Do not count rejected/uncertain candidates.

## Procedure

1. Freeze the exact baseline source identifier.
2. Re-check each candidate against source.
3. Verify every participant and line range.
4. Ensure each inventory row maps to one distinct collaboration.
5. Derive counts mechanically from confirmed rows.
6. Compare the inventory against the architecture diagram and report.
7. Validate CSV headers, UTF-8 encoding, quoting, relative paths, and row consistency.

## Output

Provide the two CSV files, a validation note, and a list of candidates deliberately excluded from confirmed counts with reasons. If the available source does not prove a pattern, leave it out of confirmed counts and explain the uncertainty separately.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
