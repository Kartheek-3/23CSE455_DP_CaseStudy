# Result 02 — Baseline Architecture Reconstruction

**Status:** Architecture summary grounded in the supplied baseline source. Diagram is a conceptual reconstruction; sequence execution was not run.

## 1. High-level architecture

```mermaid
flowchart TD
  UI[Angular standalone components] --> SVC[Angular services]
  SVC --> HTTP[Angular HttpClient]
  HTTP --> API[FastAPI application]
  API --> ROUTER[Feature routers]
  ROUTER --> DEP[FastAPI Depends: database and user/role dependencies]
  DEP --> ORM[SQLAlchemy Session and ORM models]
  ORM --> DB[(Configured database)]
  ROUTER --> BG[FastAPI BackgroundTasks]
  BG --> MSG[Email/SMS utilities]
```

The actual database engine must be confirmed from `backend/app/database.py` and runtime configuration; the diagram intentionally says “configured database” rather than assuming a deployment database.

## 2. Router registration

`backend/app/main.py`, lines 28–35, registers routers with prefixes:
- `/api/auth`
- `/api/members`
- `/api/trainers`
- `/api/classes`
- `/api/attendance`
- `/api/payments`
- `/api/plans`
- `/api/notifications`

## 3. Database and authorization dependencies

`backend/app/database.py` defines `get_db()` and `get_async_db()` (around lines 29 and 36). Feature routers import `get_db` and use `db: Session = Depends(get_db)`. For example, `backend/app/routers/plans.py`, lines 53–59, injects a session and a current trainer dependency into workout-plan creation. Authentication/role dependencies are defined in `backend/app/routers/auth.py` (including `get_current_user`, `get_current_admin`, `get_current_trainer`, and `get_current_member` around lines 90–112).

## 4. Persistence/domain structure

`backend/app/models.py` defines SQLAlchemy entities for identity/roles, member and trainer profiles, trainer availability, classes, bookings, waitlists, attendance, subscription plans, payments, workout and diet plans, progress, and notifications. These ORM classes and their relationships form the persistent domain model. The separate schema directory provides API request/response models.

## 5. Frontend dependency flow

`frontend/src/app/app.config.ts`, lines 1–12, configures routing and `provideHttpClient(withInterceptors([authInterceptor]))`. `frontend/src/app/services/auth.service.ts`, lines 8–14, declares `AuthService` as root-provided and receives `HttpClient` and `Router` through constructor injection. `PlansService` and `NotificationsService` use the same root-provided service convention. `PlansComponent` receives `AuthService`, `PlansService`, and `MembersService` in its constructor (around lines 422–426) and uses those services to fetch and save plan data.

## 6. Existing notification flow

`backend/app/routers/plans.py`, around lines 81–90, adds a direct `send_email` call to FastAPI `BackgroundTasks` after a workout plan is created for a member. `backend/app/utils/notifications.py` contains email/SMS delivery helpers. The existence of multiple delivery functions is not by itself proof of an Observer pattern; the baseline path shown here is a direct scheduled side effect.

## 7. Architectural observations

- Responsibilities are split into routers, schemas, ORM models, utilities, and Angular services/components.
- Some business logic and notification side effects are located directly in router functions.
- Framework-provided dependency injection is visible on both backend and frontend.
- The frontend uses service classes to centralize HTTP calls.
- A dedicated backend application service/repository layer is not established by the inspected examples and should not be claimed without further source evidence.

## 8. Verification still needed

Build/run commands, a live request trace, database schema/runtime selection, and complete route authorization testing remain to be captured in the final evidence package.
