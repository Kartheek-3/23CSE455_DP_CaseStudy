# Result 03 — Baseline Pattern Discovery and Evidence Review

**Source boundary:** `data/code/Gym-Managment-System/` only.

This is a conservative candidate review. The course requires actual collaborations and evidence, not a pattern name inferred from a framework annotation.

## 1. Candidate review

| Candidate | Preliminary verdict | Source evidence | Reason / caveat |
|---|---|---|---|
| Dependency injection for database session | Confirmed as framework DI mechanism; classify separately from GoF | `backend/app/database.py` (`get_db`, around line 29); `backend/app/routers/plans.py` (lines 53–59) | The endpoint declares `Depends(get_db)` and receives a session rather than constructing one inline. This is FastAPI DI, not a GoF pattern. |
| Angular constructor dependency injection | Confirmed as framework DI mechanism; classify separately from GoF | `frontend/src/app/app.config.ts`, lines 1–12; `frontend/src/app/services/auth.service.ts`, lines 8–14; `frontend/src/app/components/plans/plans.component.ts`, lines 422–426 | Dependencies are supplied by Angular's injector. Framework mechanism, not automatically a GoF pattern. |
| Root-provided Angular service / Singleton | Candidate; avoid counting as confirmed GoF Singleton without scope proof | `frontend/src/app/services/auth.service.ts`, lines 8–12; `plans.service.ts`, lines 7–11; `notifications.service.ts`, lines 7–11 | `providedIn: 'root'` normally yields an app-root service instance. It is Angular DI lifecycle behavior, not a manually enforced GoF Singleton; do not count every service as a separate Singleton pattern by default. |
| RxJS Observer / publish-subscribe in auth state | Plausible candidate; verify full subscriber interactions | `frontend/src/app/services/auth.service.ts`, lines 11–12 and 45, 52 | `BehaviorSubject` publishes current-user state through `currentUser$`; the shown file updates the subject. A confirmed pattern row should cite actual subscribers in components/guards and explain the collaboration. |
| Observer for baseline notifications | Not confirmed from inspected evidence | `backend/app/routers/plans.py`, lines 81–90; `backend/app/utils/notifications.py` | Direct `BackgroundTasks.add_task(send_email, ...)` shows a direct side effect, not an independently subscribed observer set. |
| Strategy for baseline workout recommendations | Not found in inspected baseline evidence | `backend/app/routers/plans.py`; `backend/app/models.py`, `WorkoutPlan` around lines 235–254 | The baseline stores/CRUDs plan data. No six goal-specific interchangeable strategy classes are present in this baseline archive. |
| Factory for workout-goal strategy selection | Not found in inspected baseline evidence | Baseline `backend/app/routers/plans.py` and source inventory | Goal-strategy factory belongs to the reported Part 2 change and should not be backdated into Part 1. |
| ORM/domain mapping | Confirmed as framework/architectural mechanism | `backend/app/models.py` | SQLAlchemy models map tables and relationships. Distinguish this from GoF patterns. |

## 2. Recommended Part 1 recording rule

The final `patterns.csv` should contain only collaborations that satisfy the team's adopted pattern definition and are supported by exact participants and line ranges. If the instructor's inventory is intended to contain only GoF/GRASP design patterns, keep framework DI and ORM observations in the architecture report or a separate rejected/uncertain candidate log rather than silently counting them as GoF instances.

The RxJS case deserves additional subscriber evidence before confirmation. If a subscriber cannot be located, leave the candidate uncertain or describe the subject/observable mechanism without claiming a complete application-level Observer collaboration.

## 3. Source evidence locations to recheck

- `backend/app/database.py`
- `backend/app/routers/plans.py`
- `backend/app/routers/auth.py`
- `backend/app/utils/notifications.py`
- `backend/app/models.py`
- `frontend/src/app/app.config.ts`
- `frontend/src/app/services/auth.service.ts`
- `frontend/src/app/services/plans.service.ts`
- `frontend/src/app/services/notifications.service.ts`
- `frontend/src/app/components/plans/plans.component.ts`

## 4. Result status

This candidate review is useful for planning the inventory, but the final CSV still requires a fresh exact line-range audit and a decision about whether the course's pattern-count rubric includes framework mechanisms. No unsupported pattern counts are asserted here.
