# Result 04 — Part 1 CSV and Evidence Audit Plan

The baseline archive contains placeholder files for `Part1/patterns.csv` and `Part1/Pattern_count.csv`; both are empty in the uploaded ZIP. Therefore, no existing confirmed-pattern inventory or valid count can be recovered from those files.

## Required schema

### `patterns.csv`

`source_version,pattern_name,pattern_type,instance_name,participant_roles,source_locations,intent_and_evidence`

### `pattern_counts.csv`

`source_version,summary,pattern_name,count`

## Current status

- Baseline source files exist and can be inspected.
- The uploaded inventory and count files are empty.
- Pattern candidates need a final human decision and precise line-range validation.
- A count should not be populated until confirmed rows exist.
- Rejected and uncertain candidates should remain in a separate audit note, not in confirmed totals.

## Validation checklist

1. CSV header names match the course instructions exactly.
2. `source_version` consistently identifies the original source version.
3. `participant_roles` maps each role to actual code, including combined/missing roles.
4. `source_locations` uses relative paths and exact line ranges.
5. Every row has one unique collaboration/instance.
6. Counts are derived from confirmed rows only.
7. The report, diagram, and CSV inventory agree.
8. UTF-8 encoding and CSV quoting are valid.

## No fabricated counts

This result intentionally does not generate numeric confirmed-pattern counts from uncertain candidates. Once the final candidate decisions are made, the count file should be derived from `patterns.csv` rather than manually guessed.
