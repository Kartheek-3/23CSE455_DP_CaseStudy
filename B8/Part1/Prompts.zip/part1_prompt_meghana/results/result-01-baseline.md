# Result 01 — Baseline Repository Identification and Reproducibility

**Status:** Source-grounded inspection of the uploaded B10 ZIP. Runtime setup has not been executed in this analysis.

## 1. Baseline boundary

The archive contains `23CSE455_DP_CaseStudy_B10/data/code/Gym-Managment-System/` and its own `.gitignore`, application code, frontend lockfile/package metadata, backend requirements, and a Kiro requirements document. The top-level team archive also contains an outer `.git/` directory. The exact source commit should be read from the included Git metadata before it is recorded in the final README; this result does not invent a commit hash.

The baseline path to preserve is:

`data/code/Gym-Managment-System/`

The user-reported evolved path is:

`Part2/code/Gym-Managment-System/`

The uploaded source archive inspected here does **not** contain the evolved directory. The two versions therefore cannot yet be compared by source diff in this artifact.

## 2. Stack evidence

| Area | Finding from supplied files | Evidence |
|---|---|---|
| Frontend | Angular 17 dependencies, TypeScript, RxJS | `frontend/package.json` |
| Frontend bootstrapping | Standalone `ApplicationConfig`, router and HTTP client providers | `frontend/src/app/app.config.ts`, lines 1–12 |
| Backend | FastAPI application with routers registered under `/api/...` prefixes | `backend/app/main.py`, lines 28–35 |
| Persistence | SQLAlchemy ORM entities and database-session helpers | `backend/app/models.py`; `backend/app/database.py` |
| API validation | Separate schema modules for plans, attendance, members, trainers, etc. | `backend/app/schemas/` |
| Notifications | In-app notification model/routes plus email/SMS utility functions and background-task use | `backend/app/models.py`; `backend/app/routers/notifications.py`; `backend/app/utils/notifications.py`; `backend/app/routers/plans.py` |
| Requirements | Functional scope and acceptance criteria | `.kiro/specs/gym-management-system/requirements.md` |

The package manifest specifies Angular packages at `^17.0.0`, RxJS `~7.8.0`, and TypeScript `~5.2.2`. Exact installed versions should be derived from the lockfile and toolchain, not from semver ranges alone.

## 3. Domain scope visible in the baseline

The SQLAlchemy model file defines `User`, `Member`, `Trainer`, `TrainerAvailability`, `Class`, `Booking`, `Waitlist`, `Attendance`, `SubscriptionPlan`, `Payment`, `WorkoutPlan`, `DietPlan`, `PlanProgress`, and `Notification` (see `backend/app/models.py`, approximately lines 41–306). The routers cover authentication, members, trainers, classes, attendance, payments, plans, and notifications.

## 4. Reproducibility actions still required

- Record the actual commit hash and working-tree state from the included Git repository.
- Record Python, pip, Node, npm, Angular CLI and database versions.
- Follow the repository README and backend requirements to set up the application.
- Run the backend health endpoint and frontend build; preserve commands and terminal output.
- Record the database configuration without exposing credentials.
- Save a baseline snapshot or commit reference before Part 2 changes.

## 5. Limits

No successful runtime/build/test result is claimed here. The baseline source was inspected statically; the evolved source was not included in the uploaded team ZIP.
