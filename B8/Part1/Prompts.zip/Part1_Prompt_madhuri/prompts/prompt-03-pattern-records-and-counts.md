# Prompt 03 — Pattern Records, UML, and Baseline Counts

Using the verified findings and actual source files, prepare draft Part 1 datasets.

Required `patterns.csv` columns:
source_version, pattern_name, pattern_type, instance_name, participant_roles, source_locations, intent_and_evidence

Required `pattern_counts.csv` columns:
source_version, summary, pattern_name, count

Tasks:
1. Create one patterns.csv row per confirmed pattern collaboration in the baseline source version.
2. Include all applicable participants, not just the main class. Map roles to actual classes/interfaces/functions/modules.
3. Include exact paths and line ranges for all participants.
4. Create per-pattern counts plus total_pattern_types and total_pattern_instances rows.
5. Report concrete participant classes and unique participant symbols separately for the report; count a shared symbol only once for unique symbols.
6. Keep rejected/uncertain candidates outside confirmed counts and summarize their reasons separately.
7. Recommend editable UML/class/sequence/component diagrams that reflect the verified source.
8. Explain the counting method and any limitations.

Rules:
- Use exact column names.
- Quote CSV cells containing commas correctly.
- Do not fabricate pattern records or counts.
- If a count cannot be computed from the evidence supplied, mark it pending verification instead of guessing.
- One collaboration with several concrete strategies can still be one Strategy instance.
