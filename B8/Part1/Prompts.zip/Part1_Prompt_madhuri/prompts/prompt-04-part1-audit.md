# Prompt 04 — Part 1 Evidence and Consistency Audit

Audit the Part 1 working package against the supplied source and faculty requirements.

Check:
- Repository/source version and environment details are recorded.
- Inspected scope and exclusions are explicit.
- All eight required functional areas are addressed.
- Every confirmed pattern has intent, actual participants, paths/line ranges, and evidence.
- Rejected/uncertain candidates have reasons.
- Pattern types, instances, participant classes, and unique symbols use the correct counting rules.
- `patterns.csv` and `pattern_counts.csv` use the required exact headers.
- Counts reconcile with confirmed pattern rows.
- UML diagrams match the code and have editable source files.
- LLM prompt/output records are genuine and human verification is documented.
- No unsupported pattern claims or fabricated test results remain.

Return a pass/fail/pending checklist with exact problems and corrective actions. Do not say an item passes unless the supplied files support that conclusion.
