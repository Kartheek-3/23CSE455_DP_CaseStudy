# Prompt 02 — Pattern Discovery Across the Eight Functional Areas

Analyze only the supplied source files and baseline version.

Areas:
- Member management
- Trainer management
- Class scheduling
- Subscriptions
- Attendance
- Workout plans
- Notifications
- Authentication

For each area:
1. Identify relevant actual classes, interfaces, methods, functions, modules, and files.
2. Identify candidate patterns and classify them as confirmed, rejected, or uncertain.
3. For each candidate, explain the pattern intent and why the source does or does not satisfy it.
4. Map every applicable role to an actual source symbol.
5. Give exact file paths and line ranges for every participant.
6. Explain the interaction: calls, delegation, subscriptions, object creation, dependency provision, or other relevant behavior.
7. Record alternative interpretations and how to verify them.
8. Note when the functionality or relevant code is absent from the supplied baseline.

Consider appropriate GoF patterns, GRASP, architecture patterns, concurrency patterns, and framework idioms. Do not force a pattern into every functional area.

Rules:
- A class name or LLM assertion alone is not proof.
- Do not count participant classes as separate pattern instances.
- Do not classify Angular DI as GoF Singleton merely because a service is root-provided.
- Never fabricate source locations. If line numbers cannot be checked, state that.
- Keep recommendations separate from findings.

Output:
A. Area-by-area findings
B. Confirmed pattern instance records
C. Rejected and uncertain candidates with reasons
D. Source evidence and verification plan
