# Result 03 — Part 1 CSV and UML Working Record

Status: [not run / draft / human-verified]
Prompt used: `prompts/prompt-03-pattern-records-and-counts.md`
Raw output path: [fill]

## Dataset paths
- `patterns.csv`:
- `pattern_counts.csv`:
- UML editable sources:
- Rendered diagrams:

## Reconciliation
- Distinct confirmed pattern types:
- Confirmed pattern instances:
- Concrete participant classes:
- Unique participant symbols:
- Rejected/uncertain candidates:
- Counts reconciled against source rows? [yes/no/pending]

Do not fill numerical values until calculated from verified records.
