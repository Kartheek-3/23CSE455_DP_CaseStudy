# Result 02 — Pattern Findings Working Record

Status: [not run / draft / human-verified]
Prompt used: `prompts/prompt-02-pattern-discovery.md`
Actual model/date: [fill after run]
Input files/commit: [fill]
Raw output path: [fill]

## Confirmed collaborations
[Add only source-verified instances, including roles, exact paths/lines, intent and evidence.]

## Rejected/uncertain candidates
[Record candidate, status, reason, missing evidence, and verification action.]

## Human verification
[For each material claim, record source/test evidence and correction.]
