# Result 01 — Architecture Working Record

Status: [not run / draft / human-verified]
Prompt used: `prompts/prompt-01-source-scope-and-architecture.md`
Actual model/date: [fill after run]
Input files/commit: [fill]
Raw output path: [fill]

## Verified environment and source facts
- Repository:
- Commit/snapshot:
- Framework/runtime:
- Database/backend:
- Run/test command and actual result:

## Architecture and flows
[Paste the actual LLM output or a concise faithful summary, then cite source paths/lines.]

## Human verification
- Claim checked:
- File/line evidence:
- Evaluation: correct / partially correct / incorrect / cannot confirm
- Correction:
