# Result 03 — Pattern Discovery Findings

## Candidate inventory
The case-study work identifies these representative collaborations for evidence review:

| Pattern candidate | Instance | Classification note |
|---|---|---|
| Singleton | AuthService | Angular root-provided service may have one instance per root injector; verify provider scope |
| Dependency Injection | FastAPI database session injection | Framework-supported DI idiom; inspect dependency provider and route signature |
| Singleton | PlansService | Verify Angular provider scope; do not infer from service name |
| Dependency Injection | Angular component constructor injection | Verify constructor-injected dependency and provider registration |
| Strategy | Workout recommendation strategy | Confirm common strategy contract and interchangeable recommendation algorithms |
| Strategy | Trainer assignment policy | Confirm policy interface/context delegates selection |
| Observer | Attendance event observer | Confirm subject publishes events to registered observers |
| Observer | Notification state observer | Confirm RxJS subject/observable subscription and state propagation |

## Classification discipline
Dependency Injection is an architectural/framework idiom, not a GoF pattern. Singleton may be container-scoped rather than a manually implemented GoF Singleton. Strategy and Observer require demonstrable collaboration, not merely similarly named classes.

## Status
The table is a candidate register. A candidate becomes confirmed only after its production source and exact lines have been checked. Do not report every candidate as a confirmed GoF pattern without that verification.
