# Result 05 — Part 1 Audit Checklist

Part 1 is ready for sign-off only when the following are reconciled:

- [ ] Baseline commit matches `837e2be2ef4e27baa93e9b42cecc790febd5f16c`.
- [ ] Every confirmed pattern has production-code evidence.
- [ ] `patterns.csv` uses the faculty's exact header.
- [ ] `pattern_counts.csv` totals are calculated from confirmed rows.
- [ ] Pattern types and instance names are consistent across report and diagrams.
- [ ] Dependency Injection and framework-managed Singleton claims are carefully qualified.
- [ ] Part 2 changes are not included in the baseline inventory.
- [ ] Unverified candidates are labelled rather than silently promoted.

No claim of a complete audit should be made until each checkbox is supported by repository inspection.
