# Result 02 — Baseline Architecture Summary

## Logical architecture

```text
Admin / Trainer / Member
          |
          v
Angular 17 Components
          |
          v
Angular Services / Router
          |
       HTTP API
          |
          v
FastAPI Routers
          |
          v
Backend Services / Schemas
          |
          v
SQLAlchemy Models / SQLite
```

## Responsibilities
- Angular components: render screens and handle user interactions.
- Angular services: centralize client-side API access and shared client logic.
- FastAPI routers: expose HTTP endpoints and coordinate request handling.
- Schemas: validate and shape request/response data.
- Models and database session: represent and persist application data.
- Role-based workflows: distinguish Admin, Trainer, and Member capabilities.

## Workflow examples
1. Member authentication: UI submits credentials; backend validates and returns authentication result; UI uses the result to expose the appropriate member experience.
2. Workout-plan access: member-facing UI requests plan data; backend retrieves the member's persisted plan; response is rendered by Angular.

## Evidence note
This is a logical architecture summary. Before final submission, attach exact source file and line references from the pinned baseline. Runtime sequence details should be confirmed from the actual routes and services.
