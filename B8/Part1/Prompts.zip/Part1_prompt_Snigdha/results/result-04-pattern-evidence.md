# Result 04 — Pattern Evidence Register

## Required CSV schema
`source_version,pattern_name,pattern_type,instance_name,participant_roles,source_locations,intent_and_evidence`

## Baseline version rule
Use exactly `Original code` for unmodified baseline rows.

## Instance naming
Use distinct names for each collaboration, for example:
- `AuthService`
- `FastAPI database session injection`
- `PlansService`
- `Angular component constructor injection`
- `Workout recommendation strategy`
- `Trainer assignment policy`
- `Attendance event observer`
- `Notification state observer`

## Evidence rule
`source_locations` must identify production code only. Use exact path and line range after checking the pinned repository. Do not cite a README, test, or comment as the only proof of a production pattern.

## Classification note
Keep Dependency Injection separate from GoF categories unless the faculty's prescribed taxonomy explicitly assigns it a category. Use one consistent convention in all CSVs and explain it in the README.
