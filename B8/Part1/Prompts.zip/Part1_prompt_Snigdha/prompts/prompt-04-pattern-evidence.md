# Prompt 04 — Build the Pattern Evidence Register

Create a pattern evidence register for the original Gym Management System.

Required columns:
`source_version,pattern_name,pattern_type,instance_name,participant_roles,source_locations,intent_and_evidence`

Rules:
- Use exactly `Original code` for original baseline rows.
- Preserve exact pattern names and instance names.
- Use correct categories: Creational, Structural, Behavioral, or GRASP.
- One row represents one distinct collaboration, not every file that participates.
- Cite production code only; exclude tests, generated files, and comments as sole evidence.
- Keep uncertain candidates out of the confirmed register and explain them separately.
- Do not invent line numbers. Recheck them against the supplied source snapshot.

Return valid CSV plus a short explanation of inclusion/exclusion decisions.
