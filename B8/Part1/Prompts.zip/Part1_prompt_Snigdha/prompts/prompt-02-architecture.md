# Prompt 02 — Reconstruct the Baseline Architecture

Using the verified original Team B10 Gym Management System snapshot, create a source-grounded architecture description.

Cover:
- Angular components, services, routing, and dependency injection
- FastAPI routers, services, models, schemas, and database-session lifecycle
- SQLite persistence
- Authentication and role-specific workflows
- Interactions for Admin, Trainer, and Member

Trace at least one end-to-end workflow from Angular UI through API route/service to persistence and back.

For every component, cite actual repository paths and line ranges. Do not invent modules, endpoints, class names, or database tables. Distinguish static architecture from runtime behavior that has not been executed.

Deliver:
1. Layered architecture diagram in Mermaid.
2. Component responsibility table.
3. Two or more sequence diagrams for representative workflows.
4. Evidence and uncertainty notes.
