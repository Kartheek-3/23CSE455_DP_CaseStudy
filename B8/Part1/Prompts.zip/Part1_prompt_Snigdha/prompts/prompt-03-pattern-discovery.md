# Prompt 03 — Discover Patterns in the Original Code

Perform a conservative, evidence-based design-pattern review of the original Gym Management System baseline.

Investigate these candidate instances without assuming they are all confirmed:
- Singleton — AuthService
- Dependency Injection — FastAPI database-session injection
- Singleton — PlansService
- Dependency Injection — Angular component constructor injection
- Observer — notification-state observer using RxJS
- Observer — attendance event observer
- Strategy — workout recommendation strategy
- Strategy — trainer-assignment policy

For each candidate:
1. Identify participants and their actual collaboration.
2. Explain the pattern intent in this project.
3. Provide exact production source path and line ranges.
4. Distinguish GoF patterns from framework-supported idioms and GRASP responsibilities.
5. Assign status: Confirmed, Candidate, or Not confirmed.
6. State what source evidence would falsify the claim.

Do not count a framework feature as a separate pattern instance unless the source demonstrates the required collaboration. Do not promote proposed Part 2 features into the original baseline.
