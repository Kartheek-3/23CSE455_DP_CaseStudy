# Prompt A2 — Identify and Justify Pattern Instances

## Goal
Identify design patterns that are genuinely supported by the baseline source. The objective is accurate pattern analysis, not maximizing the number of pattern names.

## Inputs
Use the repository map from Prompt A1 and the actual source at the same revision. Re-check relevant files directly.

## Tasks
1. Review likely creational, structural, and behavioral patterns where relevant to the code. Possible candidates include Singleton, Factory, Strategy, Observer, Adapter, Facade, Repository, and Dependency Injection, but do not assume any of them exists.
2. For every candidate, identify the concrete implementation: classes, functions, services, interfaces, modules, or framework configuration.
3. Explain the participants and their relationships. Describe how control or data flows between them and what design problem the arrangement solves.
4. Provide source evidence for each key part of the interpretation. Use exact paths and line ranges if available.
5. Consider at least one alternative explanation for each non-obvious candidate. For example, framework-managed service scope is not automatically proof of a deliberate Singleton pattern; a callback is not automatically proof of Observer.
6. Assign confidence as `strong`, `tentative`, or `insufficient evidence`, and justify it.
7. Separate patterns actually present in the baseline from patterns that could be introduced in a future refactor.

## Required output
Create a table with:
`pattern_name`, `pattern_category`, `instance_name`, `participants_and_roles`, `source_locations`, `observed_collaboration`, `design_intent`, `alternative_interpretation`, `confidence`.

Then provide:
- accepted findings;
- tentative findings requiring human review;
- rejected candidates and why they were rejected;
- a draft `patterns.csv` using exactly these columns:
  `source_version,pattern_name,pattern_type,instance_name,participant_roles,source_locations,intent_and_evidence`.

## Quality rules
- Do not claim intent solely from a class name.
- Do not count a library/framework feature as custom code without explaining the boundary.
- Do not fabricate line numbers or claim source was inspected if it was not.
- Use a stable baseline label such as a commit hash or clearly identified archive version.

Save the answer to `results/result-A2-pattern-discovery.md`.
