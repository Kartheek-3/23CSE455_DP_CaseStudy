# Prompt A4 — Audit Part A as an Independent Reviewer

## Role
You are reviewing the Part A package for accuracy and reproducibility. Assume the author may have misunderstood a pattern or accidentally made an unsupported claim.

## Inputs
Review A1–A3 outputs and, wherever possible, compare them with the actual source revision.

## Tasks
1. Verify that the repository and version labels are consistent throughout the package.
2. Sample-check every accepted pattern instance against its source evidence. If there are many rows, check all rows if practical; otherwise state the sampling method and identify unchecked rows.
3. Check whether each candidate's participants and collaboration match the stated pattern definition.
4. Check for duplicates, inconsistent naming, missing source locations, invalid CSV formatting, and unexplained counts.
5. Recalculate total pattern types and instances from the inventory.
6. Check that the diagram is consistent with the source and the inventory.
7. Identify unsupported statements, vague claims, or places where observed behavior is confused with proposed design.
8. Return actionable corrections, but do not silently change uncertain claims.

## Required output
- Findings table: `issue_id`, `artefact`, `problem`, `evidence`, `severity` (`high`, `medium`, `low`), `recommended_action`, `status`.
- Reconciliation results for all counts.
- Final checklist with `pass`, `revise`, or `not verified`.
- A short list of the most important manual checks remaining.

## Completion rule
Part A is ready only when all high-severity issues are fixed or clearly marked unresolved with a reason. Do not report a pass based only on formatting.

Save to `results/result-A4-independent-quality-audit.md`.
