# Prompt A3 — Produce the Inventory, Counts, and UML View

## Goal
Turn the accepted findings from A2 into consistent artefacts that can be checked by a lecturer or another student.

## Tasks
1. Finalize `patterns.csv`. Use one row per distinct, defined pattern instance. Explain your rule for deciding when two source locations are one instance versus separate instances.
2. Create `pattern_counts.csv` with exactly these columns:
   `source_version,summary,pattern_name,count`.
3. Include rows using the summary values:
   - `per_pattern`: one row for each pattern name and its instance count;
   - `total_pattern_types`: total number of unique accepted pattern types;
   - `total_pattern_instances`: total number of accepted instances.
   For total rows, document how `pattern_name` is represented (for example, `ALL`) and apply the choice consistently.
4. Reconcile all counts against the rows in `patterns.csv`. Do not include tentative or rejected findings in accepted totals unless the report explicitly defines and justifies a separate count for them.
5. Create one compact UML class diagram or sequence diagram. It should explain the most informative collaboration rather than attempt to display the entire application.
6. Provide the editable diagram source (such as Mermaid or PlantUML text) and, if tools are available, a rendered image.
7. Create `evidence_index.md` that maps every accepted CSV instance and every important diagram relationship to source evidence.

## Required output
- `patterns.csv`
- `pattern_counts.csv`
- diagram source and rendered diagram if available
- `evidence_index.md`
- a short counting-method explanation

## Validation checklist
- Every row has a source-version label.
- CSV headers are exact and stable.
- Fields containing commas are correctly quoted.
- Counts match the accepted inventory.
- The diagram does not show unsupported relationships.
- Missing evidence is marked `not verified`.

Save the explanation and artefact links/paths in `results/result-A3-csv-counts-and-uml.md`.
