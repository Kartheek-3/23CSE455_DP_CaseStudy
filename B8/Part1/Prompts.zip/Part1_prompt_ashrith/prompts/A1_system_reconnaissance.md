# Prompt A1 — Inspect and Map the Existing System

## Role
Act as a software architecture analyst documenting an existing student project for a design-pattern case study.

## Goal
Build an evidence-based map of the current Gym Management System before identifying design patterns. Do not make code changes.

## Inputs
- The repository or ZIP supplied by the student.
- The repository link, if accessible:
  `https://github.com/msnigdha07/23CSE455_DP_CaseStudy_B10/tree/main/data/code/Gym-Managment-System`

If you cannot access the source, stop and explain exactly what is needed. Do not claim that you inspected it.

## Tasks
1. Record the repository URL or archive name, branch, commit hash if available, and inspection date.
2. Identify the languages, frameworks, package managers, and main application entry points from project files.
3. Map the main layers and responsibilities, such as frontend, backend/API, persistence, authentication, and external integrations. Include a layer only if evidence confirms it.
4. Investigate relevant business areas where present: member management, trainer management, classes/scheduling, subscriptions/plans, attendance, workout plans, authentication, and notifications.
5. Trace at least three important user or system flows from entry point to data access or response. If fewer than three flows exist, explain why.
6. Find documented setup, run, build, and test commands. Distinguish commands found in project files from commands you actually ran.
7. List architectural uncertainties, missing configuration, dead ends, and areas that could not be inspected.

## Required output structure
- **Repository identity**
- **Technology and application map**
- **Feature inventory** table: feature, confirmed behavior, evidence path/lines, status (`confirmed`, `partial`, `not found`, `not verified`)
- **Important execution flows** table: flow, entry point, sequence of components, evidence
- **Commands** table: purpose, command, source of command, executed or not, observed result
- **Open questions and limitations**

## Quality rules
- Use exact file paths and line ranges when the source supports them.
- Never infer a feature from a folder name alone.
- Do not invent API endpoints, database tables, service names, or test outcomes.
- Keep descriptions concise but specific enough that another student can reproduce the inspection.

Save the answer to `results/result-A1-system-reconnaissance.md`.
