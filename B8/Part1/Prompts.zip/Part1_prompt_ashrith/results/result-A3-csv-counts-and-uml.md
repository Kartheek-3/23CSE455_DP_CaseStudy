# Result A3 — CSV, Counts, and UML
## Files created
- `patterns.csv`:
- `pattern_counts.csv`:
- Diagram source:
- Rendered diagram:
- Evidence index:

## Counting method
Define one instance and explain duplicate/framework handling.

## Count reconciliation
| Check | Recomputed value | Inventory value | Consistent? |
|---|---:|---:|---|
| Unique accepted pattern types | | | |
| Accepted instances | | | |
| Per-pattern counts | | | |

## Diagram scope
- Main interaction shown:
- Evidence for relationships:
- Known omissions:
- Unverified relationships:
