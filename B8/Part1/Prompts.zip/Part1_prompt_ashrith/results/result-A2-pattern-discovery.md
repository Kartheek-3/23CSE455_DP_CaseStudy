# Result A2 — Pattern Discovery
## Accepted findings
| Pattern | Category | Instance | Participants and roles | Source locations | Observed collaboration | Intent | Alternative explanation | Confidence |
|---|---|---|---|---|---|---|---|---|

## Tentative findings
| Candidate | Evidence currently available | What needs checking |
|---|---|---|

## Rejected candidates
| Candidate | Reason for rejection |
|---|---|

## `patterns.csv`
Header:
`source_version,pattern_name,pattern_type,instance_name,participant_roles,source_locations,intent_and_evidence`

Paste or link the validated CSV here.

## Baseline revision label
-
