# Prompt 02 — Cross-Language Singleton and Dependency Injection

## Context

Member 1 is assigned:
- Singleton — authentication service (`AuthService`).
- Dependency Injection — FastAPI database session.

Member 2 is assigned:
- Singleton — plans service (`PlansService`).

Baseline source evidence:
- Angular `AuthService`: `data/code/Gym-Managment-System/frontend/src/app/services/auth.service.ts`, `@Injectable({ providedIn: 'root' })` near line 8; constructor injection near line 14.
- Angular `PlansService`: `data/code/Gym-Managment-System/frontend/src/app/services/plans.service.ts`, root provider near line 7 and constructor injection near line 11.
- FastAPI database dependency: `data/code/Gym-Managment-System/backend/app/database.py` (`get_db`, around line 29) and endpoint use such as `backend/app/routers/plans.py` around lines 53–59.

## Objective

Create equivalent small examples in Java, Python, JavaScript, and C++ that teach Singleton and Dependency Injection while accurately distinguishing manual pattern implementations from framework-managed lifecycle behavior.

## Singleton requirements

- Demonstrate controlled creation and repeated access to a shared instance.
- Include a test that requests the instance more than once and verifies identity.
- Discuss thread-safety/concurrency where relevant.
- Avoid global mutable state unrelated to the example.
- Explain language-specific implementation: private/static instance in Java, controlled instance construction in Python, module/shared instance in JavaScript, and static local/function or controlled static instance in C++.
- For `AuthService` and `PlansService`, explain that Angular `providedIn: 'root'` is an injector scope decision; do not describe it as a hand-written Singleton class unless the code actually is one.

## Dependency Injection requirements

- Use an explicit dependency (database/session provider or repository interface) supplied to the consumer.
- Consumer code must not create its own database session internally.
- Demonstrate replacing the dependency with a fake/mock in tests.
- In Python, relate the example to FastAPI's `Depends(get_db)` and session lifecycle; do not attempt to run a FastAPI dependency in the other languages.
- In Java, JavaScript, and C++, show constructor/parameter injection with the same conceptual contract.
- Explain DI as a design principle/mechanism, not necessarily a GoF GoF catalogue pattern.

## Required deliverables

For each language/pattern:
- production snippet;
- separate test runner/tests;
- README with exact command and working directory;
- actual terminal output;
- limitations and language idioms.
Also provide a common behavior table and cross-language source/complexity comparison.

Do not include database passwords or production credentials. Do not benchmark fake database/network I/O as if it were real application performance.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
