# Prompt 03 — Cross-Language Strategy: Personalized Workout Recommendations

## Context

Member 2 is assigned the Strategy pattern for workout recommendations. The supplied Part 2 summary reports six goals:
- General Fitness
- Weight Loss
- Muscle Building
- Strength Training
- Endurance
- Flexibility

The baseline stores workout plans but the six-goal Strategy implementation belongs to Part 2 and is not present in the uploaded baseline source.

## Objective

Implement the same small recommendation problem in Java, Python, JavaScript, and C++ using interchangeable strategy objects/functions.

## Language-neutral contract

Input:
- a goal from the six supported goal names;
- a difficulty (`Beginner`, `Intermediate`, or `Advanced`).

Output:
- a stable list of exercise recommendation identifiers/names for that goal and difficulty;
- a consistent error/result for unsupported goals or difficulty values.

The actual exercise lists should be small, safe, deterministic, and identical across all languages. Use the same fixtures and expected outputs. Do not introduce medical or individualized health claims.

## Required design

- Common Strategy contract.
- Six concrete strategies or equivalent callable objects.
- Context/recommendation service that invokes a selected strategy.
- Goal-to-strategy selection separated from the strategy algorithms; if a Factory is included, explain it separately from Strategy.
- Tests for every goal, all difficulty levels, unsupported input, and stable output.
- A short comparison with the reported Part 2 architecture, mapping conceptual roles to the actual evolved source only after that source is inspected.

## Required outputs

- UML or Mermaid class diagram.
- Four source implementations and separate tests.
- Identical fixture file/expected outputs.
- README commands.
- LOC and complexity measurements using the same rules.
- Measured process timing with raw results.

Do not claim these snippets are copied from production code unless they are. Clearly label them as representative cross-language examples derived from the case-study behavior.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
