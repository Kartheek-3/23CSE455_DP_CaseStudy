# Prompt 01 — Part 3 Scope, Assigned Work, and Cross-Language Pattern Selection

## Role

Act as a design-pattern instructor, cross-language implementation engineer, test engineer, and metrics auditor. Prepare Part 3 of the B10 Gym Management System case study.

## Source requirements

The supplied Part 3 markdown assigns six examples across three team members:
- Member 1: Singleton — `AuthService`; Dependency Injection — FastAPI database session.
- Member 2: Singleton — `PlansService`; Strategy — workout recommendations.
- Member 3: Dependency Injection — Angular component constructor injection; Observer — attendance events.

Target languages are Java, Python, JavaScript, and C++. Angular is TypeScript, so plain JavaScript should demonstrate the same DI principle conceptually rather than falsely claiming to run Angular's injector.

The faculty instructions require equivalent small problems in all four languages for each confirmed pattern type, identical inputs and expected outputs, source LOC, maximum function cyclomatic complexity, runtime/compiler version, test command/result, measured median process time, and language notes.

## Objective

Translate the team assignments into a consistent implementation plan without changing the assigned responsibilities or claiming unprovided source code already exists.

## Required decisions

1. Identify the distinct pattern concepts: Singleton, Dependency Injection, Strategy, Observer. Keep the two Singleton contexts distinct in discussion but avoid redundant benchmarking unless the course requires separate instances.
2. Choose a language-neutral behavior contract for each pattern.
3. Decide whether each pattern's cross-language implementation will use one small representative domain example or two examples where the assigned context materially differs.
4. Define same inputs, outputs, and error cases across all languages.
5. Separate production snippet code from tests and benchmark harnesses.
6. State framework-specific versus language-neutral mechanisms.
7. Specify source-code evidence that connects the examples to the real Gym Management System.

## Required outputs

- Assignment matrix by team member.
- Pattern selection rationale and exclusions.
- Language-neutral behavior contracts.
- Directory tree for each pattern/language.
- Risks and assumptions.
- Evidence checklist.

Do not claim that the four-language implementations exist or pass tests until actual files and execution logs are available.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
