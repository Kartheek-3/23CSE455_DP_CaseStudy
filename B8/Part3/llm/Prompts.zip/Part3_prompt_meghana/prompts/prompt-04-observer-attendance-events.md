# Prompt 04 — Cross-Language Observer: Attendance Events and Notifications

## Context

Member 3 is assigned Observer for attendance events. The supplied Part 2 summary describes four reactions:
- in-app notification;
- email;
- SMS;
- alert to assigned trainer.

The baseline includes attendance endpoints, a notification model/router, email/SMS utility functions, and Angular notification services. The event publisher/four-observer design is reported for Part 2 and must be checked in the evolved source before it is cited as a production implementation.

## Objective

Implement one language-neutral attendance-event publisher with multiple independent observers in Java, Python, JavaScript, and C++.

## Contract

An event contains a stable event type, member ID, attendance status, and optional trainer ID. On a valid check-in event, each registered observer receives the event once. The sample should not actually send real email/SMS; use deterministic test observers that record actions.

## Required design

- Publisher/subject that emits an attendance event.
- Observer interface/callback.
- At least three test observers; optionally model all four channels as recording observers.
- Subscribe/unsubscribe behavior.
- Test that all registered observers receive an event.
- Test that an unsubscribed observer does not receive later events.
- Test event payload integrity and repeated event behavior.
- Explain delivery failure/retry and idempotency as production concerns, even if the small snippet only records events.
- Compare class-based observers, callbacks, event emitters, and function objects idiomatically across the four languages.

## Required outputs

- UML/event sequence diagram.
- Four source snippets, tests, and run instructions.
- Same event fixture and expected recorded observer actions.
- LOC, maximum function CC, compiler/runtime version, actual test result, and measured median timing.
- Notes distinguishing this educational snippet from the production notification infrastructure.

Do not use real credentials, send messages externally, or claim that a simple callback example proves the evolved application has the same architecture.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
