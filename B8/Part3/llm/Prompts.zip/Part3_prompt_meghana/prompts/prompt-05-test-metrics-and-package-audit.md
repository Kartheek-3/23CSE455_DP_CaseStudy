# Prompt 05 — Part 3 Equivalence Tests, Metrics, and Submission Audit

## Objective

Validate the four-language examples as an empirical comparison, not merely a collection of code snippets.

## Required CSV

Use `cross_language.csv` with exact columns:
- `pattern_name`
- `instance_name`
- `language`
- `snippet_path`
- `source_loc`
- `max_function_cc`
- `runtime_compiler`
- `test_command`
- `test_result`
- `median_process_ms`
- `language_notes`

One row represents one representative confirmed pattern instance implemented in one language. If there are four pattern concepts, each implemented in four languages, expect one row per pattern-language pair, with additional rows only if the team deliberately treats separate contexts as distinct instances.

## Measurement rules

1. Production LOC excludes blank lines, comments, and test code.
2. Define the exact cyclomatic-complexity counting rule and tool in a README; measure the maximum function CC consistently.
3. Record actual language runtime/compiler and version.
4. Record exact test/compile command and working directory.
5. Compile first where applicable; run one warm-up and five measured runs on the same machine.
6. Report the median process time in milliseconds.
7. State once whether timing includes process startup and fixture/input reading or only snippet execution.
8. Preserve raw timing values and terminal outputs.
9. If execution was unavailable, use `not_run` with a reason and leave timing blank. Never estimate time.

## Equivalence tests

- Use identical logical inputs and expected outputs across languages.
- Include negative/error cases.
- Ensure each language uses the same algorithmic rules, not merely similar-looking code.
- Separate tests from production source.
- Compare implementation structure, abstraction mechanism, boilerplate, ownership/memory model, runtime behavior, and framework dependence.

## Package audit

Expected pattern-first structure:
`Part3/<pattern_problem_name>/{java,python,javascript,cpp}/`
Each language folder should contain source, tests/test runner, and README. `Part3/llm/` should contain the exact prompt, raw output, verification notes, `llm.csv`, `cross_language.csv`, and presentation artifact if required.

Do not claim tests/metrics have been completed unless the files and raw evidence are present.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
