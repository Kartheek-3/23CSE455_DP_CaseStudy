# Result 03 — Strategy for Workout Recommendations

**Status:** Language-neutral contract and implementation plan.

## 1. Domain connection

The supplied Part 2 summary describes six workout goals and goal-specific recommendations. The baseline contains workout-plan CRUD and persistence, but the uploaded baseline source does not contain the reported six-strategy recommendation implementation.

## 2. Common contract

A recommendation request consists of:
- `goal`: one of the six supported goal labels;
- `difficulty`: Beginner, Intermediate, or Advanced.

The result is a deterministic list of exercise names/IDs, or a consistent error for unsupported input. Every language must use the same goal/difficulty fixtures and expected results.

## 3. Pattern roles

| Role | Language-neutral meaning |
|---|---|
| Strategy | Shared contract for producing recommendations |
| Concrete strategy | One goal-specific algorithm |
| Context | Recommendation service that invokes the selected strategy |
| Optional Factory | Maps the goal to a concrete strategy |

Six concrete strategies constitute one Strategy collaboration if they share a common contract and are selected by one context. A distinct factory can be documented as a separate collaboration only if its responsibility is actually separate.

## 4. Comparison criteria

Compare:
- interface/abstract class versus duck typing/function objects;
- selection logic and extensibility;
- validation behavior;
- LOC excluding comments/tests;
- maximum function CC under one declared rule;
- actual test result;
- runtime/compiler;
- median measured process time with raw runs.

## 5. Evidence limitation

No Java, Python, JavaScript, or C++ Strategy snippets or execution outputs were present in the supplied Part 3 markdown. The source code and metrics remain deliverables, not completed findings.
