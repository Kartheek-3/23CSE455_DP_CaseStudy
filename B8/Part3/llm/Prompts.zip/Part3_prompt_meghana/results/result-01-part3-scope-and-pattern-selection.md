# Result 01 — Part 3 Scope and Pattern Selection

**Source:** supplied Part 3 markdown and faculty `DP_Csestudy.pdf`.

## 1. Assigned work

| Team member | Assigned example 1 | Assigned example 2 |
|---|---|---|
| Member 1 | Singleton — AuthService | Dependency Injection — FastAPI database session |
| Member 2 | Singleton — PlansService | Strategy — workout recommendations |
| Member 3 | Dependency Injection — Angular constructor injection | Observer — attendance events |

The assigned target languages are Java, Python, JavaScript, and C++.

## 2. Distinct concepts

The six assigned examples cover four distinct concepts:
- Singleton (two contexts: authentication and plans service);
- Dependency Injection (FastAPI session and Angular component examples);
- Strategy (workout recommendations);
- Observer (attendance events).

The cross-language comparison should not accidentally count the same pattern type as several distinct pattern types. Whether AuthService and PlansService need separate benchmark rows depends on the team's definition of `instance_name` and whether the assignment wants each production collaboration represented separately.

## 3. Baseline evidence

The uploaded baseline contains:
- `AuthService` root provider at `frontend/src/app/services/auth.service.ts`, around line 8; constructor injection around line 14.
- `PlansService` root provider at `frontend/src/app/services/plans.service.ts`, around line 7; constructor injection around line 11.
- FastAPI `get_db()` at `backend/app/database.py`, around line 29; session injection in workout-plan creation at `backend/app/routers/plans.py`, around lines 53–59.
- `PlansComponent` constructor injection at `frontend/src/app/components/plans/plans.component.ts`, around lines 422–426.
- Attendance, notification routes, and email/SMS helpers in `backend/app/routers/attendance.py`, `backend/app/routers/notifications.py`, and `backend/app/utils/notifications.py`.

These baseline paths ground the domain examples. The evolved Strategy and Observer implementation is described in the supplied summary but was not included in the uploaded source ZIP.

## 4. Important classification note

Angular `providedIn: 'root'` is framework-managed service scope and can provide one root injector instance; it is not automatically a manually implemented GoF Singleton. FastAPI `Depends` and Angular constructor injection are dependency-injection mechanisms; explain the design principle even if the faculty asks to catalogue only GoF patterns.

## 5. Completion status

The assignment matrix is established. The actual four-language source packages, tests, and measurements were not included in the supplied Part 3 markdown, so implementation success cannot be claimed.
