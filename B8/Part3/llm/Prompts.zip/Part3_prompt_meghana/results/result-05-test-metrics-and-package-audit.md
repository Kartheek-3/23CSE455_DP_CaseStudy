# Result 05 — Part 3 Metrics and Package Audit

## 1. Required CSV schema

`cross_language.csv` must contain exactly:
`pattern_name,instance_name,language,snippet_path,source_loc,max_function_cc,runtime_compiler,test_command,test_result,median_process_ms,language_notes`

## 2. Measurement protocol

- Production LOC excludes blank lines, comments, and tests.
- The README must state the complexity tool and counting rule.
- Compiler/runtime versions and working directories are recorded.
- Compile first where needed, then one warm-up and five measured runs on the same machine.
- Store all raw times and report their median.
- State whether process startup and input reading are included.
- Leave `median_process_ms` blank if not run; use `test_result=not_run` with a reason.

## 3. Current evidence status

The supplied Part 3 markdown describes the intended six assignments and metrics but does not contain the actual source packages or raw execution logs. Therefore, no test pass counts, LOC values, complexity values, compiler versions, or timings can be asserted.

## 4. Final structure checklist

For each pattern problem, create `java/`, `python/`, `javascript/`, and `cpp/` folders with:
- production source;
- separate test source/runner;
- README with exact command, working folder, dependencies, and output.

Under `Part3/llm/`, preserve:
- exact prompt file;
- actual raw model output;
- human verification;
- `llm.csv`;
- `cross_language.csv`;
- presentation PDF if required by the team instructions.

## 5. Final acceptance gate

Part 3 is complete only when equivalent behavior is tested across languages, actual evidence is retained, and metrics are measured consistently. This package is a prompt/result planning artifact and does not substitute for the code, report, or evidence files.
