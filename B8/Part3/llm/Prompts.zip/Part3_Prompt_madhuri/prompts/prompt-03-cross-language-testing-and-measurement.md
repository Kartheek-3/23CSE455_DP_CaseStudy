# Prompt 03 — Test and Measure Cross-Language Implementations

For each approved pattern-language pair, help run tests and record evidence using the faculty schema:

pattern_name,instance_name,language,snippet_path,source_loc,max_function_cc,runtime_compiler,test_command,test_result,median_process_ms,language_notes

Method:
1. Compile first where applicable.
2. Perform one warm-up.
3. Run five measured fresh-process executions on the same machine.
4. Record median elapsed time in milliseconds.
5. State whether timing includes process startup and test input/output.
6. Record exact runtime/compiler version.
7. Calculate maximum function cyclomatic complexity using one documented tool/rule consistently.
8. Record actual passed/total or failed result; use not_run with a reason if not executed.
9. Never estimate missing timing, complexity, source locations, or test results.
10. Explain language-specific structural/dynamic differences. Treat timings as environment-specific, not a general language-speed ranking.

Output a CSV draft and a list of raw evidence files needed. Clearly distinguish planned commands from commands actually run.
