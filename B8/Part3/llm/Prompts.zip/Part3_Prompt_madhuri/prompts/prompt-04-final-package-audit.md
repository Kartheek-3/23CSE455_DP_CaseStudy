# Prompt 04 — Final Audit of the Complete Case Study

Audit the Parts 1–3 package against the assignment instructions.

Expected:
- Part 1: baseline architecture, source-backed pattern inventory, counts, evidence, diagrams.
- Part 2: three feature changes, tests, pattern evolution records, refactoring and updated evidence.
- Part 3: approved pattern examples in Java, Python, JavaScript, and C++; tests, READMEs, cross-language CSV.
- Genuine prompt/raw-output records and human verification.
- Final README and report.

Verify:
- File/folder paths exist.
- CSV headers exactly match faculty schemas.
- Row counts reconcile with the approved inventory and version labels.
- Source locations point to the correct production snapshot.
- Runtime/compiler versions, commands, tests, complexity, and timing are evidenced.
- No claims of full integration testing without execution evidence.
- No unrelated students' material or unverified examples have been copied into the case study.
- Report and ZIP/repository contents agree.

Return a pass/fail/pending checklist, exact outstanding risks, and a recommended final folder tree. Do not guarantee a grade or claim audit items passed without evidence.
