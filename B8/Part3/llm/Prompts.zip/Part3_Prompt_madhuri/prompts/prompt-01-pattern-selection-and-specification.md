# Prompt 01 — Select Patterns and Define Common Specifications

Select two significant design pattern types/instances from the verified Part 1 inventory.

Supply:
- Approved Part 1 inventory and source evidence:
- Pattern candidates:
- Faculty/team allocation, if any:
- Reasons for significance:

Tasks:
1. Check that each candidate is confirmed by source evidence.
2. Recommend two suitable patterns and justify the selection without increasing counts artificially.
3. Define one small deterministic problem for each selected pattern.
4. Specify inputs, outputs, business rules, edge cases, errors, and expected outputs.
5. Define shared test fixtures to use in Java, Python, JavaScript, and C++.
6. Explain which aspects represent the original production collaboration and which are a reduced educational demonstration.
7. Flag framework-specific patterns such as Angular/FastAPI dependency injection; implementations in other languages must be described as language-neutral equivalents, not actual framework integrations.

Do not invent approved inventory items or claim an unverified pattern is confirmed.
