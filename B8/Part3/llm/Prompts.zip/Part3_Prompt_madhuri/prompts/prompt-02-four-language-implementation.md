# Prompt 02 — Implement the Selected Patterns in Four Languages

Using the approved specifications, create equivalent standalone examples in Java, Python, JavaScript, and C++ for each selected pattern.

Requirements:
- Keep problem behavior, inputs, expected outputs, and edge cases equivalent.
- Keep production snippet and test runner separate where practical.
- Include a README in every language folder with roles, design explanation, prerequisites, exact compile/run command, and expected output.
- Use idiomatic language constructs; do not mechanically translate syntax.
- For framework-specific DI examples, label other-language versions as language-neutral equivalents rather than claiming actual Angular/FastAPI integration.
- Do not connect examples to the production database/application unless explicitly required.
- Return folder tree and full source/test/README contents.
- Do not claim the code passed tests unless actual execution output is provided.
