# Result 01 — Part 3 Pattern Selection

Status: [not run / draft / human-verified]
Selected pattern 1:
- Pattern type/instance:
- Part 1 evidence:
- Reason for selection:

Selected pattern 2:
- Pattern type/instance:
- Part 1 evidence:
- Reason for selection:

## Common specifications
[Inputs, outputs, rules, edge cases and expected outputs for both patterns.]

## Human verification
[Confirm selections against the final approved inventory.]
