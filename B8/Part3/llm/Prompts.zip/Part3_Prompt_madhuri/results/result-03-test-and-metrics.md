# Result 03 — Cross-Language Test and Metrics

Required CSV schema:
pattern_name,instance_name,language,snippet_path,source_loc,max_function_cc,runtime_compiler,test_command,test_result,median_process_ms,language_notes

## Measurement procedure
1. Compile/syntax-check first.
2. Run one warm-up.
3. Run five measured fresh-process executions on the same machine.
4. Record median elapsed time and what timing includes.
5. Record exact runtime/compiler version.
6. Calculate max function cyclomatic complexity using the README's stated tool/rule.
7. Record actual test result or not_run with reason.

## Evidence
- Raw outputs/logs:
- Timing measurements:
- Complexity tool/output:
- Test fixtures:
- Human verification notes:

Never estimate or copy measurements from examples unless the exact final source and commands match and are re-run.
