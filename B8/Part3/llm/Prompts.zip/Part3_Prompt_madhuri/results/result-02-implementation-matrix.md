# Result 02 — Four-Language Implementation Matrix

Status: [not run / draft / human-verified]

| Pattern instance | Language | Source path | Test path | README path | Run status |
|---|---|---|---|---|---|
| Pattern 1 | Java | pending | pending | pending | not_run |
| Pattern 1 | Python | pending | pending | pending | not_run |
| Pattern 1 | JavaScript | pending | pending | pending | not_run |
| Pattern 1 | C++ | pending | pending | pending | not_run |
| Pattern 2 | Java | pending | pending | pending | not_run |
| Pattern 2 | Python | pending | pending | pending | not_run |
| Pattern 2 | JavaScript | pending | pending | pending | not_run |
| Pattern 2 | C++ | pending | pending | pending | not_run |

Add rows if the approved allocation contains more than two pattern instances. Do not claim a run passed without evidence.
