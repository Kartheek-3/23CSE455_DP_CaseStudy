# Result C2 — Four-Language Implementation
## Implementation matrix
| Pattern | Language | Source files | Entry point | Run command | Runtime/compiler version | Dependencies | Executed? |
|---|---|---|---|---|---|---|---|
| A | Java | | | | | | |
| A | Python | | | | | | |
| A | JavaScript | | | | | | |
| A | C++ | | | | | | |
| B | Java | | | | | | |
| B | Python | | | | | | |
| B | JavaScript | | | | | | |
| B | C++ | | | | | | |

## Contract coverage
| Pattern/scenario | Java | Python | JavaScript | C++ | Notes |
|---|---|---|---|---|---|

## Idiomatic differences
-
## Unrun or failing implementations
-
