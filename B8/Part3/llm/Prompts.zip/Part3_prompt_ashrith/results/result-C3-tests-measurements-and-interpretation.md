# Result C3 — Tests, Measurements, and Interpretation
## Environment
| Language | Version | OS | Settings |
|---|---|---|---|

## Test matrix
| Pattern | Language | Scenario | Expected | Actual | Status | Evidence/log |
|---|---|---|---|---|---|---|

## Measurement protocol
- LOC rule:
- Complexity tool/method:
- Runtime workload:
- Repetitions and warm-up:
- Timing method:
- Sources of noise:

## `cross_language_results.csv`
Suggested header:
`pattern_name,language,loc,complexity_metric,runtime_ms,test_status,environment,notes`

## Interpretation
- Comparable findings:
- Non-comparable results:
- Limitations:
- Measurements not collected:
