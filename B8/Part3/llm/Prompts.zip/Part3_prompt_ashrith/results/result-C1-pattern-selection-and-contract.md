# Result C1 — Pattern Selection and Contracts
## Pattern A
- Name/category:
- Gym-system problem:
- Baseline/evolution evidence or demonstration-only label:
- Participants:
- Observable contract:
- Normal scenario:
- Second scenario:
- Edge case:
- Invalid/failure case:
- Cross-language invariants:
- Permitted idiomatic differences:

## Pattern B
- Name/category:
- Gym-system problem:
- Baseline/evolution evidence or demonstration-only label:
- Participants:
- Observable contract:
- Normal scenario:
- Second scenario:
- Edge case:
- Invalid/failure case:
- Cross-language invariants:
- Permitted idiomatic differences:

## Selection rationale
-
