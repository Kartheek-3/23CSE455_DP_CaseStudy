# Prompt C1 — Select Two Patterns and Define Their Behavior

## Goal
Choose two design patterns suitable for a fair cross-language implementation study and define precisely what each implementation must do.

## Selection requirements
1. Prefer patterns that connect meaningfully to the Gym Management System case study.
2. Use evidence from Part A or Part B when claiming that a pattern exists in the original system.
3. If a pattern is selected only for the comparative exercise, label it as a demonstration rather than a confirmed baseline instance.
4. Choose examples small enough to implement and test in all four languages without requiring a full web framework or database.

## For each pattern, specify
- pattern name and category;
- gym-system problem being modeled;
- participants and responsibilities;
- language-neutral input/output or observable behavior;
- at least four scenarios, including normal behavior, an edge case, and an invalid or failure case;
- which behavior must remain identical across languages;
- which implementation details may be language-specific;
- what a test must observe to determine pass or fail.

## Deliverables
Create `pattern_contracts.md` and a short selection rationale. Avoid writing language-specific code at this stage. The contract must be clear enough that four people could implement it independently and still produce behaviorally comparable solutions.

Save to `results/result-C1-pattern-selection-and-contract.md`.
