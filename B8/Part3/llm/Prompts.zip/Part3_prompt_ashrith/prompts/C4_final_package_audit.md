# Prompt C4 — Audit the Complete Cross-Language Package

## Role
Review the package as if you were preparing to defend it in a viva. Your task is to find gaps, not to praise the work by default.

## Tasks
1. Confirm exactly two patterns were selected and the selection rationale is explicit.
2. Confirm that all eight pattern-language combinations have source code.
3. Confirm that each implementation follows the shared contract.
4. Verify run instructions and actual test evidence for each language.
5. Check that all reported measurements have a method and source evidence.
6. Look for unfair comparisons, unreported environment differences, or conclusions stronger than the data supports.
7. Check consistency of filenames, CSV headers, terminology, and version information.
8. List any pattern explanations that confuse a general coding technique with the selected design pattern.
9. Identify which claims need manual demonstration during a viva.

## Required output
- Audit table with `requirement`, `evidence`, `status` (`pass`, `revise`, `not verified`), `risk`, and `action`.
- Missing artefacts list.
- Most likely viva questions about design choices, testing, and measurement.
- Final status: `ready`, `ready with limitations`, or `not ready`, supported by findings.

Do not mark an item as passed because a file exists; inspect whether its contents satisfy the requirement.

Save to `results/result-C4-final-package-audit.md`.
