# Prompt C2 — Implement Both Patterns in Four Languages

## Goal
Create eight small, runnable implementations: two patterns in each of Java, Python, JavaScript, and C++.

## Inputs
Use the approved language-neutral contracts from C1. Do not change the expected behavior separately for each language to make implementation easier.

## Requirements
1. Organize files by pattern and language, using clear, consistent names.
2. Provide a minimal entry point or test runner for each implementation.
3. Implement the same participants and observable responsibilities as the contract requires, using idiomatic language features.
4. Add comments that explain the design decision and pattern roles; avoid excessive line-by-line comments.
5. Keep unrelated concerns such as database access, UI rendering, and network calls out of the example unless the contract requires them.
6. Document the compiler/interpreter/runtime version and any dependencies.
7. Provide exact build and run commands for each implementation.
8. Execute every command where the environment allows it. Record errors honestly and do not mark unexecuted code as verified.
9. If a language toolchain is unavailable, still provide source only if requested, and clearly mark that implementation as not compiled or run.

## Required output
- Source code for all eight implementations.
- Folder/file map.
- Run instructions.
- A table mapping each contract scenario to the implementation and its test.
- A short explanation of important idiomatic differences across languages.

## Consistency checks
- Same inputs should produce equivalent observable behavior.
- Error and edge-case behavior should follow the contract.
- Avoid using different algorithms or extra features in one language without explaining why.
- Do not claim that a pattern is implemented correctly solely because the class or function names match a textbook example.

Save the implementation summary to `results/result-C2-four-language-implementation.md`.
