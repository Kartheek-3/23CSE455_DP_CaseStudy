# Prompt C3 — Test All Implementations and Compare Them Fairly

## Goal
Verify behavior against the shared contract and collect a small, reproducible comparison dataset.

## Test phase
1. Run each implementation's test command.
2. Record the exact command, environment, expected behavior, actual output, and pass/fail status.
3. Use the same scenario definitions for all four languages.
4. Include at least one edge case and one failure or invalid-input case per pattern where applicable.
5. Keep logs or concise captured outputs as evidence. Do not create imaginary logs.

## Measurement phase
Choose metrics that are appropriate and realistically comparable:
- lines of code, with a stated counting rule;
- a complexity metric only if a consistent tool or comparable method is available;
- runtime for a deterministic workload, if all implementations can be run under sufficiently comparable conditions;
- qualitative assessment of readability, extensibility, and idiomatic fit, supported by specific examples.

For runtime:
- state the workload and input size;
- record hardware/OS and language runtime/compiler versions;
- explain warm-up, repetition count, and timing method;
- report summary statistics where possible;
- avoid drawing strong conclusions from tiny or noisy differences.

## Required output
Create `cross_language_results.csv` with a documented schema, for example:
`pattern_name,language,loc,complexity_metric,runtime_ms,test_status,environment,notes`.

Also provide:
- test result matrix;
- measurement protocol;
- results table;
- interpretation of similarities and differences;
- limitations and measurements that could not be collected.

## Quality rules
Never invent results to complete the table. Use `not measured`, `not run`, or `not available` as appropriate. Explain when two values are not directly comparable.

Save to `results/result-C3-tests-measurements-and-interpretation.md`.
