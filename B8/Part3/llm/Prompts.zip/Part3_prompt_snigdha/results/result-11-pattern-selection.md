# Result 11 — Part 3 Pattern Selection

## Team allocation recorded for the cross-language exercise

| Member | Pattern instance 1 | Pattern instance 2 |
|---|---|---|
| Member 1 | Singleton — AuthService | Dependency Injection — FastAPI database session injection |
| Member 2 | Singleton — PlansService | Strategy — Workout recommendation strategy |
| Member 3 | Dependency Injection — Angular component constructor injection | Observer — Attendance event observer |

The separately discussed Strategy — Trainer assignment policy and Observer — Notification state observer should be included only where the final faculty-approved allocation requires them. Avoid silently adding extra pattern instances.

## Demonstration rule
Each pattern is implemented in Java, Python, C++, and JavaScript with the same purpose, equivalent test inputs, and expected behavior. Samples are educational demonstrations, not full ports of Angular/FastAPI application code.

## Classification
- Singleton: Creational (qualify Angular injector scope).
- Strategy: Behavioral.
- Observer: Behavioral.
- Dependency Injection: framework/architectural idiom; use the faculty-approved category consistently and explain the classification.
