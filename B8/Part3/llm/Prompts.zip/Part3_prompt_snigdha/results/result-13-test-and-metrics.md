# Result 13 — Cross-Language Test and Metrics Method

## Required schema
`pattern_name,instance_name,language,snippet_path,source_loc,max_function_cc,runtime_compiler,test_command,test_result,median_process_ms,language_notes`

## Required measurement procedure
1. Compile or perform syntax validation.
2. Run one warm-up.
3. Execute five measured fresh-process runs on the same machine.
4. Record median elapsed time in milliseconds.
5. Record the runtime/compiler and version.
6. Calculate maximum function cyclomatic complexity using one documented tool/rule.
7. Record exact passed/total or failed result.
8. Leave unavailable values blank or `not_run` with a reason; never estimate.

## Interpretation
Process timings include the exact scope documented in README (startup and test execution, or another clearly defined boundary). Results are machine- and runtime-version-specific and are not a general performance ranking of languages.

## Evidence status
Earlier standalone examples were test-run in their own environment, but those results must not be copied into this case-study metrics file unless the exact submitted source files and commands match. Re-run the final submission package before freezing the CSV.
