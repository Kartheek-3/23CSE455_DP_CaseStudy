# Prompt 12 — Implement the Selected Patterns in Four Languages

Create equivalent, standalone examples for each approved pattern instance in Java, Python, C++, and JavaScript.

Requirements:
- Keep the problem, inputs, expected outputs, and edge cases equivalent across languages.
- Keep production snippet and test runner separate where practical.
- Include a README in each language folder with roles, design explanation, prerequisites, exact compile/run command, and expected output.
- Use idiomatic language constructs; do not mechanically translate syntax.
- For framework-specific DI examples, label other-language versions as language-neutral equivalents rather than claiming they are actual Angular/FastAPI integrations.
- Do not connect the samples to the production database or application unless explicitly requested.

Return the full folder tree and all source/test/README contents.
