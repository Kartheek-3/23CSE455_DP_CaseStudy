# Prompt 13 — Test and Measure Cross-Language Implementations

For every approved pattern-language pair, compile/run tests and record evidence using the faculty schema:

`pattern_name,instance_name,language,snippet_path,source_loc,max_function_cc,runtime_compiler,test_command,test_result,median_process_ms,language_notes`

Method:
1. Compile before timing.
2. Perform one warm-up.
3. Run five measured fresh-process executions on the same machine.
4. Record the median elapsed milliseconds.
5. State whether timing includes process startup and test input/output.
6. Record exact runtime/compiler version.
7. Calculate maximum function cyclomatic complexity using one documented rule/tool, consistently across languages.
8. Record passed/total or failed result; use `not_run` only with a reason.
9. Never estimate missing timing, complexity, source locations, or test results.

Explain language-specific structural/dynamic differences. Treat timings as environment-specific, not a language speed ranking.
