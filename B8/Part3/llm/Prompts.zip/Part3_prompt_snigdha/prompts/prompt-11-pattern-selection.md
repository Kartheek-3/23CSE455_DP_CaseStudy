# Prompt 11 — Select Patterns for Part 3 Cross-Language Demonstrations

Select the confirmed pattern instances from the Gym Management System case study for compact implementations in Java, Python, C++, and JavaScript.

Use the team allocation and approved pattern inventory:
- Member 1: Singleton — AuthService; Dependency Injection — FastAPI database session injection
- Member 2: Singleton — PlansService; Strategy — workout recommendation strategy
- Member 3: Dependency Injection — Angular component constructor injection; Observer — attendance event observer

Also retain any separately approved instance such as Strategy — trainer assignment policy or Observer — notification state only if it appears in the final approved inventory.

For each selection define:
- Pattern intent and roles
- One small deterministic problem
- Same input cases and expected outputs across languages
- Boundaries of the demonstration versus the production app

Do not add patterns simply to increase the count. Do not treat dependency injection as a GoF pattern; classify it consistently with the faculty's taxonomy and justify the category.
