# Case Study Scope — Team B10 Gym Management System

## System context
The case study concerns the Gym Management System repository `MeharRaza/Gym-Managment-System`, using Angular 17, FastAPI, and SQLite, with Admin, Trainer, and Member roles. The recorded baseline commit is `837e2be2ef4e27baa93e9b42cecc790febd5f16c`.

## Three parts
1. **Part 1 — Original code analysis:** architecture reconstruction and source-backed pattern discovery.
2. **Part 2 — System evolution:** Personalized Workout Plans, Trainer-Assignment Policies, and Attendance Notifications. These must be analysed as changes, not retroactively attributed to the baseline.
3. **Part 3 — Cross-language implementation:** selected pattern instances are demonstrated in Java, Python, C++, and JavaScript with source, tests, and READMEs.

## Member allocation used in the current working records
- Member 1: Singleton — AuthService; Dependency Injection — FastAPI database session injection.
- Member 2: Singleton — PlansService; Strategy — Workout recommendation strategy.
- Member 3: Dependency Injection — Angular component constructor injection; Observer — Attendance event observer.

## Related pattern candidates
Trainer assignment Strategy and notification-state Observer have also appeared in earlier discussions. Include them in final counts only if they are part of the approved final inventory. Avoid counting the same collaboration twice.

## Classification discipline
- Singleton: Creational, but Angular root-injector services should be described as container-scoped singletons, not necessarily hand-written GoF Singleton implementations.
- Strategy: Behavioral.
- Observer: Behavioral.
- Dependency Injection: framework/architectural idiom; use the faculty's prescribed classification consistently and justify it.
- GRASP patterns should be named and counted separately from GoF patterns if the faculty requires that distinction.

## Evidence discipline
Never invent source line ranges, runtime versions, complexity values, or elapsed times. Keep production code separate from tests. Record the precise source version for each stage. A passing standalone demonstration does not prove that the full Angular/FastAPI application passes integration tests.
