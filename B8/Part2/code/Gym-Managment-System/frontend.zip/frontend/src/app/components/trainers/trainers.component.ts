import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TrainersService } from '../../services/trainers.service';
import { AuthService } from '../../services/auth.service';
import { Trainer } from '../../models/user.model';

@Component({
  selector: 'app-trainers',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <div>
          <h1>Trainers</h1>
          <p>Manage your fitness team</p>
        </div>
        <button class="btn btn-primary" *ngIf="auth.isAdmin()" (click)="openModal()">+ Add Trainer</button>
      </div>

      <div class="filters-bar">
        <input type="text" [(ngModel)]="search" (input)="onSearch()" placeholder="Search trainers..." class="search-input" />
      </div>

      <div class="loading" *ngIf="loading">Loading trainers...</div>

      <div class="trainers-grid" *ngIf="!loading">
        <div class="trainer-card" *ngFor="let t of trainers">
          <div class="trainer-avatar">{{ t.full_name[0] }}</div>
          <div class="trainer-info">
            <h3>{{ t.full_name }}</h3>
            <p class="specialization">{{ t.specialization }}</p>
            <p class="bio" *ngIf="t.bio">{{ t.bio }}</p>
            <div class="trainer-meta">
              <span>{{ t.rating.toFixed(1) }} / 5 ({{ t.rating_count }} reviews)</span>
              <span>{{ t.years_experience }} yrs exp</span>
              <span>\${{ t.hourly_rate }}/hr</span>
              <span *ngIf="auth.isAdmin()" class="capacity" [class.full]="(t.active_clients || 0) >= (t.max_clients || 0)">Clients {{ t.active_clients || 0 }} / {{ t.max_clients }}</span>
            </div>
          </div>
          <div class="trainer-actions" *ngIf="auth.isAdmin()">
            <button class="btn btn-outline btn-sm" (click)="editTrainer(t)">Edit</button>
            <button class="btn btn-danger btn-sm" (click)="deleteTrainer(t.id)">Remove</button>
          </div>
          <div class="trainer-actions" *ngIf="auth.isMember()">
            <button class="btn btn-outline btn-sm" (click)="openRating(t)">Rate Trainer</button>
          </div>
        </div>
        <div class="empty-state" *ngIf="trainers.length === 0">
          <div class="empty-icon">🏋️</div>
          <p>No trainers found.</p>
        </div>
      </div>

      <!-- Add/Edit Modal -->
      <div class="modal-overlay" *ngIf="showModal" (click)="closeModal()">
        <div class="modal" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>{{ editingTrainer ? 'Edit Trainer' : 'Add New Trainer' }}</h2>
            <button class="modal-close" (click)="closeModal()">✕</button>
          </div>
          <div class="modal-body">
            <ng-container *ngIf="!editingTrainer">
              <div class="form-row">
                <div class="form-group">
                  <label>Full Name *</label>
                  <input type="text" [(ngModel)]="form.full_name" class="form-control" />
                </div>
                <div class="form-group">
                  <label>Email *</label>
                  <input type="email" [(ngModel)]="form.email" class="form-control" />
                </div>
              </div>
              <div class="form-row">
                <div class="form-group">
                  <label>Phone *</label>
                  <input type="tel" [(ngModel)]="form.phone" class="form-control" />
                </div>
                <div class="form-group">
                  <label>Password *</label>
                  <input type="password" [(ngModel)]="form.password" class="form-control" />
                </div>
              </div>
            </ng-container>
            <ng-container *ngIf="editingTrainer">
              <div class="form-row">
                <div class="form-group">
                  <label>Full Name</label>
                  <input type="text" [(ngModel)]="form.full_name" class="form-control" />
                </div>
                <div class="form-group">
                  <label>Phone</label>
                  <input type="tel" [(ngModel)]="form.phone" class="form-control" />
                </div>
              </div>
            </ng-container>
            <div class="form-row">
              <div class="form-group">
                <label>Specialization *</label>
                <input type="text" [(ngModel)]="form.specialization" class="form-control" placeholder="e.g. Yoga, HIIT" />
              </div>
              <div class="form-group">
                <label>Hourly Rate ($)</label>
                <input type="number" [(ngModel)]="form.hourly_rate" class="form-control" min="0" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Years Experience</label>
                <input type="number" [(ngModel)]="form.years_experience" class="form-control" min="0" />
              </div>
              <div class="form-group">
                <label>Max Clients</label>
                <input type="number" [(ngModel)]="form.max_clients" class="form-control" min="1" />
              </div>
            </div>
            <div class="form-group">
              <label>Bio</label>
              <textarea [(ngModel)]="form.bio" class="form-control" rows="3"></textarea>
            </div>
            <div class="alert alert-error" *ngIf="formError">{{ formError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="closeModal()">Cancel</button>
            <button class="btn btn-primary" (click)="saveTrainer()" [disabled]="saving">
              {{ saving ? 'Saving...' : (editingTrainer ? 'Update' : 'Add Trainer') }}
            </button>
          </div>
        </div>
      </div>

      <!-- Rating Modal -->
      <div class="modal-overlay" *ngIf="showRatingModal" (click)="showRatingModal = false">
        <div class="modal modal-sm" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>Rate {{ ratingTrainer?.full_name }}</h2>
            <button class="modal-close" (click)="showRatingModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="star-rating">
              <button *ngFor="let s of [1,2,3,4,5]" class="star" [ngClass]="{ active: ratingValue >= s }" (click)="ratingValue = s">★</button>
            </div>
            <div class="form-group" style="margin-top:1rem">
              <label>Comment (optional)</label>
              <textarea [(ngModel)]="ratingComment" class="form-control" rows="2"></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="showRatingModal = false">Cancel</button>
            <button class="btn btn-primary" (click)="submitRating()">Submit Rating</button>
          </div>
        </div>
      </div>

      <div class="toast" *ngIf="toast" [ngClass]="toastType">{{ toast }}</div>
    </div>
  `,
  styles: [`
    .page-container { padding: 2rem; max-width: 1280px; margin: 0 auto; background: #0a0a0a; min-height: 100vh; }
    .page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 2rem; flex-wrap: wrap; gap: 1rem; }
    .page-header h1 { font-family: 'Bebas Neue', sans-serif; font-size: 2.5rem; letter-spacing: 0.05em; color: #fff; margin: 0; line-height: 1; }
    .page-header p { color: #666; margin-top: 0.4rem; font-size: 0.875rem; }
    .filters-bar { margin-bottom: 1.5rem; }
    .search-input { width: 100%; max-width: 400px; padding: 0.65rem 1rem; background: #111; border: 1px solid #2a2a2a; border-radius: 2px; color: #fff; font-size: 0.875rem; }
    .search-input:focus { outline: none; border-color: #fff; }
    .search-input::placeholder { color: #444; }
    .loading { text-align: center; padding: 4rem; color: #444; font-size: 0.8rem; letter-spacing: 0.1em; text-transform: uppercase; }
    .trainers-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1px; background: #1a1a1a; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; }
    .trainer-card { background: #0f0f0f; padding: 1.75rem; display: flex; flex-direction: column; gap: 1rem; transition: background 0.2s; }
    .trainer-card:hover { background: #141414; }
    .trainer-avatar { width: 56px; height: 56px; border-radius: 2px; background: #1a1a1a; border: 1px solid #2a2a2a; color: #fff; display: flex; align-items: center; justify-content: center; font-family: 'Bebas Neue', sans-serif; font-size: 1.6rem; letter-spacing: 0.05em; }
    .trainer-info h3 { font-family: 'Bebas Neue', sans-serif; font-size: 1.3rem; letter-spacing: 0.05em; color: #fff; margin: 0 0 0.3rem; }
    .specialization { color: #888; font-size: 0.75rem; font-weight: 700; letter-spacing: 0.1em; text-transform: uppercase; margin: 0 0 0.5rem; }
    .bio { font-size: 0.8rem; color: #555; margin: 0 0 0.5rem; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; line-height: 1.5; }
    .trainer-meta { display: flex; flex-wrap: wrap; gap: 0.75rem; font-size: 0.75rem; color: #555; }
    .capacity { color: #68d391; font-weight: 700; }
    .capacity.full { color: #fc8181; }
    .trainer-actions { display: flex; gap: 0.5rem; padding-top: 0.5rem; border-top: 1px solid #1a1a1a; }
    .empty-state { grid-column: 1/-1; text-align: center; padding: 5rem 2rem; color: #333; font-size: 0.875rem; }
    .empty-icon { font-size: 2rem; margin-bottom: 1rem; opacity: 0.3; }
    .btn { display: inline-flex; align-items: center; justify-content: center; padding: 0.5rem 1.25rem; border-radius: 2px; border: none; cursor: pointer; font-weight: 700; font-size: 0.7rem; letter-spacing: 0.1em; text-transform: uppercase; transition: all 0.2s; }
    .btn-primary { background: #fff; color: #000; }
    .btn-primary:disabled { opacity: 0.4; cursor: not-allowed; }
    .btn-outline { background: transparent; border: 1px solid #2a2a2a; color: #888; }
    .btn-outline:hover { border-color: #fff; color: #fff; }
    .btn-danger  { background: transparent; border: 1px solid rgba(229,62,62,0.3); color: #fc8181; }
    .btn-danger:hover { background: rgba(229,62,62,0.1); }
    .btn-sm { padding: 0.4rem 0.875rem; font-size: 0.68rem; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.88); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 1rem; }
    .modal { background: #111; border: 1px solid #2a2a2a; border-radius: 4px; width: 100%; max-width: 520px; max-height: 90vh; overflow-y: auto; }
    .modal-sm { max-width: 380px; }
    .modal-header { display: flex; justify-content: space-between; align-items: center; padding: 1.5rem; border-bottom: 1px solid #1a1a1a; }
    .modal-header h2 { font-family: 'Bebas Neue', sans-serif; font-size: 1.4rem; letter-spacing: 0.06em; color: #fff; margin: 0; }
    .modal-close { background: none; border: none; color: #555; cursor: pointer; font-size: 1.1rem; }
    .modal-close:hover { color: #fff; }
    .modal-body { padding: 1.5rem; }
    .modal-footer { padding: 1rem 1.5rem; border-top: 1px solid #1a1a1a; display: flex; justify-content: flex-end; gap: 0.75rem; }
    .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    .form-group { margin-bottom: 1rem; }
    .form-group label { display: block; font-size: 0.7rem; font-weight: 700; letter-spacing: 0.12em; text-transform: uppercase; color: #666; margin-bottom: 0.4rem; }
    .form-control { width: 100%; padding: 0.75rem 0.875rem; background: #0a0a0a; border: 1px solid #2a2a2a; border-radius: 2px; color: #fff; font-size: 0.9rem; box-sizing: border-box; }
    .form-control:focus { outline: none; border-color: #fff; }
    textarea.form-control { resize: vertical; }
    .alert { padding: 0.75rem 1rem; border-radius: 2px; margin-bottom: 1rem; font-size: 0.85rem; }
    .alert-error { background: rgba(229,62,62,0.1); color: #fc8181; border: 1px solid rgba(229,62,62,0.3); }
    .star-rating { display: flex; gap: 0.5rem; justify-content: center; }
    .star { background: none; border: none; font-size: 2.5rem; cursor: pointer; color: #222; transition: color 0.2s; }
    .star.active { color: #fff; }
    .toast { position: fixed; bottom: 2rem; right: 2rem; padding: 0.875rem 1.5rem; border-radius: 2px; font-weight: 700; font-size: 0.8rem; letter-spacing: 0.06em; z-index: 2000; }
    .toast.success { background: #111; color: #68d391; border: 1px solid rgba(56,161,105,0.4); }
    .toast.error   { background: #111; color: #fc8181; border: 1px solid rgba(229,62,62,0.4); }
    @media (max-width: 640px) { .form-row { grid-template-columns: 1fr; } .trainers-grid { grid-template-columns: 1fr; } }
  `]
})
export class TrainersComponent implements OnInit {
  trainers: Trainer[] = [];
  loading = false;
  showModal = false;
  editingTrainer: Trainer | null = null;
  saving = false;
  formError = '';
  toast = '';
  toastType = 'success';
  search = '';
  searchTimeout: any;
  showRatingModal = false;
  ratingTrainer: Trainer | null = null;
  ratingValue = 0;
  ratingComment = '';

  form: any = { full_name: '', email: '', phone: '', password: '', specialization: '', bio: '', hourly_rate: 0, years_experience: 0, max_clients: 10 };

  constructor(public auth: AuthService, private trainersService: TrainersService) {}

  ngOnInit() { this.loadTrainers(); }

  loadTrainers() {
    this.loading = true;
    this.trainersService.getAll(this.search).subscribe({
      next: t => { this.trainers = t; this.loading = false; },
      error: () => this.loading = false
    });
  }

  onSearch() { clearTimeout(this.searchTimeout); this.searchTimeout = setTimeout(() => this.loadTrainers(), 400); }

  openModal() {
    this.editingTrainer = null;
    this.form = { full_name: '', email: '', phone: '', password: '', specialization: '', bio: '', hourly_rate: 0, years_experience: 0, max_clients: 10 };
    this.formError = '';
    this.showModal = true;
  }

  editTrainer(t: Trainer) {
    this.editingTrainer = t;
    this.form = { full_name: t.full_name, phone: t.phone, specialization: t.specialization, bio: t.bio || '', hourly_rate: t.hourly_rate, years_experience: t.years_experience, max_clients: t.max_clients || 10 };
    this.formError = '';
    this.showModal = true;
  }

  closeModal() { this.showModal = false; }

  saveTrainer() {
    this.saving = true;
    this.formError = '';
    const obs = this.editingTrainer
      ? this.trainersService.update(this.editingTrainer.id, this.form)
      : this.trainersService.create(this.form);
    obs.subscribe({
      next: () => { this.saving = false; this.showToast(this.editingTrainer ? 'Trainer updated!' : 'Trainer added!', 'success'); this.closeModal(); this.loadTrainers(); },
      error: (err) => { this.saving = false; this.formError = err.error?.detail || 'Failed to save.'; }
    });
  }

  deleteTrainer(id: number) {
    if (!confirm('Remove this trainer?')) return;
    this.trainersService.delete(id).subscribe({
      next: () => { this.showToast('Trainer removed.', 'success'); this.loadTrainers(); },
      error: () => this.showToast('Failed to remove.', 'error')
    });
  }

  openRating(t: Trainer) { this.ratingTrainer = t; this.ratingValue = 0; this.ratingComment = ''; this.showRatingModal = true; }

  submitRating() {
    if (!this.ratingTrainer || this.ratingValue === 0) return;
    this.trainersService.rateTrainer({ trainer_id: this.ratingTrainer.id, rating: this.ratingValue, comment: this.ratingComment }).subscribe({
      next: () => { this.showRatingModal = false; this.showToast('Rating submitted!', 'success'); this.loadTrainers(); },
      error: () => this.showToast('Failed to submit rating.', 'error')
    });
  }

  showToast(msg: string, type: string) { this.toast = msg; this.toastType = type; setTimeout(() => this.toast = '', 3000); }
}
