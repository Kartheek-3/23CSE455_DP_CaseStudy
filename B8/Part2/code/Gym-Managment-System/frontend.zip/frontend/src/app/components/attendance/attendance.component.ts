import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AttendanceService } from '../../services/attendance.service';
import { ClassesService } from '../../services/classes.service';
import { MembersService } from '../../services/members.service';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-attendance',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="pg">
      <div class="pg-head">
        <h1 class="pg-title">ATTENDANCE</h1>
        <p class="pg-sub">{{ auth.isMember() ? 'Generate your QR code to check in' : 'Track and manage attendance' }}</p>
      </div>

      <!-- ── MEMBER VIEW ── -->
      <ng-container *ngIf="auth.isMember()">
        <div class="qr-layout">
          <div class="qr-panel">
            <div class="panel-label">QR CHECK-IN</div>
            <h2 class="panel-title">YOUR ACCESS CODE</h2>
            <p class="panel-hint">Show this to your trainer. Code expires in 30 seconds.</p>
            <div class="fg">
              <label>SELECT CLASS (OPTIONAL)</label>
              <select [(ngModel)]="selectedClassId" class="fi">
                <option [ngValue]="null">— Any Class —</option>
                <option *ngFor="let c of myClasses" [ngValue]="c.id">{{ c.name }} · {{ c.start_time | date:'MMM d, h:mm a' }}</option>
              </select>
            </div>
            <button class="btn-w btn-full" (click)="generateQR()" [disabled]="generatingQR">
              <span class="spin" *ngIf="generatingQR"></span>
              {{ generatingQR ? 'GENERATING...' : 'GENERATE QR CODE' }}
            </button>
            <div class="qr-box" *ngIf="qrData">
              <img [src]="qrData.qr_image" alt="QR Code" class="qr-img" />
              <div class="qr-timer" [ngClass]="{ urgent: timeLeft <= 10 }">
                EXPIRES IN {{ timeLeft }}s
              </div>
              <div class="qr-expired-msg" *ngIf="timeLeft <= 0">CODE EXPIRED — GENERATE NEW</div>
            </div>
          </div>

          <div class="streak-panel" *ngIf="streak">
            <div class="streak-block">
              <div class="streak-num">{{ streak.streak }}</div>
              <div class="streak-lbl">DAY STREAK</div>
            </div>
            <div class="streak-sep"></div>
            <div class="streak-block">
              <div class="streak-num">{{ streak.total_attended }}</div>
              <div class="streak-lbl">TOTAL SESSIONS</div>
            </div>
          </div>
        </div>

        <div class="section-hd">MY ATTENDANCE HISTORY</div>
        <div class="tbl-wrap">
          <table class="tbl">
            <thead><tr><th>CLASS</th><th>DATE & TIME</th><th>METHOD</th></tr></thead>
            <tbody>
              <tr *ngFor="let r of myAttendance">
                <td>{{ r.class_name || '—' }}</td>
                <td>{{ r.marked_at | date:'MMM d, yyyy · h:mm a' }}</td>
                <td><span class="mbadge" [ngClass]="r.method">{{ r.method | uppercase }}</span></td>
              </tr>
              <tr *ngIf="myAttendance.length === 0"><td colspan="3" class="empty-row">NO RECORDS YET</td></tr>
            </tbody>
          </table>
        </div>
      </ng-container>

      <!-- ── TRAINER / ADMIN VIEW ── -->
      <ng-container *ngIf="auth.isTrainer() || auth.isAdmin()">
        <div class="tabs">
          <button class="tab" [class.active]="activeTab==='manual'" (click)="activeTab='manual'">MANUAL ATTENDANCE</button>
          <button class="tab" [class.active]="activeTab==='scan'"   (click)="activeTab='scan'">QR SCANNER</button>
          <button class="tab" [class.active]="activeTab==='report'" (click)="activeTab='report'">REPORTS</button>
        </div>

        <!-- Manual Tab -->
        <div *ngIf="activeTab==='manual'">
          <div class="dark-card">
            <div class="card-label">MARK ATTENDANCE</div>
            <div class="f2">
              <div class="fg">
                <label>SELECT CLASS *</label>
                <select [(ngModel)]="manualForm.class_id" (change)="loadRoster()" class="fi">
                  <option [ngValue]="null">— Select Class —</option>
                  <option *ngFor="let c of allClasses" [ngValue]="c.id">{{ c.name }} · {{ c.start_time | date:'MMM d, h:mm a' }}</option>
                </select>
              </div>
              <div class="fg">
                <label>SELECT MEMBER *</label>
                <select [(ngModel)]="manualForm.member_id" class="fi">
                  <option [ngValue]="null">— Select Member —</option>
                  <option *ngFor="let m of rosterMembers" [ngValue]="m.member_id">{{ m.member_name }}</option>
                </select>
              </div>
            </div>
            <button class="btn-w" (click)="markManual()" [disabled]="!manualForm.class_id || !manualForm.member_id || markingAttendance">
              <span class="spin" *ngIf="markingAttendance"></span>
              {{ markingAttendance ? 'MARKING...' : 'MARK PRESENT' }}
            </button>
            <button class="btn-ghost close-btn" (click)="closeClass()" [disabled]="!manualForm.class_id || closingClass"
                    title="Marks everyone still booked as a no-show and notifies them and their trainer">
              {{ closingClass ? 'CLOSING...' : 'CLOSE CLASS &amp; MARK NO-SHOWS' }}
            </button>
            <div class="err" *ngIf="manualError">{{ manualError }}</div>
            <div class="ok"  *ngIf="manualSuccess">{{ manualSuccess }}</div>
          </div>

          <div class="dark-card" *ngIf="manualForm.class_id && rosterMembers.length > 0">
            <div class="card-label">CLASS ROSTER</div>
            <div class="roster">
              <div class="roster-row" *ngFor="let m of rosterMembers">
                <div class="r-avatar">{{ m.member_name?.[0] }}</div>
                <span class="r-name">{{ m.member_name }}</span>
                <button class="btn-ghost btn-sm" (click)="quickMark(m.member_id)">MARK PRESENT</button>
              </div>
            </div>
          </div>
        </div>

        <!-- QR Scanner Tab -->
        <div *ngIf="activeTab==='scan'">
          <div class="dark-card">
            <div class="card-label">QR CODE SCANNER</div>
            <p class="card-hint">Select the class, then paste or scan the member's QR token.</p>
            <div class="fg">
              <label>SELECT CLASS *</label>
              <select [(ngModel)]="scanForm.class_id" class="fi">
                <option [ngValue]="null">— Select Class —</option>
                <option *ngFor="let c of allClasses" [ngValue]="c.id">{{ c.name }} · {{ c.start_time | date:'MMM d, h:mm a' }}</option>
              </select>
            </div>
            <div class="fg">
              <label>QR TOKEN *</label>
              <textarea [(ngModel)]="scanForm.qr_token" class="fi" rows="3" placeholder="Paste QR token here..."></textarea>
            </div>
            <button class="btn-w" (click)="processScan()" [disabled]="!scanForm.class_id || !scanForm.qr_token || scanning">
              <span class="spin" *ngIf="scanning"></span>
              {{ scanning ? 'PROCESSING...' : 'PROCESS SCAN' }}
            </button>
            <div class="scan-ok" *ngIf="scanResult">
              <strong>{{ scanResult.member_name }}</strong> checked in to <strong>{{ scanResult.class_name }}</strong>
              <span class="scan-time">{{ scanResult.checked_in_at | date:'h:mm:ss a' }}</span>
            </div>
            <div class="err" *ngIf="scanError">{{ scanError }}</div>
          </div>
        </div>

        <!-- Reports Tab -->
        <div *ngIf="activeTab==='report'">
          <div class="dark-card">
            <div class="card-label">GENERATE REPORT</div>
            <div class="f3">
              <div class="fg"><label>FROM DATE</label><input type="date" [(ngModel)]="reportFilters.from_date" class="fi" /></div>
              <div class="fg"><label>TO DATE</label><input type="date" [(ngModel)]="reportFilters.to_date" class="fi" /></div>
              <div class="fg"><label>CLASS</label>
                <select [(ngModel)]="reportFilters.class_id" class="fi">
                  <option [ngValue]="null">All Classes</option>
                  <option *ngFor="let c of allClasses" [ngValue]="c.id">{{ c.name }}</option>
                </select>
              </div>
            </div>
            <button class="btn-w" (click)="loadReport()">GENERATE REPORT</button>
          </div>

          <div class="stats-strip" *ngIf="stats">
            <div class="sbox"><div class="sval">{{ stats.today }}</div><div class="slbl">TODAY</div></div>
            <div class="sbox"><div class="sval">{{ stats.this_week }}</div><div class="slbl">THIS WEEK</div></div>
            <div class="sbox"><div class="sval">{{ stats.total }}</div><div class="slbl">ALL TIME</div></div>
          </div>

          <div class="tbl-wrap" *ngIf="reportData.length > 0">
            <table class="tbl">
              <thead><tr><th>MEMBER</th><th>CLASS</th><th>DATE & TIME</th><th>METHOD</th></tr></thead>
              <tbody>
                <tr *ngFor="let r of reportData">
                  <td>{{ r.member_name || '—' }}</td>
                  <td>{{ r.class_name || '—' }}</td>
                  <td>{{ r.marked_at | date:'MMM d, yyyy · h:mm a' }}</td>
                  <td><span class="mbadge" [ngClass]="r.method">{{ r.method | uppercase }}</span></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="empty-row" *ngIf="reportData.length===0 && reportLoaded">NO RECORDS FOUND</div>
        </div>
      </ng-container>

      <div class="toast" *ngIf="toast" [ngClass]="toastType">{{ toast }}</div>
    </div>
  `,
  styles: [`
    .pg      { padding: 2rem; max-width: 1100px; margin: 0 auto; min-height: 100vh; }
    .pg-head { margin-bottom: 2rem; }
    .pg-title{ font-family: 'Bebas Neue', sans-serif; font-size: 2.5rem; letter-spacing: 0.05em; color: #fff; margin: 0; line-height: 1; }
    .pg-sub  { color: #555; margin-top: 0.4rem; font-size: 0.875rem; }

    /* Buttons */
    .btn-w   { display: inline-flex; align-items: center; justify-content: center; gap: 0.4rem; padding: 0.75rem 1.75rem; background: #fff; color: #000; border: none; border-radius: 2px; font-weight: 800; font-size: 0.75rem; letter-spacing: 0.1em; cursor: pointer; transition: background 0.2s; }
    .btn-w:hover:not(:disabled) { background: #e0e0e0; }
    .btn-w:disabled { opacity: 0.4; cursor: not-allowed; }
    .btn-full{ width: 100%; margin-bottom: 1.5rem; }
    .btn-ghost{ display: inline-flex; align-items: center; padding: 0.5rem 1rem; background: transparent; border: 1px solid #2a2a2a; color: #666; border-radius: 2px; font-weight: 700; font-size: 0.7rem; letter-spacing: 0.1em; cursor: pointer; transition: all 0.2s; }
    .btn-ghost:hover { border-color: #fff; color: #fff; }
    .btn-sm  { padding: 0.4rem 0.875rem; font-size: 0.68rem; }
    .spin    { display: inline-block; width: 12px; height: 12px; border: 2px solid rgba(0,0,0,0.2); border-top-color: #000; border-radius: 50%; animation: sp 0.7s linear infinite; }
    @keyframes sp { to { transform: rotate(360deg); } }

    /* Tabs */
    .tabs { display: flex; margin-bottom: 2rem; border-bottom: 1px solid #1a1a1a; }
    .tab  { padding: 0.875rem 1.5rem; background: none; border: none; cursor: pointer; font-weight: 800; font-size: 0.72rem; letter-spacing: 0.12em; color: #444; border-bottom: 2px solid transparent; margin-bottom: -1px; transition: all 0.2s; }
    .tab:hover  { color: #888; }
    .tab.active { color: #fff; border-bottom-color: #fff; }

    /* Cards */
    .dark-card  { background: #111; border: 1px solid #1a1a1a; border-radius: 4px; padding: 1.75rem; margin-bottom: 1.5rem; }
    .card-label { font-size: 0.62rem; font-weight: 800; letter-spacing: 0.2em; color: #444; text-transform: uppercase; margin-bottom: 1.25rem; }
    .card-hint  { font-size: 0.8rem; color: #555; margin-bottom: 1.25rem; line-height: 1.6; }

    /* Form */
    .f2  { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; margin-bottom: 1.25rem; }
    .f3  { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 1rem; margin-bottom: 1.25rem; }
    .fg  { margin-bottom: 1rem; }
    .fg label { display: block; font-size: 0.62rem; font-weight: 800; letter-spacing: 0.15em; color: #555; margin-bottom: 0.4rem; }
    .fi  { width: 100%; padding: 0.75rem 0.875rem; background: #0a0a0a; border: 1px solid #2a2a2a; border-radius: 2px; color: #fff; font-size: 0.875rem; box-sizing: border-box; transition: border-color 0.2s; font-family: inherit; }
    .fi:focus { outline: none; border-color: #fff; }
    .fi::placeholder { color: #333; }
    select.fi option { background: #111; }
    textarea.fi { resize: vertical; }

    /* Alert boxes */
    .err { padding: 0.75rem 1rem; background: rgba(229,62,62,0.08); color: #fc8181; border: 1px solid rgba(229,62,62,0.25); border-radius: 2px; font-size: 0.825rem; margin-top: 0.875rem; }
    .ok  { padding: 0.75rem 1rem; background: rgba(56,161,105,0.08); color: #68d391; border: 1px solid rgba(56,161,105,0.25); border-radius: 2px; font-size: 0.825rem; margin-top: 0.875rem; }

    /* QR Layout (member) */
    .qr-layout   { display: grid; grid-template-columns: 1fr 220px; gap: 1.5rem; margin-bottom: 2rem; align-items: start; }
    .qr-panel    { background: #111; border: 1px solid #1a1a1a; border-radius: 4px; padding: 1.75rem; }
    .panel-label { font-size: 0.62rem; font-weight: 800; letter-spacing: 0.2em; color: #444; margin-bottom: 0.75rem; }
    .panel-title { font-family: 'Bebas Neue', sans-serif; font-size: 1.6rem; letter-spacing: 0.06em; color: #fff; margin: 0 0 0.5rem; }
    .panel-hint  { font-size: 0.8rem; color: #555; margin-bottom: 1.5rem; line-height: 1.6; }
    .qr-box      { text-align: center; margin-top: 1.5rem; padding-top: 1.5rem; border-top: 1px solid #1a1a1a; }
    .qr-img      { width: 180px; height: 180px; border: 1px solid #2a2a2a; border-radius: 4px; padding: 8px; background: #fff; }
    .qr-timer    { margin-top: 1rem; font-size: 0.75rem; font-weight: 800; letter-spacing: 0.15em; color: #888; }
    .qr-timer.urgent { color: #fc8181; animation: pulse 1s infinite; }
    .qr-expired-msg  { font-size: 0.75rem; font-weight: 800; letter-spacing: 0.1em; color: #fc8181; margin-top: 0.5rem; }
    @keyframes pulse { 0%,100% { opacity: 1; } 50% { opacity: 0.4; } }

    /* Streak panel */
    .streak-panel { background: #111; border: 1px solid #1a1a1a; border-radius: 4px; padding: 1.75rem; display: flex; flex-direction: column; align-items: center; gap: 1.25rem; }
    .streak-block { text-align: center; }
    .streak-num   { font-family: 'Bebas Neue', sans-serif; font-size: 3rem; color: #fff; line-height: 1; }
    .streak-lbl   { font-size: 0.62rem; font-weight: 800; letter-spacing: 0.15em; color: #444; margin-top: 0.25rem; }
    .streak-sep   { width: 100%; height: 1px; background: #1a1a1a; }

    /* Roster */
    .roster     { display: flex; flex-direction: column; gap: 1px; background: #1a1a1a; border-radius: 2px; overflow: hidden; }
    .roster-row { display: flex; align-items: center; gap: 0.875rem; padding: 0.875rem 1rem; background: #0f0f0f; }
    .r-avatar   { width: 30px; height: 30px; border-radius: 2px; background: #1a1a1a; border: 1px solid #2a2a2a; color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 0.85rem; font-family: 'Bebas Neue', sans-serif; flex-shrink: 0; }
    .r-name     { flex: 1; font-size: 0.875rem; color: #ccc; }

    /* Scan result */
    .scan-ok  { display: flex; flex-direction: column; gap: 0.25rem; padding: 1rem; background: rgba(56,161,105,0.08); border: 1px solid rgba(56,161,105,0.25); border-radius: 2px; margin-top: 1rem; font-size: 0.875rem; color: #68d391; }
    .scan-time{ font-size: 0.75rem; color: #555; }

    /* Stats strip */
    .stats-strip { display: flex; gap: 1px; background: #1a1a1a; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; margin-bottom: 1.5rem; }
    .sbox { flex: 1; background: #0f0f0f; padding: 1.25rem 1.75rem; display: flex; flex-direction: column; align-items: center; }
    .sval { font-family: 'Bebas Neue', sans-serif; font-size: 2.5rem; color: #fff; line-height: 1; }
    .slbl { font-size: 0.62rem; font-weight: 800; letter-spacing: 0.15em; color: #444; margin-top: 0.3rem; }

    /* Table */
    .section-hd { font-family: 'Bebas Neue', sans-serif; font-size: 1.3rem; letter-spacing: 0.06em; color: #fff; margin-bottom: 1rem; padding-bottom: 0.75rem; border-bottom: 1px solid #1a1a1a; }
    .tbl-wrap { background: #111; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; overflow-x: auto; margin-bottom: 1.5rem; }
    .tbl  { width: 100%; border-collapse: collapse; min-width: 400px; }
    .tbl th { background: #0a0a0a; padding: 0.875rem 1rem; text-align: left; font-size: 0.62rem; font-weight: 800; color: #444; letter-spacing: 0.14em; border-bottom: 1px solid #1a1a1a; }
    .tbl td { padding: 1rem; border-bottom: 1px solid #161616; font-size: 0.875rem; color: #aaa; }
    .tbl tr:last-child td { border-bottom: none; }
    .tbl tr:hover td { background: #141414; }
    .mbadge { display: inline-block; padding: 0.2rem 0.6rem; border-radius: 2px; font-size: 0.62rem; font-weight: 800; letter-spacing: 0.1em; }
    .mbadge.manual { background: rgba(255,255,255,0.06); color: #888; border: 1px solid #2a2a2a; }
    .mbadge.qr     { background: rgba(56,161,105,0.1); color: #68d391; border: 1px solid rgba(56,161,105,0.25); }
    .empty-row { text-align: center; color: #333; padding: 3rem; font-size: 0.72rem; font-weight: 800; letter-spacing: 0.15em; }

    /* Toast */
    .toast { position: fixed; bottom: 2rem; right: 2rem; padding: 0.875rem 1.5rem; border-radius: 2px; font-weight: 700; font-size: 0.78rem; letter-spacing: 0.08em; z-index: 2000; }
    .toast.success { background: #0f0f0f; color: #68d391; border: 1px solid rgba(56,161,105,0.3); }
    .close-btn { margin-left: 0.75rem; }
    .toast.error   { background: #0f0f0f; color: #fc8181; border: 1px solid rgba(229,62,62,0.3); }

    @media (max-width: 768px) {
      .pg { padding: 1rem; }
      .qr-layout { grid-template-columns: 1fr; }
      .f2, .f3   { grid-template-columns: 1fr; }
    }
  `]
})
export class AttendanceComponent implements OnInit, OnDestroy {
  activeTab = 'manual';
  allClasses: any[] = []; myClasses: any[] = []; rosterMembers: any[] = [];
  myAttendance: any[] = []; reportData: any[] = []; reportLoaded = false;
  stats: any = null; streak: any = null; qrData: any = null; timeLeft = 0;
  generatingQR = false; selectedClassId: number | null = null;
  markingAttendance = false; scanning = false; closingClass = false;
  scanResult: any = null; scanError = ''; manualError = ''; manualSuccess = '';
  toast = ''; toastType = 'success';
  private timerInterval: any;

  manualForm: any = { class_id: null, member_id: null };
  scanForm: any = { class_id: null, qr_token: '' };
  reportFilters: any = { from_date: '', to_date: '', class_id: null };

  constructor(public auth: AuthService, private attendanceService: AttendanceService, private classesService: ClassesService, private membersService: MembersService) {}

  ngOnInit() {
    if (this.auth.isMember()) {
      this.membersService.getMe().subscribe(m => {
        this.classesService.getMemberSchedule(m.id).subscribe(b => this.myClasses = b as any);
        this.attendanceService.getMemberStreak(m.id).subscribe(s => this.streak = s);
        this.attendanceService.getReport({ member_id: m.id }).subscribe(r => this.myAttendance = r);
      });
    } else {
      this.classesService.getAll().subscribe(c => this.allClasses = c);
      this.attendanceService.getStats().subscribe(s => this.stats = s);
    }
  }

  ngOnDestroy() { clearInterval(this.timerInterval); }

  generateQR() {
    this.generatingQR = true;
    this.attendanceService.generateQR(this.selectedClassId || undefined).subscribe({
      next: (data) => {
        this.qrData = data; this.generatingQR = false; this.timeLeft = 30;
        clearInterval(this.timerInterval);
        this.timerInterval = setInterval(() => { this.timeLeft--; if (this.timeLeft <= 0) { clearInterval(this.timerInterval); this.qrData = null; } }, 1000);
      },
      error: () => { this.generatingQR = false; this.showToast('Failed to generate QR.', 'error'); }
    });
  }

  loadRoster() { if (!this.manualForm.class_id) return; this.classesService.getRoster(this.manualForm.class_id).subscribe(r => this.rosterMembers = r); }

  markManual() {
    this.markingAttendance = true; this.manualError = ''; this.manualSuccess = '';
    this.attendanceService.markManual({ member_id: this.manualForm.member_id, class_id: this.manualForm.class_id }).subscribe({
      next: (r) => { this.markingAttendance = false; this.manualSuccess = `Attendance marked for ${r.member_name}`; this.manualForm.member_id = null; },
      error: (err) => { this.markingAttendance = false; this.manualError = err.error?.detail || 'Failed.'; }
    });
  }

  quickMark(memberId: number) {
    if (!this.manualForm.class_id) return;
    this.attendanceService.markManual({ member_id: memberId, class_id: this.manualForm.class_id }).subscribe({
      next: (r) => { this.showToast(`Marked: ${r.member_name}`, 'success'); this.loadRoster(); },
      error: (err) => this.showToast(err.error?.detail || 'Failed.', 'error')
    });
  }

  closeClass() {
    if (!this.manualForm.class_id) return;
    if (!confirm('Mark every member still booked in this class as a no-show and notify them?')) return;
    this.closingClass = true; this.manualError = ''; this.manualSuccess = '';
    this.attendanceService.closeClass(this.manualForm.class_id).subscribe({
      next: (r) => {
        this.closingClass = false;
        this.manualSuccess = r.no_shows ? `${r.class_name} closed: ${r.no_shows} no-show(s) notified.` : `${r.class_name} closed: no no-shows.`;
        this.loadRoster();
      },
      error: (err) => { this.closingClass = false; this.manualError = err.error?.detail || 'Failed to close class.'; }
    });
  }

  processScan() {
    this.scanning = true; this.scanError = ''; this.scanResult = null;
    this.attendanceService.scanQR(this.scanForm.qr_token, this.scanForm.class_id).subscribe({
      next: (r) => { this.scanning = false; this.scanResult = r; this.scanForm.qr_token = ''; },
      error: (err) => { this.scanning = false; this.scanError = err.error?.detail || 'Invalid QR code.'; }
    });
  }

  loadReport() {
    const filters: any = {};
    if (this.reportFilters.from_date) filters.from_date = this.reportFilters.from_date;
    if (this.reportFilters.to_date) filters.to_date = this.reportFilters.to_date;
    if (this.reportFilters.class_id) filters.class_id = this.reportFilters.class_id;
    this.attendanceService.getReport(filters).subscribe(r => { this.reportData = r; this.reportLoaded = true; });
  }

  showToast(msg: string, type: string) { this.toast = msg; this.toastType = type; setTimeout(() => this.toast = '', 3000); }
}
