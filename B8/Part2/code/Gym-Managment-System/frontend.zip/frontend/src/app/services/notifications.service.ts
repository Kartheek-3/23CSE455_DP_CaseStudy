import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, Subscription, timer, switchMap, tap, catchError, of } from 'rxjs';
import { Notification } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class NotificationsService {
  private apiUrl = `${environment.apiUrl}/notifications`;
  private unreadCountSubject = new BehaviorSubject<number>(0);
  private latestSubject = new BehaviorSubject<Notification[]>([]);
  private polling?: Subscription;

  unreadCount$ = this.unreadCountSubject.asObservable();
  latest$ = this.latestSubject.asObservable();

  constructor(private http: HttpClient) {}

  getMyNotifications(params: { channel?: string; unread_only?: boolean; limit?: number } = {}): Observable<Notification[]> {
    const query: any = {};
    if (params.channel) query.channel = params.channel;
    if (params.unread_only) query.unread_only = true;
    if (params.limit) query.limit = params.limit;
    return this.http.get<Notification[]>(`${this.apiUrl}/`, { params: query });
  }

  getUnreadCount(): Observable<{ unread: number }> {
    return this.http.get<{ unread: number }>(`${this.apiUrl}/unread-count`);
  }

  startPolling(intervalMs = 30000): void {
    if (this.polling) return;
    this.polling = timer(0, intervalMs).pipe(
      switchMap(() => this.getUnreadCount().pipe(catchError(() => of(null))))
    ).subscribe(res => {
      if (!res) return;
      if (res.unread !== this.unreadCountSubject.value || !this.latestSubject.value.length) this.refreshLatest();
      this.unreadCountSubject.next(res.unread);
    });
  }

  stopPolling(): void {
    this.polling?.unsubscribe();
    this.polling = undefined;
    this.unreadCountSubject.next(0);
    this.latestSubject.next([]);
  }

  refresh(): void {
    this.getUnreadCount().subscribe({ next: res => this.unreadCountSubject.next(res.unread), error: () => {} });
    this.refreshLatest();
  }

  private refreshLatest(): void {
    this.getMyNotifications({ channel: 'in_app', limit: 15 }).subscribe({
      next: list => this.latestSubject.next(list),
      error: () => {},
    });
  }

  markRead(id: number): Observable<Notification> {
    return this.http.put<Notification>(`${this.apiUrl}/${id}/read`, {}).pipe(tap(() => this.refresh()));
  }

  markAllRead(): Observable<{ updated: number }> {
    return this.http.put<{ updated: number }>(`${this.apiUrl}/read-all`, {}).pipe(tap(() => this.refresh()));
  }

  getSettings(): Observable<any> {
    return this.http.get(`${this.apiUrl}/settings`);
  }

  updateSettings(data: any): Observable<any> {
    return this.http.put(`${this.apiUrl}/settings`, data);
  }
}
