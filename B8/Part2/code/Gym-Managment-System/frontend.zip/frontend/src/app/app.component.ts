import { Component, OnDestroy, OnInit } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { AuthService } from './services/auth.service';
import { NotificationsService } from './services/notifications.service';
import { Notification } from './models/user.model';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <ng-container *ngIf="auth.isLoggedIn(); else publicPage">
      <div class="layout">

        <!-- Sidebar -->
        <aside class="sidebar" [class.open]="sidebarOpen">
          <div class="sidebar-brand">
            <a routerLink="/dashboard" class="brand-link">
              <span class="brand-name">GYM</span>
              <span class="brand-sub">MANAGER</span>
            </a>
            <button class="sidebar-close-btn" (click)="sidebarOpen=false">X</button>
          </div>

          <div class="sidebar-role">
            <span class="role-pill">{{ auth.getRole() | uppercase }}</span>
            <button class="bell-btn" (click)="toggleNotifications()" title="Notifications">
              ALERTS
              <span class="bell-badge" *ngIf="(notifications.unreadCount$ | async) as count">{{ count > 99 ? '99+' : count }}</span>
            </button>
          </div>

          <nav class="sidebar-nav">
            <div class="nav-group">
              <span class="nav-group-label">Main</span>
              <a routerLink="/dashboard" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Dashboard
              </a>
              <a routerLink="/classes" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Classes
              </a>
              <a routerLink="/attendance" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Attendance
              </a>
              <a routerLink="/plans" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Plans
              </a>
              <a routerLink="/payments" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Payments
              </a>
            </div>

            <div class="nav-group" *ngIf="auth.isAdmin()">
              <span class="nav-group-label">Admin</span>
              <a routerLink="/members" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Members
              </a>
              <a routerLink="/trainers" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                Trainers
              </a>
            </div>

            <div class="nav-group" *ngIf="auth.isTrainer()">
              <span class="nav-group-label">Trainer</span>
              <a routerLink="/members" routerLinkActive="active" class="nav-link" (click)="sidebarOpen=false">
                My Members
              </a>
            </div>
          </nav>

          <div class="sidebar-footer">
            <button class="sidebar-logout" (click)="logout()">
              Sign Out
            </button>
          </div>
        </aside>

        <!-- Backdrop -->
        <div class="backdrop" *ngIf="sidebarOpen" (click)="sidebarOpen=false"></div>

        <!-- Main -->
        <div class="main">
          <header class="topbar">
            <button class="topbar-menu" (click)="sidebarOpen=true">
              <span></span><span></span><span></span>
            </button>
            <span class="topbar-brand">GYMMANAGER</span>
            <span class="topbar-role">{{ auth.getRole() | uppercase }}</span>
            <button class="bell-btn" (click)="toggleNotifications()">
              ALERTS
              <span class="bell-badge" *ngIf="(notifications.unreadCount$ | async) as count">{{ count > 99 ? '99+' : count }}</span>
            </button>
          </header>

          <div class="notif-panel" *ngIf="notificationsOpen">
            <div class="notif-head">
              <span>Notifications</span>
              <div class="notif-head-actions">
                <button class="notif-link" (click)="markAllRead()">Mark all read</button>
                <button class="notif-link" (click)="notificationsOpen=false">Close</button>
              </div>
            </div>
            <label class="notif-toggle">
              <input type="checkbox" [checked]="attendanceAlerts" (change)="toggleAttendanceAlerts($event)">
              Email / SMS attendance alerts
            </label>
            <div class="notif-list">
              <div *ngFor="let n of notifications.latest$ | async" class="notif-item" [class.unread]="!n.is_read" (click)="markRead(n)">
                <div class="notif-subject">{{ n.subject || n.type }}</div>
                <div class="notif-content">{{ n.content }}</div>
                <div class="notif-time">{{ n.created_at | date:'MMM d, h:mm a' }}</div>
              </div>
              <div class="notif-empty" *ngIf="!(notifications.latest$ | async)?.length">No notifications yet.</div>
            </div>
          </div>
          <div class="content">
            <router-outlet></router-outlet>
          </div>
        </div>
      </div>
    </ng-container>

    <ng-template #publicPage>
      <router-outlet></router-outlet>
    </ng-template>
  `,
  styles: [`
    .layout { display: flex; min-height: 100vh; background: #0a0a0a; }

    /* ── Sidebar ── */
    .sidebar {
      width: 220px; flex-shrink: 0;
      background: #000; border-right: 1px solid #1a1a1a;
      display: flex; flex-direction: column;
      position: fixed; top: 0; left: 0; height: 100vh; z-index: 500;
      transition: transform 0.3s ease;
    }
    .sidebar-brand {
      padding: 1.75rem 1.5rem 1.25rem;
      border-bottom: 1px solid #1a1a1a;
      display: flex; align-items: center; justify-content: space-between;
    }
    .brand-link { display: flex; flex-direction: column; line-height: 1; text-decoration: none; }
    .brand-name { font-family: 'Bebas Neue', sans-serif; font-size: 1.6rem; color: #fff; letter-spacing: 0.1em; }
    .brand-sub  { font-size: 0.6rem; font-weight: 700; letter-spacing: 0.25em; color: #555; text-transform: uppercase; }
    .sidebar-close-btn { display: none; background: none; border: none; color: #555; cursor: pointer; font-size: 1rem; font-weight: 700; }

    .sidebar-role { padding: 1rem 1.5rem; border-bottom: 1px solid #1a1a1a; }
    .role-pill { font-size: 0.65rem; font-weight: 700; letter-spacing: 0.15em; color: #777; background: #111; border: 1px solid #2a2a2a; padding: 0.3rem 0.75rem; border-radius: 2px; }

    .sidebar-nav { flex: 1; padding: 1.25rem 0; overflow-y: auto; }
    .nav-group { margin-bottom: 1.5rem; }
    .nav-group-label { display: block; padding: 0 1.5rem 0.5rem; font-size: 0.6rem; font-weight: 700; letter-spacing: 0.2em; color: #444; text-transform: uppercase; }
    .nav-link {
      display: block; padding: 0.7rem 1.5rem;
      font-size: 0.8rem; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase;
      color: #666; text-decoration: none; transition: all 0.2s;
      border-left: 2px solid transparent;
    }
    .nav-link:hover { color: #ccc; background: #111; }
    .nav-link.active { color: #fff; background: #111; border-left-color: #fff; }

    .sidebar-footer { padding: 1.5rem; border-top: 1px solid #1a1a1a; }
    .sidebar-logout {
      width: 100%; padding: 0.65rem;
      background: transparent; border: 1px solid #2a2a2a;
      color: #666; font-size: 0.75rem; font-weight: 700;
      letter-spacing: 0.1em; text-transform: uppercase;
      cursor: pointer; border-radius: 2px; transition: all 0.2s;
    }
    .sidebar-logout:hover { border-color: #fff; color: #fff; background: #111; }

    /* ── Main ── */
    .main { flex: 1; margin-left: 220px; display: flex; flex-direction: column; min-height: 100vh; }
    .backdrop { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 400; }

    /* ── Topbar (mobile) ── */
    .topbar {
      display: none; align-items: center; gap: 1rem;
      padding: 1rem 1.25rem; background: #000;
      border-bottom: 1px solid #1a1a1a; position: sticky; top: 0; z-index: 100;
    }
    .topbar-menu {
      display: flex; flex-direction: column; gap: 4px;
      background: none; border: none; cursor: pointer; padding: 4px;
    }
    .topbar-menu span { display: block; width: 22px; height: 2px; background: #fff; }
    .topbar-brand { font-family: 'Bebas Neue', sans-serif; font-size: 1.2rem; letter-spacing: 0.12em; color: #fff; }
    .topbar-role { margin-left: auto; font-size: 0.65rem; font-weight: 700; letter-spacing: 0.15em; color: #555; }

    .content { flex: 1; }

    /* ── Notifications ── */
    .sidebar-role { display: flex; align-items: center; justify-content: space-between; gap: 0.5rem; }
    .bell-btn {
      position: relative; background: transparent; border: 1px solid #2a2a2a; color: #aaa;
      font-size: 0.6rem; font-weight: 700; letter-spacing: 0.12em; padding: 0.3rem 0.6rem;
      border-radius: 2px; cursor: pointer;
    }
    .bell-btn:hover { border-color: #fff; color: #fff; }
    .bell-badge {
      position: absolute; top: -7px; right: -7px; min-width: 16px; height: 16px; padding: 0 4px;
      background: #e53935; color: #fff; border-radius: 8px; font-size: 0.6rem; line-height: 16px; text-align: center;
    }
    .notif-panel {
      position: fixed; top: 1rem; left: 236px; width: 340px; max-height: 70vh; z-index: 600;
      background: #0d0d0d; border: 1px solid #2a2a2a; border-radius: 4px; display: flex; flex-direction: column;
      box-shadow: 0 10px 30px rgba(0,0,0,0.6);
    }
    .notif-head { display: flex; justify-content: space-between; align-items: center; padding: 0.85rem 1rem; border-bottom: 1px solid #1a1a1a; color: #fff; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase; }
    .notif-head-actions { display: flex; gap: 0.75rem; }
    .notif-link { background: none; border: none; color: #888; font-size: 0.7rem; cursor: pointer; text-transform: none; letter-spacing: 0; }
    .notif-link:hover { color: #fff; }
    .notif-toggle { display: flex; align-items: center; gap: 0.5rem; padding: 0.6rem 1rem; border-bottom: 1px solid #1a1a1a; color: #888; font-size: 0.75rem; }
    .notif-list { overflow-y: auto; }
    .notif-item { padding: 0.75rem 1rem; border-bottom: 1px solid #151515; cursor: pointer; }
    .notif-item.unread { background: #141414; border-left: 2px solid #e53935; }
    .notif-subject { color: #fff; font-size: 0.8rem; font-weight: 600; }
    .notif-content { color: #999; font-size: 0.75rem; margin-top: 0.2rem; }
    .notif-time { color: #555; font-size: 0.65rem; margin-top: 0.3rem; }
    .notif-empty { padding: 1.25rem 1rem; color: #555; font-size: 0.8rem; text-align: center; }

    @media (max-width: 1023px) {
      .sidebar { transform: translateX(-100%); }
      .sidebar.open { transform: translateX(0); }
      .sidebar-close-btn { display: block; }
      .backdrop { display: block; }
      .main { margin-left: 0; }
      .topbar { display: flex; }
      .topbar .topbar-role { margin-left: auto; }
      .notif-panel { left: 0.75rem; right: 0.75rem; top: 4rem; width: auto; }
    }
  `]
})
export class AppComponent implements OnInit, OnDestroy {
  sidebarOpen = false;
  notificationsOpen = false;
  attendanceAlerts = true;
  private authSub?: Subscription;

  constructor(public auth: AuthService, private router: Router, public notifications: NotificationsService) {}

  ngOnInit() {
    this.authSub = this.auth.currentUser$.subscribe(user => {
      if (user) {
        this.notifications.startPolling();
      } else {
        this.notifications.stopPolling();
        this.notificationsOpen = false;
      }
    });
  }

  ngOnDestroy() {
    this.authSub?.unsubscribe();
    this.notifications.stopPolling();
  }

  toggleNotifications() {
    this.notificationsOpen = !this.notificationsOpen;
    if (this.notificationsOpen) {
      this.notifications.refresh();
      this.notifications.getSettings().subscribe({
        next: s => this.attendanceAlerts = s.attendance_alerts !== false,
        error: () => {},
      });
    }
  }

  markRead(n: Notification) {
    if (!n.is_read) this.notifications.markRead(n.id).subscribe();
  }

  markAllRead() {
    this.notifications.markAllRead().subscribe();
  }

  toggleAttendanceAlerts(event: Event) {
    const enabled = (event.target as HTMLInputElement).checked;
    this.notifications.updateSettings({ attendance_alerts: enabled }).subscribe({
      next: () => this.attendanceAlerts = enabled,
      error: () => (event.target as HTMLInputElement).checked = this.attendanceAlerts,
    });
  }

  logout() { this.auth.logout(); }
}
