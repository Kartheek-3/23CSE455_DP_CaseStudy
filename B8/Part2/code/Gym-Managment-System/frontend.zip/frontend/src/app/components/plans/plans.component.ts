import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { PlansService } from '../../services/plans.service';
import { TrainersService } from '../../services/trainers.service';
import { MembersService } from '../../services/members.service';
import { AuthService } from '../../services/auth.service';
import { AssignmentsService } from '../../services/assignments.service';
import { WorkoutPlan, DietPlan } from '../../models/user.model';

@Component({
  selector: 'app-plans',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-container">
      <div class="page-header">
        <div>
          <h1>Plans</h1>
          <p>{{ auth.isTrainer() || auth.isAdmin() ? 'Create and manage workout & diet plans' : 'Your assigned workout and diet plans' }}</p>
        </div>
        <div class="header-actions" *ngIf="auth.isTrainer() || auth.isAdmin()">
          <button class="btn btn-primary" (click)="openWorkoutModal()">+ Workout Plan</button>
          <button class="btn btn-outline" (click)="openDietModal()">+ Diet Plan</button>
        </div>
      </div>

      <div class="tabs">
        <button class="tab" [ngClass]="{ active: activeTab === 'workout' }" (click)="activeTab = 'workout'">💪 Workout Plans</button>
        <button class="tab" [ngClass]="{ active: activeTab === 'diet' }" (click)="activeTab = 'diet'">🥗 Diet Plans</button>
        <button class="tab" [ngClass]="{ active: activeTab === 'progress' }" *ngIf="auth.isMember()" (click)="activeTab = 'progress'">📈 My Progress</button>
      </div>

      <!-- Workout Plans -->
      <div *ngIf="activeTab === 'workout'">
        <div class="plans-list">
          <div class="plan-item" *ngFor="let p of workoutPlans">
            <div class="plan-item-header">
              <div>
                <h3>{{ p.title }}</h3>
                <span class="plan-meta">{{ p.difficulty }} · {{ p.duration_weeks }} weeks</span>
                <span class="fitness-goal-tag" *ngIf="p.fitness_goal">🎯 {{ p.fitness_goal }}</span>
                <span class="trainer-tag" *ngIf="p.trainer_name">by {{ p.trainer_name }}</span>
              </div>
              <div class="plan-item-actions">
                <span class="badge public" *ngIf="p.is_public">Public</span>
                <button class="btn-icon" (click)="expandedWorkout = expandedWorkout === p.id ? null : p.id">
                  {{ expandedWorkout === p.id ? '▲' : '▼' }}
                </button>
                <ng-container *ngIf="auth.isTrainer() || auth.isAdmin()">
                  <button class="btn-icon" (click)="editWorkout(p)">✏️</button>
                  <button class="btn-icon" (click)="deleteWorkout(p.id)">🗑️</button>
                </ng-container>
              </div>
            </div>
            <p class="plan-desc" *ngIf="p.description">{{ p.description }}</p>

            <div class="exercises-list" *ngIf="expandedWorkout === p.id">
              <div class="exercise-item" *ngFor="let e of p.exercises; let i = index">
                <div class="exercise-num">{{ i + 1 }}</div>
                <div class="exercise-info">
                  <strong>{{ e.name }}</strong>
                  <span *ngIf="e.sets && e.reps">{{ e.sets }} sets × {{ e.reps }} reps</span>
                  <span *ngIf="e.duration_seconds">{{ e.duration_seconds }}s</span>
                  <a *ngIf="e.video_url" [href]="e.video_url" target="_blank" rel="noopener noreferrer" class="video-link">▶ Watch</a>
                </div>
                <button class="btn btn-sm btn-outline" *ngIf="auth.isMember()" (click)="logProgress(p.id, 'workout', e.name)">
                  ✅ Done
                </button>
              </div>
              <div class="empty" *ngIf="!p.exercises || p.exercises.length === 0">No exercises added yet.</div>
            </div>
          </div>
          <div class="empty-state" *ngIf="workoutPlans.length === 0">
            <div class="empty-icon">💪</div>
            <p>No workout plans yet.</p>
          </div>
        </div>
      </div>

      <!-- Diet Plans -->
      <div *ngIf="activeTab === 'diet'">
        <div class="plans-list">
          <div class="plan-item" *ngFor="let p of dietPlans">
            <div class="plan-item-header">
              <div>
                <h3>{{ p.title }}</h3>
                <span class="plan-meta">{{ p.total_calories }} cal/day · {{ p.duration_weeks }} weeks</span>
                <span class="trainer-tag" *ngIf="p.trainer_name">by {{ p.trainer_name }}</span>
              </div>
              <div class="plan-item-actions">
                <span class="badge public" *ngIf="p.is_public">Public</span>
                <button class="btn-icon" (click)="expandedDiet = expandedDiet === p.id ? null : p.id">
                  {{ expandedDiet === p.id ? '▲' : '▼' }}
                </button>
                <ng-container *ngIf="auth.isTrainer() || auth.isAdmin()">
                  <button class="btn-icon" (click)="editDiet(p)">✏️</button>
                  <button class="btn-icon" (click)="deleteDiet(p.id)">🗑️</button>
                </ng-container>
              </div>
            </div>
            <p class="plan-desc" *ngIf="p.description">{{ p.description }}</p>

            <div class="macros-row" *ngIf="p.macros && expandedDiet === p.id">
              <div class="macro-chip">🥩 Protein: {{ p.macros.protein || 0 }}g</div>
              <div class="macro-chip">🍞 Carbs: {{ p.macros.carbs || 0 }}g</div>
              <div class="macro-chip">🥑 Fats: {{ p.macros.fats || 0 }}g</div>
              <div class="macro-chip">🔥 {{ p.total_calories }} kcal</div>
            </div>

            <div class="meals-grid" *ngIf="expandedDiet === p.id">
              <div class="meal-card" *ngFor="let meal of getMealKeys(p.meals)">
                <h4 class="meal-title">{{ meal | titlecase }}</h4>
                <div class="meal-item" *ngFor="let item of p.meals[meal]">
                  <span>{{ item.name || item }}</span>
                  <span *ngIf="item.calories" class="meal-cals">{{ item.calories }} cal</span>
                </div>
              </div>
            </div>
          </div>
          <div class="empty-state" *ngIf="dietPlans.length === 0">
            <div class="empty-icon">🥗</div>
            <p>No diet plans yet.</p>
          </div>
        </div>
      </div>

      <!-- Progress Tab -->
      <div *ngIf="activeTab === 'progress'">
        <div class="progress-list" *ngIf="progressLogs.length > 0">
          <div class="progress-item" *ngFor="let log of progressLogs">
            <div class="progress-icon">{{ log.plan_type === 'workout' ? '💪' : '🥗' }}</div>
            <div class="progress-info">
              <strong>{{ log.exercise_name || 'Session completed' }}</strong>
              <span>{{ log.plan_type | titlecase }} plan · {{ log.logged_at | date:'MMM d, h:mm a' }}</span>
              <span *ngIf="log.feedback" class="feedback">{{ log.feedback }}</span>
            </div>
            <div class="rating-stars" *ngIf="log.rating">
              <span *ngFor="let s of [1,2,3,4,5]" [ngClass]="{ filled: log.rating >= s }">★</span>
            </div>
          </div>
        </div>
        <div class="empty-state" *ngIf="progressLogs.length === 0">
          <div class="empty-icon">📈</div>
          <p>No progress logged yet. Mark exercises as done to track your progress.</p>
        </div>
      </div>

      <!-- Workout Modal -->
      <div class="modal-overlay" *ngIf="showWorkoutModal" (click)="showWorkoutModal = false">
        <div class="modal modal-lg" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>{{ editingWorkout ? 'Edit Workout Plan' : 'New Workout Plan' }}</h2>
            <button class="modal-close" (click)="showWorkoutModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="form-row">
              <div class="form-group">
                <label>Title *</label>
                <input type="text" [(ngModel)]="workoutForm.title" class="form-control" placeholder="e.g. 4-Week Strength Builder" />
              </div>
              <div class="form-group">
                <label>Difficulty</label>
                <select [(ngModel)]="workoutForm.difficulty" (ngModelChange)="generateExerciseSuggestions()" class="form-control">
                  <option value="Beginner">Beginner</option>
                  <option value="Intermediate">Intermediate</option>
                  <option value="Advanced">Advanced</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label>Fitness Goal *</label>
              <select [(ngModel)]="workoutForm.fitness_goal" (ngModelChange)="onGoalChange()" class="form-control">
                <option *ngFor="let goal of fitnessGoals" [value]="goal">{{ goal }}</option>
              </select>
              <small class="field-hint" *ngIf="!goalFromMember">Choose the goal this workout plan is designed for.</small>
              <small class="field-hint goal-from-member" *ngIf="goalFromMember">Pre-filled from the selected member's fitness goals.</small>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Duration (weeks)</label>
                <input type="number" [(ngModel)]="workoutForm.duration_weeks" class="form-control" min="1" />
              </div>
              <div class="form-group">
                <label>Assign to Member</label>
                <select [(ngModel)]="workoutForm.member_id" (ngModelChange)="onWorkoutMemberChange()" class="form-control">
                  <option [ngValue]="null">— All / Public —</option>
                  <option *ngFor="let m of allMembers" [ngValue]="m.id">{{ m.full_name }}</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label>Description</label>
              <textarea [(ngModel)]="workoutForm.description" class="form-control" rows="2"></textarea>
            </div>
            <div class="form-group">
              <label class="check-label">
                <input type="checkbox" [(ngModel)]="workoutForm.is_public" /> Make this plan public
              </label>
            </div>
            <div class="recommendation-section">
              <div class="recommendation-header">
                <div>
                  <h4>✨ Recommended Exercises</h4>
                  <p class="recommendation-hint">Suggestions for {{ workoutForm.fitness_goal }} at {{ workoutForm.difficulty }} level.</p>
                </div>
                <button class="btn btn-sm btn-outline" (click)="generateExerciseSuggestions()">Refresh Suggestions</button>
              </div>
              <div class="suggestion-list">
                <div class="suggestion-item" *ngFor="let exercise of suggestedExercises">
                  <div class="suggestion-info">
                    <strong>{{ exercise.name }}</strong>
                    <span *ngIf="!exercise.duration_seconds">{{ exercise.sets }} sets × {{ exercise.reps }} reps</span>
                    <span *ngIf="exercise.duration_seconds">{{ exercise.sets }} sets × {{ exercise.duration_seconds }}s</span>
                  </div>
                  <button class="btn btn-sm btn-outline" (click)="addSuggestedExercise(exercise)">+ Add</button>
                </div>
              </div>
            </div>
            <div class="exercises-editor">
              <div class="exercises-header">
                <h4>Workout Exercises</h4>
                <button class="btn btn-sm btn-outline" (click)="addExercise()">+ Add Custom Exercise</button>
              </div>
              <div class="exercise-row" *ngFor="let ex of workoutForm.exercises; let i = index">
                <input type="text" [(ngModel)]="ex.name" class="form-control ex-name" placeholder="Exercise name" />
                <input type="number" [(ngModel)]="ex.sets" class="form-control ex-num" placeholder="Sets" min="1" />
                <input type="number" [(ngModel)]="ex.reps" class="form-control ex-num" placeholder="Reps" min="1" />
                <input type="text" [(ngModel)]="ex.video_url" class="form-control ex-url" placeholder="Video URL" />
                <button class="btn-remove" (click)="removeExercise(i)">✕</button>
              </div>
            </div>
            <div class="alert alert-error" *ngIf="planError">{{ planError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="showWorkoutModal = false">Cancel</button>
            <button class="btn btn-primary" (click)="saveWorkout()" [disabled]="savingPlan">{{ savingPlan ? 'Saving...' : 'Save Plan' }}</button>
          </div>
        </div>
      </div>

      <!-- Diet Modal -->
      <div class="modal-overlay" *ngIf="showDietModal" (click)="showDietModal = false">
        <div class="modal modal-lg" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>{{ editingDiet ? 'Edit Diet Plan' : 'New Diet Plan' }}</h2>
            <button class="modal-close" (click)="showDietModal = false">✕</button>
          </div>
          <div class="modal-body">
            <div class="form-row">
              <div class="form-group">
                <label>Title *</label>
                <input type="text" [(ngModel)]="dietForm.title" class="form-control" placeholder="e.g. Weight Loss Meal Plan" />
              </div>
              <div class="form-group">
                <label>Total Calories/Day</label>
                <input type="number" [(ngModel)]="dietForm.total_calories" class="form-control" min="500" />
              </div>
            </div>
            <div class="form-row">
              <div class="form-group"><label>Protein (g)</label><input type="number" [(ngModel)]="dietForm.macros.protein" class="form-control" /></div>
              <div class="form-group"><label>Carbs (g)</label><input type="number" [(ngModel)]="dietForm.macros.carbs" class="form-control" /></div>
              <div class="form-group"><label>Fats (g)</label><input type="number" [(ngModel)]="dietForm.macros.fats" class="form-control" /></div>
            </div>
            <div class="form-row">
              <div class="form-group">
                <label>Duration (weeks)</label>
                <input type="number" [(ngModel)]="dietForm.duration_weeks" class="form-control" min="1" />
              </div>
              <div class="form-group">
                <label>Assign to Member</label>
                <select [(ngModel)]="dietForm.member_id" class="form-control">
                  <option [ngValue]="null">— All / Public —</option>
                  <option *ngFor="let m of allMembers" [ngValue]="m.id">{{ m.full_name }}</option>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label>Description</label>
              <textarea [(ngModel)]="dietForm.description" class="form-control" rows="2"></textarea>
            </div>
            <div class="form-group">
              <label class="check-label">
                <input type="checkbox" [(ngModel)]="dietForm.is_public" /> Make this plan public
              </label>
            </div>
            <div class="meals-editor">
              <h4>Meal Breakdown</h4>
              <div class="meal-editor-row" *ngFor="let meal of mealKeys">
                <label class="meal-label">{{ meal | titlecase }}</label>
                <input type="text" class="form-control" [placeholder]="'Enter ' + meal + ' items (comma separated)'"
                       [ngModel]="getMealString(meal)" (ngModelChange)="setMealString(meal, $event)" />
              </div>
            </div>
            <div class="alert alert-error" *ngIf="planError">{{ planError }}</div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="showDietModal = false">Cancel</button>
            <button class="btn btn-primary" (click)="saveDiet()" [disabled]="savingPlan">{{ savingPlan ? 'Saving...' : 'Save Plan' }}</button>
          </div>
        </div>
      </div>

      <!-- Feedback Modal -->
      <div class="modal-overlay" *ngIf="showProgressModal" (click)="showProgressModal = false">
        <div class="modal modal-sm" (click)="$event.stopPropagation()">
          <div class="modal-header">
            <h2>Log Progress</h2>
            <button class="modal-close" (click)="showProgressModal = false">✕</button>
          </div>
          <div class="modal-body">
            <p><strong>{{ progressForm.exercise_name }}</strong></p>
            <div class="form-group">
              <label>Rating</label>
              <div class="star-rating">
                <button *ngFor="let s of [1,2,3,4,5]" class="star" [ngClass]="{ active: progressForm.rating >= s }" (click)="progressForm.rating = s">★</button>
              </div>
            </div>
            <div class="form-group">
              <label>Feedback (optional)</label>
              <select [(ngModel)]="progressForm.feedback" class="form-control">
                <option value="">Select feedback...</option>
                <option value="too easy">Too easy</option>
                <option value="just right">Just right</option>
                <option value="too hard">Too hard</option>
                <option value="great">Great exercise!</option>
              </select>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline" (click)="showProgressModal = false">Skip</button>
            <button class="btn btn-primary" (click)="submitProgress()">Log it!</button>
          </div>
        </div>
      </div>

      <div class="toast" *ngIf="toast" [ngClass]="toastType">{{ toast }}</div>
    </div>
  `,
  styles: [`
    .page-container { padding: 1.5rem; max-width: 1100px; margin: 0 auto; }
    .page-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 1.5rem; flex-wrap: wrap; gap: 1rem; }
    .page-header h1 { font-size: 1.75rem; font-weight: 700; color: #1a202c; margin: 0; }
    .page-header p { color: #718096; margin-top: 0.25rem; }
    .header-actions { display: flex; gap: 0.75rem; }
    .tabs { display: flex; gap: 0.5rem; margin-bottom: 1.5rem; border-bottom: 2px solid #e2e8f0; }
    .tab { padding: 0.75rem 1.25rem; background: none; border: none; cursor: pointer; font-weight: 600; color: #718096; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all 0.2s; }
    .tab.active { color: #667eea; border-bottom-color: #667eea; }
    .plans-list { display: flex; flex-direction: column; gap: 1rem; }
    .plan-item { background: white; border-radius: 12px; padding: 1.25rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .plan-item-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 0.5rem; }
    .plan-item-header h3 { font-size: 1.1rem; font-weight: 700; color: #1a202c; margin: 0 0 0.25rem; }
    .plan-meta { font-size: 0.8rem; color: #718096; margin-right: 0.5rem; }
    .fitness-goal-tag { display: inline-block; margin: 6px 8px 0 0; padding: 5px 10px; background: #eaf3ff; color: #2563eb; border-radius: 15px; font-size: 12px; font-weight: 600; }
    .trainer-tag { font-size: 0.8rem; color: #667eea; }
    .plan-item-actions { display: flex; align-items: center; gap: 0.5rem; }
    .badge.public { background: #f0fff4; color: #276749; padding: 0.2rem 0.6rem; border-radius: 20px; font-size: 0.75rem; font-weight: 600; }
    .btn-icon { background: none; border: none; cursor: pointer; font-size: 1rem; padding: 0.25rem; border-radius: 4px; }
    .btn-icon:hover { background: #f0f4f8; }
    .plan-desc { font-size: 0.875rem; color: #718096; margin: 0 0 0.75rem; }
    .exercises-list { margin-top: 1rem; border-top: 1px solid #e2e8f0; padding-top: 1rem; }
    .exercise-item { display: flex; align-items: center; gap: 1rem; padding: 0.6rem 0; border-bottom: 1px solid #f0f4f8; }
    .exercise-num { width: 24px; height: 24px; border-radius: 50%; background: #ebf4ff; color: #3182ce; display: flex; align-items: center; justify-content: center; font-size: 0.75rem; font-weight: 700; flex-shrink: 0; }
    .exercise-info { flex: 1; display: flex; flex-wrap: wrap; align-items: center; gap: 0.5rem; font-size: 0.875rem; }
    .exercise-info strong { color: #2d3748; }
    .exercise-info span { color: #718096; }
    .video-link { color: #667eea; text-decoration: none; font-size: 0.8rem; }
    .empty { text-align: center; color: #a0aec0; padding: 1rem; font-size: 0.875rem; }
    .macros-row { display: flex; flex-wrap: wrap; gap: 0.5rem; margin: 0.75rem 0; }
    .macro-chip { background: #ebf4ff; color: #3182ce; padding: 0.25rem 0.75rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
    .meals-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; margin-top: 0.75rem; }
    .meal-card { background: #f7fafc; border-radius: 8px; padding: 0.875rem; }
    .meal-title { font-size: 0.875rem; font-weight: 700; color: #2d3748; margin: 0 0 0.5rem; }
    .meal-item { display: flex; justify-content: space-between; font-size: 0.8rem; color: #4a5568; padding: 0.2rem 0; border-bottom: 1px solid #e2e8f0; }
    .meal-cals { color: #718096; }
    .progress-list { display: flex; flex-direction: column; gap: 0.75rem; }
    .progress-item { background: white; border-radius: 10px; padding: 1rem 1.25rem; display: flex; align-items: center; gap: 1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }
    .progress-icon { font-size: 1.5rem; }
    .progress-info { flex: 1; display: flex; flex-direction: column; gap: 0.15rem; }
    .progress-info strong { color: #2d3748; font-size: 0.95rem; }
    .progress-info span { font-size: 0.8rem; color: #718096; }
    .feedback { background: #fffbeb; color: #92400e; padding: 0.1rem 0.5rem; border-radius: 4px; font-size: 0.75rem; }
    .rating-stars span { color: #e2e8f0; font-size: 1.1rem; }
    .rating-stars span.filled { color: #f6ad55; }
    .empty-state { text-align: center; padding: 4rem; color: #718096; }
    .empty-icon { font-size: 3rem; margin-bottom: 1rem; }
    .recommendation-section { margin-top: 1.25rem; padding: 1rem; background: #f7f9ff; border: 1px solid #dbe4ff; border-radius: 10px; }
    .recommendation-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.75rem; margin-bottom: 1rem; }
    .recommendation-header h4 { margin: 0; font-size: 0.95rem; font-weight: 700; color: #2d3748; }
    .recommendation-hint { margin: 5px 0 0; font-size: 0.8rem; color: #718096; }
    .suggestion-list { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 0.75rem; }
    .suggestion-item { display: flex; justify-content: space-between; align-items: center; gap: 0.5rem; background: white; padding: 0.75rem; border: 1px solid #e2e8f0; border-radius: 8px; }
    .suggestion-info { display: flex; flex-direction: column; gap: 4px; }
    .suggestion-info strong { font-size: 0.85rem; color: #2d3748; }
    .suggestion-info span { font-size: 0.75rem; color: #718096; }
    .field-hint { display: block; margin-top: 5px; color: #718096; font-size: 0.78rem; }
    .goal-from-member { color: #2563eb; font-weight: 600; }
    .exercises-editor { margin-top: 1rem; }
    .exercises-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.75rem; }
    .exercises-header h4 { font-size: 0.95rem; font-weight: 700; margin: 0; }
    .exercise-row { display: grid; grid-template-columns: 2fr 1fr 1fr 2fr auto; gap: 0.5rem; margin-bottom: 0.5rem; align-items: center; }
    .ex-name, .ex-url { }
    .ex-num { }
    .btn-remove { background: #fff5f5; border: 1px solid #fc8181; color: #c53030; border-radius: 6px; cursor: pointer; padding: 0.4rem 0.6rem; }
    .meals-editor h4 { font-size: 0.95rem; font-weight: 700; margin: 1rem 0 0.75rem; }
    .meal-editor-row { display: grid; grid-template-columns: 100px 1fr; gap: 0.75rem; margin-bottom: 0.5rem; align-items: center; }
    .meal-label { font-weight: 600; font-size: 0.875rem; color: #4a5568; }
    .form-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 1rem; margin-bottom: 0.75rem; }
    .form-group { margin-bottom: 0.75rem; }
    .form-group label { display: block; font-weight: 600; color: #4a5568; margin-bottom: 0.4rem; font-size: 0.875rem; }
    .check-label { display: flex; align-items: center; gap: 0.5rem; cursor: pointer; font-weight: 600; font-size: 0.875rem; color: #4a5568; }
    .form-control { width: 100%; padding: 0.65rem 0.875rem; border: 2px solid #e2e8f0; border-radius: 8px; font-size: 0.9rem; box-sizing: border-box; }
    .form-control:focus { outline: none; border-color: #667eea; }
    textarea.form-control { resize: vertical; }
    .btn { padding: 0.6rem 1.25rem; border-radius: 8px; border: none; cursor: pointer; font-weight: 600; font-size: 0.9rem; transition: all 0.2s; }
    .btn-primary { background: linear-gradient(135deg, #667eea, #764ba2); color: white; }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .btn-outline { background: white; border: 2px solid #667eea; color: #667eea; }
    .btn-sm { padding: 0.35rem 0.75rem; font-size: 0.8rem; }
    .alert { padding: 0.75rem 1rem; border-radius: 8px; margin-top: 0.75rem; font-size: 0.875rem; }
    .alert-error { background: #fff5f5; color: #c53030; border: 1px solid #fed7d7; }
    .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; z-index: 1000; padding: 1rem; }
    .modal { background: white; border-radius: 16px; width: 100%; max-width: 520px; max-height: 90vh; overflow-y: auto; }
    .modal-lg { max-width: 700px; }
    .modal-sm { max-width: 380px; }
    .modal-header { display: flex; justify-content: space-between; align-items: center; padding: 1.25rem 1.5rem; border-bottom: 1px solid #e2e8f0; }
    .modal-header h2 { font-size: 1.25rem; font-weight: 700; margin: 0; }
    .modal-close { background: none; border: none; font-size: 1.25rem; cursor: pointer; color: #718096; }
    .modal-body { padding: 1.5rem; }
    .modal-footer { padding: 1rem 1.5rem; border-top: 1px solid #e2e8f0; display: flex; justify-content: flex-end; gap: 0.75rem; }
    .star-rating { display: flex; gap: 0.5rem; }
    .star { background: none; border: none; font-size: 2rem; cursor: pointer; color: #e2e8f0; transition: color 0.2s; }
    .star.active { color: #f6ad55; }
    .toast { position: fixed; bottom: 1.5rem; right: 1.5rem; padding: 0.875rem 1.5rem; border-radius: 10px; font-weight: 600; z-index: 2000; }
    .toast.success { background: #276749; color: white; }
    .toast.error { background: #c53030; color: white; }
    @media (max-width: 640px) { .exercise-row { grid-template-columns: 1fr; } .meal-editor-row { grid-template-columns: 1fr; } .recommendation-header { align-items: flex-start; flex-direction: column; } .suggestion-list { grid-template-columns: 1fr; } }
  `]
})
export class PlansComponent implements OnInit {
  activeTab = 'workout';
  workoutPlans: WorkoutPlan[] = [];
  dietPlans: DietPlan[] = [];
  progressLogs: any[] = [];
  allMembers: any[] = [];
  expandedWorkout: number | null = null;
  expandedDiet: number | null = null;
  showWorkoutModal = false;
  showDietModal = false;
  showProgressModal = false;
  editingWorkout: WorkoutPlan | null = null;
  editingDiet: DietPlan | null = null;
  savingPlan = false;
  planError = '';
  toast = '';
  toastType = 'success';
  mealKeys = ['breakfast', 'lunch', 'dinner', 'snacks'];
  fitnessGoals: string[] = ['General Fitness', 'Weight Loss', 'Muscle Building', 'Strength Training', 'Endurance', 'Flexibility'];
  suggestedExercises: any[] = [];
  goalFromMember = false;

  workoutForm: any = { title: '', description: '', difficulty: 'Intermediate', fitness_goal: 'General Fitness', duration_weeks: 4, member_id: null, is_public: false, exercises: [] };
  dietForm: any = { title: '', description: '', total_calories: 2000, duration_weeks: 4, member_id: null, is_public: false, macros: { protein: 150, carbs: 200, fats: 65 }, meals: { breakfast: [], lunch: [], dinner: [], snacks: [] } };
  progressForm: any = { plan_id: 0, plan_type: 'workout', exercise_name: '', rating: 0, feedback: '' };

  constructor(
    public auth: AuthService,
    private plansService: PlansService,
    private membersService: MembersService,
    private assignmentsService: AssignmentsService
  ) {}

  ngOnInit() {
    this.loadPlans();
    if (this.auth.isAdmin() || this.auth.isTrainer()) {
      this.assignmentsService.getMyClients().subscribe(m => this.allMembers = m);
      this.plansService.getWorkoutGoals().subscribe(goals => this.fitnessGoals = goals);
    }
    if (this.auth.isMember()) {
      this.membersService.getMe().subscribe(m => {
        this.plansService.getMemberProgress(m.id).subscribe(p => this.progressLogs = p);
      });
    }
  }

  loadPlans() {
    this.plansService.getWorkoutPlans().subscribe(p => this.workoutPlans = p);
    this.plansService.getDietPlans().subscribe(p => this.dietPlans = p);
  }

  openWorkoutModal() {
    this.editingWorkout = null;
    this.workoutForm = { title: '', description: '', difficulty: 'Intermediate', fitness_goal: 'General Fitness', duration_weeks: 4, member_id: null, is_public: false, exercises: [] };
    this.suggestedExercises = [];
    this.goalFromMember = false;
    this.planError = '';
    this.showWorkoutModal = true;
    this.generateExerciseSuggestions();
  }
  openDietModal() { this.editingDiet = null; this.dietForm = { title: '', description: '', total_calories: 2000, duration_weeks: 4, member_id: null, is_public: false, macros: { protein: 150, carbs: 200, fats: 65 }, meals: { breakfast: [], lunch: [], dinner: [], snacks: [] } }; this.planError = ''; this.showDietModal = true; }

  editWorkout(p: WorkoutPlan) {
    this.editingWorkout = p;
    this.workoutForm = { ...p, fitness_goal: p.fitness_goal || 'General Fitness', exercises: (p.exercises || []).map((e: any) => ({ ...e })) };
    this.goalFromMember = false;
    this.planError = '';
    this.showWorkoutModal = true;
    this.generateExerciseSuggestions();
  }
  editDiet(p: DietPlan) { this.editingDiet = p; this.dietForm = { ...p, macros: { ...p.macros }, meals: { ...p.meals } }; this.planError = ''; this.showDietModal = true; }

  addExercise() { this.workoutForm.exercises.push({ name: '', sets: 3, reps: 10, duration_seconds: null, video_url: '' }); }

  generateExerciseSuggestions(useMemberGoal = false) {
    this.plansService.getWorkoutRecommendations({
      goal: this.workoutForm.fitness_goal,
      difficulty: this.workoutForm.difficulty,
      member_id: this.workoutForm.member_id,
      use_member_goal: useMemberGoal,
    }).subscribe({
      next: rec => {
        this.suggestedExercises = rec.exercises;
        if (rec.inferred_from_member) {
          this.workoutForm.fitness_goal = rec.goal;
          this.goalFromMember = true;
        }
      },
      error: () => { this.suggestedExercises = []; this.showToast('Could not load exercise suggestions.', 'error'); }
    });
  }

  onGoalChange() {
    this.goalFromMember = false;
    this.generateExerciseSuggestions();
  }

  onWorkoutMemberChange() {
    this.goalFromMember = false;
    this.generateExerciseSuggestions(!!this.workoutForm.member_id);
  }

  addSuggestedExercise(exercise: any) {
    const alreadyExists = this.workoutForm.exercises.some((e: any) =>
      (e.name || '').trim().toLowerCase() === exercise.name.toLowerCase()
    );
    if (alreadyExists) {
      this.showToast('Exercise already added!', 'error');
      return;
    }
    this.workoutForm.exercises.push({ ...exercise, duration_seconds: exercise.duration_seconds ?? null, video_url: '' });
    this.showToast('Exercise added successfully!', 'success');
  }

  removeExercise(index: number) { this.workoutForm.exercises.splice(index, 1); }

  saveWorkout() {
    if (!this.workoutForm.title) { this.planError = 'Title is required.'; return; }
    this.savingPlan = true;
    const obs = this.editingWorkout ? this.plansService.updateWorkoutPlan(this.editingWorkout.id, this.workoutForm) : this.plansService.createWorkoutPlan(this.workoutForm);
    obs.subscribe({ next: () => { this.savingPlan = false; this.showWorkoutModal = false; this.loadPlans(); this.showToast('Workout plan saved!', 'success'); }, error: (e) => { this.savingPlan = false; this.planError = e.error?.detail || 'Failed to save.'; } });
  }

  saveDiet() {
    if (!this.dietForm.title) { this.planError = 'Title is required.'; return; }
    this.savingPlan = true;
    const obs = this.editingDiet ? this.plansService.updateDietPlan(this.editingDiet.id, this.dietForm) : this.plansService.createDietPlan(this.dietForm);
    obs.subscribe({ next: () => { this.savingPlan = false; this.showDietModal = false; this.loadPlans(); this.showToast('Diet plan saved!', 'success'); }, error: (e) => { this.savingPlan = false; this.planError = e.error?.detail || 'Failed to save.'; } });
  }

  deleteWorkout(id: number) { if (!confirm('Delete this plan?')) return; this.plansService.deleteWorkoutPlan(id).subscribe(() => { this.loadPlans(); this.showToast('Plan deleted.', 'success'); }); }
  deleteDiet(id: number) { if (!confirm('Delete this plan?')) return; this.plansService.deleteDietPlan(id).subscribe(() => { this.loadPlans(); this.showToast('Plan deleted.', 'success'); }); }

  logProgress(planId: number, planType: string, exerciseName: string) { this.progressForm = { plan_id: planId, plan_type: planType, exercise_name: exerciseName, rating: 0, feedback: '' }; this.showProgressModal = true; }

  submitProgress() {
    this.plansService.logProgress({ ...this.progressForm, completed: true }).subscribe({
      next: () => { this.showProgressModal = false; this.showToast('Progress logged!', 'success'); if (this.auth.isMember()) { this.membersService.getMe().subscribe(m => this.plansService.getMemberProgress(m.id).subscribe(p => this.progressLogs = p)); } },
      error: () => this.showToast('Failed to log progress.', 'error')
    });
  }

  getMealKeys(meals: any): string[] { return meals ? Object.keys(meals) : []; }
  getMealString(meal: string): string { const items = this.dietForm.meals[meal] || []; return items.map((i: any) => typeof i === 'string' ? i : i.name).join(', '); }
  setMealString(meal: string, value: string) { this.dietForm.meals[meal] = value.split(',').map((s: string) => ({ name: s.trim() })).filter((i: any) => i.name); }
  showToast(msg: string, type: string) { this.toast = msg; this.toastType = type; setTimeout(() => this.toast = '', 3000); }
}
