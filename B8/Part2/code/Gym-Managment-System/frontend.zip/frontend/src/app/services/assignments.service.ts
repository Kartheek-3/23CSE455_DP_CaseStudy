import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { AssignmentPolicy, Member, TrainerAssignment } from '../models/user.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class AssignmentsService {
  private apiUrl = `${environment.apiUrl}/assignments`;

  constructor(private http: HttpClient) {}

  getPolicies(): Observable<AssignmentPolicy[]> {
    return this.http.get<AssignmentPolicy[]>(`${this.apiUrl}/policies`);
  }

  assignByPolicy(memberId: number, policy: string): Observable<TrainerAssignment> {
    return this.http.post<TrainerAssignment>(`${this.apiUrl}/members/${memberId}`, { policy });
  }

  assignManually(memberId: number, trainerId: number): Observable<TrainerAssignment> {
    return this.http.post<TrainerAssignment>(`${this.apiUrl}/members/${memberId}`, { trainer_id: trainerId });
  }

  unassign(memberId: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/members/${memberId}`);
  }

  autoAssign(policy: string): Observable<{ assigned: number; skipped: number; assignments: TrainerAssignment[] }> {
    return this.http.post<any>(`${this.apiUrl}/auto-assign`, { policy });
  }

  getHistory(memberId: number): Observable<TrainerAssignment[]> {
    return this.http.get<TrainerAssignment[]>(`${this.apiUrl}/members/${memberId}/history`);
  }

  getMyClients(): Observable<Member[]> {
    return this.http.get<Member[]>(`${this.apiUrl}/my-clients`);
  }
}
