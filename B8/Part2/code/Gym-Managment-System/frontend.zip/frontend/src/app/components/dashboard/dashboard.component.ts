import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { MembersService } from '../../services/members.service';
import { ClassesService } from '../../services/classes.service';
import { AttendanceService } from '../../services/attendance.service';
import { PaymentsService } from '../../services/payments.service';
import { TrainersService } from '../../services/trainers.service';
import { AssignmentsService } from '../../services/assignments.service';
import { Member } from '../../models/user.model';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="dash">

      <!-- Hero banner -->
      <div class="dash-hero">
        <div class="dash-hero-overlay"></div>
        <div class="dash-hero-content">
          <p class="dash-hero-label">{{ auth.getRole() | uppercase }} DASHBOARD</p>
          <h1 class="dash-hero-title">
            {{ auth.isAdmin() ? 'COMMAND CENTER' : auth.isTrainer() ? 'TRAINER HUB' : 'MY FITNESS' }}
          </h1>
        </div>
      </div>

      <div class="page">

        <!-- ADMIN -->
        <ng-container *ngIf="auth.isAdmin()">
          <div class="stats-grid">
            <div class="stat-box">
              <div class="stat-box-value">{{ memberStats?.total || 0 }}</div>
              <div class="stat-box-label">Total Members</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ memberStats?.active || 0 }}</div>
              <div class="stat-box-label">Active Members</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ attendanceStats?.today || 0 }}</div>
              <div class="stat-box-label">Check-ins Today</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">\${{ revenueStats?.monthly_revenue?.toFixed(0) || 0 }}</div>
              <div class="stat-box-label">Monthly Revenue</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ attendanceStats?.this_week || 0 }}</div>
              <div class="stat-box-label">This Week</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ memberStats?.expired || 0 }}</div>
              <div class="stat-box-label">Expired Subs</div>
            </div>
          </div>

          <div class="section-title">QUICK ACTIONS</div>
          <div class="quick-grid">
            <a routerLink="/members"    class="quick-card">
              <div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&q=70')"></div>
              <div class="qc-overlay"></div>
              <div class="qc-body"><span class="qc-title">MEMBERS</span><span class="qc-sub">Manage accounts</span></div>
            </a>
            <a routerLink="/trainers"   class="quick-card">
              <div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=600&q=70')"></div>
              <div class="qc-overlay"></div>
              <div class="qc-body"><span class="qc-title">TRAINERS</span><span class="qc-sub">Your fitness team</span></div>
            </a>
            <a routerLink="/classes"    class="quick-card">
              <div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=70')"></div>
              <div class="qc-overlay"></div>
              <div class="qc-body"><span class="qc-title">CLASSES</span><span class="qc-sub">Schedule & manage</span></div>
            </a>
            <a routerLink="/payments"   class="quick-card">
              <div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=600&q=70')"></div>
              <div class="qc-overlay"></div>
              <div class="qc-body"><span class="qc-title">PAYMENTS</span><span class="qc-sub">Revenue & billing</span></div>
            </a>
            <a routerLink="/attendance" class="quick-card">
              <div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=600&q=70')"></div>
              <div class="qc-overlay"></div>
              <div class="qc-body"><span class="qc-title">ATTENDANCE</span><span class="qc-sub">Track check-ins</span></div>
            </a>
            <a routerLink="/plans"      class="quick-card">
              <div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=600&q=70')"></div>
              <div class="qc-overlay"></div>
              <div class="qc-body"><span class="qc-title">PLANS</span><span class="qc-sub">Workout & diet</span></div>
            </a>
          </div>

          <div class="section-title">RECENT CLASSES</div>
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>Class</th><th>Trainer</th><th>Schedule</th><th>Capacity</th><th>Level</th></tr></thead>
              <tbody>
                <tr *ngFor="let c of recentClasses">
                  <td><strong>{{ c.name }}</strong></td>
                  <td>{{ c.trainer_name }}</td>
                  <td>{{ c.start_time | date:'MMM d, h:mm a' }}</td>
                  <td>
                    <div class="cap-bar-wrap">
                      <div class="cap-bar"><div class="cap-fill" [style.width.%]="(c.current_enrolled/c.max_capacity)*100"></div></div>
                      <span>{{ c.current_enrolled }}/{{ c.max_capacity }}</span>
                    </div>
                  </td>
                  <td><span class="badge badge-gray">{{ c.difficulty_level }}</span></td>
                </tr>
                <tr *ngIf="recentClasses.length===0"><td colspan="5" class="empty-row">No classes scheduled</td></tr>
              </tbody>
            </table>
          </div>
        </ng-container>

        <!-- TRAINER -->
        <ng-container *ngIf="auth.isTrainer()">
          <div class="stats-grid">
            <div class="stat-box">
              <div class="stat-box-value">{{ trainerClasses.length }}</div>
              <div class="stat-box-label">My Classes</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ attendanceStats?.today || 0 }}</div>
              <div class="stat-box-label">Today Check-ins</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ attendanceStats?.this_week || 0 }}</div>
              <div class="stat-box-label">This Week</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ myClients.length }}</div>
              <div class="stat-box-label">My Clients</div>
            </div>
          </div>

          <div class="section-title">MY CLIENTS</div>
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>Member</th><th>Fitness Goals</th><th>Membership</th></tr></thead>
              <tbody>
                <tr *ngFor="let m of myClients">
                  <td><strong>{{ m.full_name }}</strong></td>
                  <td>{{ m.fitness_goals || '—' }}</td>
                  <td>{{ m.subscription_status | titlecase }}</td>
                </tr>
                <tr *ngIf="myClients.length===0"><td colspan="3" class="empty-row">No clients assigned yet</td></tr>
              </tbody>
            </table>
          </div>

          <div class="section-title">MY UPCOMING CLASSES</div>
          <div class="table-wrap">
            <table class="data-table">
              <thead><tr><th>Class</th><th>Date & Time</th><th>Enrolled</th><th>Location</th><th>Level</th></tr></thead>
              <tbody>
                <tr *ngFor="let c of trainerClasses">
                  <td><strong>{{ c.name }}</strong></td>
                  <td>{{ c.start_time | date:'EEE, MMM d · h:mm a' }}</td>
                  <td>{{ c.current_enrolled }}/{{ c.max_capacity }}</td>
                  <td>{{ c.location }}</td>
                  <td><span class="badge badge-gray">{{ c.difficulty_level }}</span></td>
                </tr>
                <tr *ngIf="trainerClasses.length===0"><td colspan="5" class="empty-row">No upcoming classes</td></tr>
              </tbody>
            </table>
          </div>

          <div class="quick-grid">
            <a routerLink="/classes"    class="quick-card"><div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1518611012118-696072aa579a?w=600&q=70')"></div><div class="qc-overlay"></div><div class="qc-body"><span class="qc-title">CLASSES</span><span class="qc-sub">My schedule</span></div></a>
            <a routerLink="/attendance" class="quick-card"><div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1574680096145-d05b474e2155?w=600&q=70')"></div><div class="qc-overlay"></div><div class="qc-body"><span class="qc-title">ATTENDANCE</span><span class="qc-sub">Mark present</span></div></a>
            <a routerLink="/plans"      class="quick-card"><div class="qc-bg" style="background-image:url('https://images.unsplash.com/photo-1490645935967-10de6ba17061?w=600&q=70')"></div><div class="qc-overlay"></div><div class="qc-body"><span class="qc-title">PLANS</span><span class="qc-sub">Upload plans</span></div></a>
          </div>
        </ng-container>

        <!-- MEMBER -->
        <ng-container *ngIf="auth.isMember()">
          <div class="stats-grid">
            <div class="stat-box" [ngClass]="memberProfile?.subscription_status==='active'?'stat-active':'stat-warn'">
              <div class="stat-box-value">{{ memberProfile?.subscription_status | titlecase }}</div>
              <div class="stat-box-label">Membership Status</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ memberBookings.length }}</div>
              <div class="stat-box-label">Booked Classes</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ streak?.streak || 0 }}</div>
              <div class="stat-box-label">Day Streak</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value">{{ streak?.total_attended || 0 }}</div>
              <div class="stat-box-label">Total Sessions</div>
            </div>
            <div class="stat-box">
              <div class="stat-box-value stat-trainer">{{ memberProfile?.assigned_trainer_name || 'Not assigned' }}</div>
              <div class="stat-box-label">Your Trainer</div>
            </div>
          </div>

          <div class="expiry-bar" *ngIf="memberProfile?.subscription_expiry">
            <div [ngClass]="isExpiringSoon()?'expiry-warn':'expiry-info'">
              <span>Membership expires {{ memberProfile?.subscription_expiry | date:'MMMM d, yyyy' }}</span>
              <a routerLink="/payments" *ngIf="isExpiringSoon()" class="renew-btn">RENEW NOW</a>
            </div>
          </div>

          <div class="two-col">
            <div>
              <div class="section-title">UPCOMING CLASSES</div>
              <div class="booking-list">
                <div class="booking-item" *ngFor="let b of memberBookings">
                  <div class="booking-info">
                    <strong>{{ b.class_name }}</strong>
                    <span>{{ b.class_start_time | date:'EEE, MMM d · h:mm a' }}</span>
                  </div>
                  <span class="badge badge-white">BOOKED</span>
                </div>
                <div class="empty-block" *ngIf="memberBookings.length===0">
                  No upcoming classes. <a routerLink="/classes">Browse classes</a>
                </div>
              </div>
            </div>

            <div>
              <div class="section-title">QUICK ACTIONS</div>
              <div class="action-list">
                <a routerLink="/classes"    class="action-row">Browse Classes<span class="arrow">→</span></a>
                <a routerLink="/attendance" class="action-row">QR Check-in<span class="arrow">→</span></a>
                <a routerLink="/plans"      class="action-row">My Plans<span class="arrow">→</span></a>
                <a routerLink="/payments"   class="action-row">Payments<span class="arrow">→</span></a>
              </div>
            </div>
          </div>
        </ng-container>

      </div>
    </div>
  `,
  styles: [`
    .dash { background: #0a0a0a; min-height: 100vh; }

    .dash-hero {
      height: 220px; position: relative; overflow: hidden;
      background-image: url('https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1400&q=80');
      background-size: cover; background-position: center 30%;
      display: flex; align-items: flex-end;
    }
    .dash-hero-overlay { position: absolute; inset: 0; background: linear-gradient(to right, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.4) 100%); }
    .dash-hero-content { position: relative; z-index: 1; padding: 2rem 2.5rem; }
    .dash-hero-label { font-size: 0.65rem; font-weight: 700; letter-spacing: 0.25em; color: #666; text-transform: uppercase; margin-bottom: 0.5rem; }
    .dash-hero-title { font-family: 'Bebas Neue', sans-serif; font-size: clamp(2rem, 5vw, 3.5rem); letter-spacing: 0.05em; color: #fff; line-height: 1; }

    /* Quick cards */
    .quick-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1px; background: #1a1a1a; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; margin-bottom: 2.5rem; }
    .quick-card { position: relative; height: 160px; overflow: hidden; text-decoration: none; display: flex; flex-direction: column; justify-content: flex-end; }
    .qc-bg { position: absolute; inset: 0; background-size: cover; background-position: center; transition: transform 0.4s ease; }
    .quick-card:hover .qc-bg { transform: scale(1.06); }
    .qc-overlay { position: absolute; inset: 0; background: linear-gradient(to top, rgba(0,0,0,0.85) 0%, rgba(0,0,0,0.2) 100%); transition: background 0.3s; }
    .quick-card:hover .qc-overlay { background: linear-gradient(to top, rgba(0,0,0,0.7) 0%, rgba(0,0,0,0.1) 100%); }
    .qc-body { position: relative; z-index: 1; padding: 1rem; }
    .qc-title { display: block; font-family: 'Bebas Neue', sans-serif; font-size: 1.2rem; letter-spacing: 0.08em; color: #fff; line-height: 1; }
    .qc-sub   { display: block; font-size: 0.7rem; color: #aaa; margin-top: 0.2rem; letter-spacing: 0.05em; }

    /* Capacity bar */
    .cap-bar-wrap { display: flex; align-items: center; gap: 0.5rem; font-size: 0.8rem; }
    .cap-bar  { flex: 1; height: 3px; background: #2a2a2a; border-radius: 2px; min-width: 60px; }
    .cap-fill { height: 100%; background: #fff; border-radius: 2px; }

    /* Member specifics */
    .stat-active .stat-box-value { color: #68d391; }
    .stat-warn   .stat-box-value { color: #f6e05e; }
    .stat-trainer { font-size: 1.4rem; }
    .expiry-bar  { margin-bottom: 2rem; }
    .expiry-info, .expiry-warn { display: flex; align-items: center; justify-content: space-between; gap: 1rem; padding: 0.875rem 1.25rem; border-radius: 4px; font-size: 0.875rem; flex-wrap: wrap; }
    .expiry-info { background: rgba(255,255,255,0.04); border: 1px solid #2a2a2a; color: #777; }
    .expiry-warn { background: rgba(236,201,75,0.08); border: 1px solid rgba(236,201,75,0.25); color: #f6e05e; }
    .renew-btn { padding: 0.4rem 1rem; background: #f6e05e; color: #000; font-size: 0.7rem; font-weight: 700; letter-spacing: 0.1em; border-radius: 2px; text-decoration: none; }
    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; }
    .booking-list { display: flex; flex-direction: column; gap: 1px; background: #1a1a1a; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; }
    .booking-item { background: #111; display: flex; justify-content: space-between; align-items: center; padding: 1rem 1.25rem; }
    .booking-info { display: flex; flex-direction: column; gap: 0.2rem; }
    .booking-info strong { font-size: 0.9rem; color: #fff; }
    .booking-info span   { font-size: 0.75rem; color: #666; }
    .empty-block { background: #111; padding: 2rem; text-align: center; color: #555; font-size: 0.875rem; border-radius: 4px; }
    .empty-block a { color: #999; }
    .action-list { display: flex; flex-direction: column; gap: 1px; background: #1a1a1a; border: 1px solid #1a1a1a; border-radius: 4px; overflow: hidden; }
    .action-row { background: #111; display: flex; justify-content: space-between; align-items: center; padding: 1.1rem 1.25rem; font-size: 0.8rem; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; color: #888; text-decoration: none; transition: all 0.2s; }
    .action-row:hover { background: #1a1a1a; color: #fff; }
    .arrow { color: #444; transition: transform 0.2s; }
    .action-row:hover .arrow { transform: translateX(4px); color: #fff; }

    @media (max-width: 900px) { .two-col { grid-template-columns: 1fr; } .quick-grid { grid-template-columns: repeat(2, 1fr); } }
    @media (max-width: 600px) { .quick-grid { grid-template-columns: 1fr; } .dash-hero { height: 160px; } }
  `]
})
export class DashboardComponent implements OnInit {
  memberStats: any = {}; attendanceStats: any = {}; revenueStats: any = {};
  recentClasses: any[] = []; trainerClasses: any[] = []; memberBookings: any[] = [];
  memberProfile: any = null; streak: any = null; myClients: Member[] = [];

  constructor(
    public auth: AuthService,
    private membersService: MembersService,
    private classesService: ClassesService,
    private attendanceService: AttendanceService,
    private paymentsService: PaymentsService,
    private trainersService: TrainersService,
    private assignmentsService: AssignmentsService
  ) {}

  ngOnInit() {
    if (this.auth.isAdmin()) this.loadAdmin();
    else if (this.auth.isTrainer()) this.loadTrainer();
    else this.loadMember();
  }

  loadAdmin() {
    this.membersService.getStats().subscribe(s => this.memberStats = s);
    this.attendanceService.getStats().subscribe(s => this.attendanceStats = s);
    this.paymentsService.getRevenueStats().subscribe(s => this.revenueStats = s);
    this.classesService.getAll().subscribe(c => this.recentClasses = c.slice(0, 6));
  }

  loadTrainer() {
    this.trainersService.getMe().subscribe(t => this.classesService.getTrainerSchedule(t.id).subscribe(c => this.trainerClasses = c));
    this.attendanceService.getStats().subscribe(s => this.attendanceStats = s);
    this.assignmentsService.getMyClients().subscribe(m => this.myClients = m);
  }

  loadMember() {
    this.membersService.getMe().subscribe(m => {
      this.memberProfile = m;
      this.classesService.getMemberSchedule(m.id).subscribe(b => this.memberBookings = b);
      this.attendanceService.getMemberStreak(m.id).subscribe(s => this.streak = s);
    });
  }

  isExpiringSoon(): boolean {
    if (!this.memberProfile?.subscription_expiry) return false;
    return (new Date(this.memberProfile.subscription_expiry).getTime() - Date.now()) < 3 * 86400000;
  }
}
