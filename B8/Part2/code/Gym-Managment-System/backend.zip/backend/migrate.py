#!/usr/bin/env python3
"""Add tables and columns that exist in the models but not yet in the SQLite database.

Existing data is kept. New columns are filled with their model default for existing rows.
"""
from sqlalchemy import inspect, text

from app.database import engine, Base
from app import models  # noqa: F401  (registers all tables on Base.metadata)


def migrate() -> None:
    inspector = inspect(engine)
    existing_tables = set(inspector.get_table_names())

    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if table.name not in existing_tables:
                continue
            existing_columns = {c["name"] for c in inspector.get_columns(table.name)}
            for column in table.columns:
                if column.name in existing_columns:
                    continue
                column_type = column.type.compile(dialect=engine.dialect)
                ddl = f'ALTER TABLE {table.name} ADD COLUMN {column.name} {column_type}'
                if column.foreign_keys:
                    fk = next(iter(column.foreign_keys))
                    ddl += f' REFERENCES {fk.column.table.name}({fk.column.name})'
                conn.execute(text(ddl))
                default = column.default.arg if column.default is not None and column.default.is_scalar else None
                if default is not None:
                    conn.execute(
                        text(f'UPDATE {table.name} SET {column.name} = :value WHERE {column.name} IS NULL'),
                        {"value": default},
                    )
                print(f"Added column {table.name}.{column.name}")

    new_tables = [t for t in Base.metadata.sorted_tables if t.name not in existing_tables]
    Base.metadata.create_all(bind=engine, tables=new_tables)
    for table in new_tables:
        print(f"Created table {table.name}")
    print("Migration complete.")


if __name__ == "__main__":
    migrate()
