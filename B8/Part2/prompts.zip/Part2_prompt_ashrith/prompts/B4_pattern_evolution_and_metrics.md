# Prompt B4 — Compare the Baseline and Evolved Designs

## Goal
Explain how CR-1, CR-2, and CR-3 changed the system's design, and support the explanation with code evidence rather than general claims about good design.

## Inputs
Use the identified baseline revision and the actual revision containing the completed change requests. If a change is incomplete, report it as incomplete.

## Tasks
1. Define version labels for baseline and each change stage. Record commits or directories so the comparison can be reproduced.
2. Summarize user-visible behavior before and after each change.
3. Compare relevant source structures: responsibilities, dependencies, control flow, and extension points.
4. Update the pattern inventory. For each relevant instance, state whether it was `introduced`, `retained`, `modified`, `removed`, or `uncertain`. Define these status terms before using them.
5. Create `patterns_evolution.csv` with exactly:
   `change_id,source_version,pattern_name,instance_name,status,source_locations,evidence,reason`
6. Measure a small set of useful metrics using the same method for baseline and evolved versions. Suitable options include changed files, additions/deletions, test counts, or complexity from a consistent tool. Only report metrics that can be measured reliably.
7. Explain what each metric does and does not demonstrate. Do not equate more lines or more tests automatically with better quality.
8. Record refactoring trade-offs, remaining coupling, and limitations.

## Required output
- Version map.
- Before/after table per change request.
- Updated pattern inventory and `patterns_evolution.csv`.
- Metrics table with measurement method, commands/tools, values, and interpretation.
- Design trade-off discussion.
- Missing evidence and unresolved questions.

## Quality rules
Never backdate a new pattern into the baseline. Never fabricate timing, complexity, test counts, or line numbers. Keep measured values separate from qualitative judgments.

Save to `results/result-B4-pattern-evolution-and-metrics.md`.
