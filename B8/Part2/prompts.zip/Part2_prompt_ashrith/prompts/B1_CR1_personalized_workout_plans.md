# Prompt B1 — Change Request CR-1: Personalized Workout Plans

## Scenario
The gym application should support workout plans that can be tailored to a member's goals or profile, rather than relying only on a single fixed plan.

## Goal
Implement a small, coherent version of this capability using the existing codebase and data model as the starting point.

## Before coding
1. Inspect the existing workout-plan and member flows.
2. Record which member attributes and plan information actually exist.
3. Identify missing information. Do not silently invent fields or assume that a recommendation engine already exists.
4. Write a user story and at least four acceptance criteria, including a normal case, a missing-data case, and an invalid or unsupported input case.
5. Propose a design with clear responsibilities. Explain how it fits the current architecture and identify one alternative you considered.

## Implementation requirements
1. Make the smallest end-to-end change that satisfies the criteria.
2. Keep existing plan behavior working where personalization information is unavailable, or define and test a clear fallback.
3. Validate input and handle empty or unsupported values.
4. Add or update tests for the acceptance criteria.
5. Avoid unrelated cleanup that makes the change difficult to review.
6. Record all changed files and important symbols with verified source locations.

## Required output
- User story and acceptance criteria.
- Baseline workflow and constraints.
- Design decision, rationale, and rejected alternative.
- Implementation summary by file.
- Tests run: exact command, expected behavior, actual result, pass/fail/not run.
- Known limitations and next steps.
- A short note on whether the change introduces, modifies, or does not materially affect a design-pattern instance.

## Evidence rules
Never claim tests passed unless you ran them and observed the result. If the environment prevents execution, provide the command and mark the result `not run`.

Save to `results/result-B1-CR1-personalized-workout-plans.md`.
