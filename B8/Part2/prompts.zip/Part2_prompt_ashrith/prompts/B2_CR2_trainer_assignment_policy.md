# Prompt B2 — Change Request CR-2: Configurable Trainer-Assignment Policies

## Scenario
The gym application should support more than one rule for assigning a trainer, instead of hard-coding one assignment decision throughout the workflow.

## Goal
Add at least two selectable assignment policies, provided the existing data supports them. Potential examples include availability-based assignment or workload-based assignment. Do not implement a policy whose required data does not exist unless you explicitly add and document that data.

## Before coding
1. Trace the current trainer assignment workflow from its caller to the assignment result.
2. Identify existing trainer/member/class fields that can legitimately inform assignment.
3. Define the policy interface or equivalent boundary and explain which component chooses and invokes a policy.
4. Write acceptance criteria for policy selection, a successful assignment, no eligible trainer, and missing or incomplete data.
5. Explain why your design makes adding a future policy easier. Compare it with a simpler conditional-based implementation.

## Implementation requirements
1. Implement two distinct policies with observable differences.
2. Ensure the application can actually select and execute each policy; do not merely create unused classes.
3. Keep the assignment caller independent of policy-specific implementation details where practical.
4. Add tests for each policy and important edge cases.
5. Document any tie-breaking rule, default policy, and failure behavior.
6. Record the files, symbols, and verified source locations changed.

## Required output
- Existing-flow analysis.
- Policy definitions and inputs.
- Acceptance criteria.
- Design rationale and alternative.
- Implementation summary.
- Test table with commands and actual observed outcomes.
- Pattern interpretation with evidence, including any uncertainty.
- Remaining limitations.

## Evidence rules
Do not claim the Strategy pattern is present just because multiple classes exist. Show how the caller delegates behavior to a selectable policy. If the implementation uses a different design, describe it accurately.

Save to `results/result-B2-CR2-trainer-assignment-policy.md`.
