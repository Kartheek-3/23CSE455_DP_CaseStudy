# Prompt B5 — Regression Review and Part B Submission Gate

## Role
Act as a reviewer responsible for deciding whether the evolved application is sufficiently verified for submission.

## Tasks
1. Check each acceptance criterion from CR-1, CR-2, and CR-3 against implementation evidence and tests.
2. Verify that tests correspond to the current evolved revision, not an older working copy.
3. Review existing core workflows likely to be affected by the changes.
4. Check negative cases, missing data, and failure behavior.
5. Confirm that new abstractions are used by real application flows rather than existing as unused example code.
6. Verify that `patterns_evolution.csv` rows refer to actual changes and use the agreed status definitions.
7. Recalculate or reproduce every reported metric where possible.
8. Identify any untested behavior, regressions, design overcomplication, or unsupported claims.

## Required output
- A review table with `check`, `evidence`, `status` (`pass`, `fail`, `not verified`), `impact`, and `next action`.
- A prioritized defect list.
- A list of exact commands another reviewer can run.
- A final recommendation: `ready`, `ready with disclosed limitations`, or `not ready`, with reasons.

## Important
A missing test result is `not verified`, not a pass. Do not hide incomplete work to make the report appear finished.

Save to `results/result-B5-regression-and-submission-review.md`.
