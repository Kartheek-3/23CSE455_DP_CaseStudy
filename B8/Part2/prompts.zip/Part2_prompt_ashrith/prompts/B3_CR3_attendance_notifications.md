# Prompt B3 — Change Request CR-3: Attendance-Triggered Notifications

## Scenario
When attendance is recorded or a defined attendance event occurs, the system should be able to notify the relevant recipient without making the attendance logic responsible for every detail of message delivery.

## Goal
Add a testable notification flow that fits the actual attendance implementation.

## Before coding
1. Trace the existing attendance workflow and identify the exact point at which attendance is successfully recorded.
2. Determine what information is available at that point and who should receive a notification.
3. Specify the trigger, recipient, message content, and expected behavior when recipient data is missing.
4. Decide what should happen if notification delivery fails. Explain whether attendance should remain saved and how failures are reported.
5. Consider duplicate events and how tests can avoid sending real email, SMS, or push notifications.
6. If the application has no notification system, clearly label the new interface or test implementation as newly introduced.

## Implementation requirements
1. Separate the decision to notify from the implementation that delivers the message where practical.
2. Use a fake, stub, or mock delivery component in automated tests.
3. Test the successful path, delivery failure, and at least one missing-data or duplicate-event case relevant to the chosen design.
4. Avoid claiming asynchronous processing, retry logic, or durable delivery unless it is actually implemented.
5. Record all affected files and source locations.

## Required output
- Existing attendance flow with evidence.
- Notification event contract.
- Failure and duplicate handling decisions.
- Implementation summary.
- Test commands and actual outcomes.
- Pattern impact discussion supported by source evidence.
- Known limitations and possible future work.

Save to `results/result-B3-CR3-attendance-notifications.md`.
