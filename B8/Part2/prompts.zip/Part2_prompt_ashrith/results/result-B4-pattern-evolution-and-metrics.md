# Result B4 — Pattern Evolution and Metrics
## Version map
| Label | Commit/directory | Changes included |
|---|---|---|

## Before/after summary
| Change | Previous behavior | New behavior | Evidence | Test status |
|---|---|---|---|---|

## `patterns_evolution.csv`
Header:
`change_id,source_version,pattern_name,instance_name,status,source_locations,evidence,reason`

## Metrics
| Metric | Baseline | Evolved | Method/tool | Same method? | Interpretation |
|---|---|---|---|---|---|

## Trade-offs, limitations, unresolved evidence
-
