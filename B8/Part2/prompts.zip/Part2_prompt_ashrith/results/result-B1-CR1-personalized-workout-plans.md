# Result B1 — CR-1 Personalized Workout Plans
## User story
## Acceptance criteria
- [ ] Normal case:
- [ ] Missing data:
- [ ] Invalid/unsupported input:
- [ ] Existing behavior preserved or fallback defined:

## Baseline evidence
| Existing behavior | Path/lines | Constraint |
|---|---|---|

## Design decision
- Chosen approach:
- Alternative:
- Rationale:

## Implementation
| File/lines | Change | Criterion |
|---|---|---|

## Tests actually run
| Command/test | Expected | Actual | Status |
|---|---|---|---|

## Pattern impact and limitations
-
