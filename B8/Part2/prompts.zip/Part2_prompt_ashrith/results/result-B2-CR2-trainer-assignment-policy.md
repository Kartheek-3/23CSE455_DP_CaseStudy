# Result B2 — CR-2 Trainer-Assignment Policies
## Existing assignment flow
## Policy definitions
| Policy | Inputs | Expected result | No-eligible-trainer behavior |
|---|---|---|---|

## Acceptance criteria
- [ ] Policy selection works through an actual caller.
- [ ] Each policy has tests.
- [ ] Tie-breaking/default behavior is documented.
- [ ] Missing data is handled.

## Implementation evidence
| File/lines | Responsibility | Evidence |
|---|---|---|

## Tests actually run
| Command/test | Expected | Actual | Status |
|---|---|---|---|

## Pattern justification and limitations
-
