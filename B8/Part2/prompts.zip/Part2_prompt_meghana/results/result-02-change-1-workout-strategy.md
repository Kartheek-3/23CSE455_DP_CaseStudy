# Result 02 — Change 1: Personalized Workout Recommendations

**Status: USER-REPORTED; evolved source not included for independent verification.**

## 1. Reported behavior

The summary describes six workout-goal strategies: General Fitness, Weight Loss, Muscle Building, Strength Training, Endurance, and Flexibility. A factory selects the strategy for a goal. The system reportedly detects goals from member free text, stores the goal on plans, exposes one endpoint to list goals and another to retrieve recommendations, and updates the Plans page with a selector and suggested-exercises panel.

## 2. Why Strategy is a plausible fit

The intended Strategy collaboration is:
- Context: recommendation service/use case.
- Strategy contract: common recommendation method.
- Concrete strategies: one per supported fitness goal.
- Client: endpoint/UI workflow that chooses a goal and requests recommendations.

The design is justified if each concrete strategy encapsulates a different algorithm and the context invokes them through the same contract. If the code is only one long conditional that returns different static lists, the Strategy claim needs re-evaluation.

## 3. Why Factory is a separate candidate

The reported factory maps a goal to a strategy. To count it separately, the source should show a distinct creation/selection responsibility rather than treating any `if` statement as a Factory pattern.

## 4. Baseline relationship

The baseline already stores and manages workout plans (`backend/app/models.py`, `WorkoutPlan`, around lines 235–254; `backend/app/routers/plans.py`, around lines 51–153). Therefore the change should be described as **goal-based recommendation and plan-goal extension**, not as creation of workout plans from scratch.

## 5. Verification required

- Actual strategy contract and six concrete strategy source paths.
- Factory mapping and unknown-goal behavior.
- Text detection rules and ambiguity handling.
- Exact API paths/methods/schemas.
- Goal persistence/migration compatibility.
- Angular refresh behavior for goal, difficulty, and member.
- Actual test output. The reported 11 checks remain unverified until logs are supplied.

No numeric pattern count or exact source line references for the evolved classes can be supplied from the current archive.
