# Result 05 — Part 2 Evolution Matrix and Count Status

## 1. Required version labels

Use one consistent set of source-version labels, for example:
- `original`
- `after_change1`
- `after_change2`
- `after_change3`

Use the team's actual names if already standardized, but never use “submission stage” as a source version.

## 2. Likely pattern candidates from the supplied summary

| Pattern | Reported instance | Expected status |
|---|---|---|
| Strategy | Workout recommendation policies | Newly introduced in Change 1, if source confirms the collaboration |
| Factory | Workout-goal strategy selection | Newly introduced in Change 1, if a distinct factory is present |
| Strategy | Trainer-assignment policies | Newly introduced in Change 2, one collaboration with three concrete policies |
| Angular root service/shared service mechanism | AssignmentsService | Framework-managed service scope; classify carefully rather than automatically counting GoF Singleton |
| Observer | Attendance event notification | Newly introduced in Change 3, if source proves publisher/subscriber behavior |

This table is a candidate matrix, not a final confirmed inventory. Baseline dependency-injection mechanisms should be tracked separately from GoF counts if the course's confirmed pattern count is intended to count application-level design patterns.

## 3. CSV status

The baseline ZIP's `Part2/pattern_evolution.csv` and `Part2/Pattern_count.csv` are empty. The required evolution schema in the faculty PDF is `patterns_evolution.csv` with columns:
`source_version,pattern_name,pattern_type,instance_name,participant_roles,source_locations,intent_and_evidence,status_after_change,change_description`.

The count schema is:
`source_version,summary,pattern_name,count`.

## 4. Why final counts are withheld

The evolved source and diffs are absent. Exact participant roles, source paths, confirmed statuses, and removals cannot be verified. The correct next action is to populate the matrix after source inspection, not to generate plausible-looking counts now.
