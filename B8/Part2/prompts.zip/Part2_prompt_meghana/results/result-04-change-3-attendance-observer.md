# Result 04 — Change 3: Attendance Notifications and Observer

**Status: USER-REPORTED; evolved source not included for independent verification.**

## 1. Baseline behavior

The baseline already has attendance operations in `backend/app/routers/attendance.py`, notification persistence/routes in `backend/app/models.py` and `backend/app/routers/notifications.py`, email/SMS helper functions in `backend/app/utils/notifications.py`, and Angular notification/attendance services. For example, baseline workout-plan creation adds an email task directly through `BackgroundTasks` (`backend/app/routers/plans.py`, around lines 81–90). This direct call is not by itself an Observer implementation.

## 2. Reported evolved behavior

The supplied summary describes an attendance event publisher and four observers:
- in-app notification;
- email;
- SMS;
- assigned-trainer alert.

It also reports member email/SMS preferences, unread counts, mark-one/read-all, filtering, a 30-second Angular polling loop, a notification badge/panel, and a close-class action that marks booked non-attendees as no-shows after class start.

## 3. Observer proof requirements

The evolved source must show:
- a publisher/event source;
- event contract/payload;
- observer contract or independently registered callbacks;
- four concrete observers;
- subscription/dispatch mechanism;
- event types and recipient selection;
- behavior when an observer fails;
- prevention of duplicate notifications.

Four helper calls inside one attendance route do not automatically establish Observer. The architectural point is that attendance publishes an event without embedding the delivery-channel logic or directly managing each observer.

## 4. No-show safety checks

Verify the class has started, only booked non-attendees are marked, already attended members are untouched, repeat close is idempotent, authorization is enforced, and notifications are not duplicated.

## 5. Verification required

Inspect the evolved publisher, observer classes, notification routes/service, close-class endpoint, frontend polling lifecycle, and actual tests. The reported 21 checks remain unverified from the uploaded archive.
