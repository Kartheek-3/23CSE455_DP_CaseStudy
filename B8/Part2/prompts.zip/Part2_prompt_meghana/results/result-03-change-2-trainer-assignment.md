# Result 03 — Change 2: Trainer-Assignment Policies

**Status: USER-REPORTED; evolved source not included for independent verification.**

## 1. Reported behavior

The summary describes three interchangeable policies:
- specialization match;
- least loaded;
- highest rated.

It also reports a member-to-trainer assignment, `max_clients` capacity, an assignment-history table, assign/unassign/auto-assign/history/my-clients endpoints, trainer-specific plan ownership checks, startup migration, and Angular changes including an `AssignmentsService`.

## 2. Strategy assessment

The Strategy pattern is appropriate if all policies satisfy a common contract and the assignment workflow can choose among them without containing each algorithm inline. The three policies form one Strategy collaboration; do not count three concrete policies as three Strategy instances.

## 3. Important correctness checks

- Capacity is enforced by the backend in both manual and automatic assignment.
- The selection and assignment are atomic enough to avoid exceeding capacity under concurrent requests.
- Missing ratings/specializations and ties have deterministic documented behavior.
- No-eligible-trainer cases return an understandable result.
- Assignment history retains the actor, time, action, and prior/new assignment where required.
- Migration can be safely rerun and does not silently corrupt existing databases.
- Trainer ownership checks are enforced server-side, not only by filtering the Angular dropdown.
- Unassignment and reassignment retain the required history.

## 4. Singleton classification

The baseline already uses Angular services with `@Injectable({ providedIn: 'root' })`, including `PlansService` (`frontend/src/app/services/plans.service.ts`, lines 7–11). The reported new `AssignmentsService` may be a shared root-provided service, but that alone does not establish a manually implemented GoF Singleton. Record Angular-managed application scope accurately.

## 5. Verification required

Inspect actual assignment model, policy interface/classes, router, migration, Angular service/components, and test logs. The reported 19 checks are not independently verified in the available archive.
