# Prompt 05 — Part 2 Pattern Evolution Matrix and Versioned Counts

## Objective

Maintain the required version-by-version pattern evidence across baseline, after Change 1, after Change 2, and after Change 3.

## Required CSV

Use the assignment's exact schema for `patterns_evolution.csv`:
- `source_version`
- `pattern_name`
- `pattern_type`
- `instance_name`
- `participant_roles`
- `source_locations`
- `intent_and_evidence`
- `status_after_change`
- `change_description`

One row is one confirmed collaboration in one source version. Preserve the same `instance_name` when a collaboration continues through a change. Retain removed instances with status `removed`.

The assignment also requires `pattern_counts.csv` with:
- `source_version`
- `summary`
- `pattern_name`
- `count`

## Procedure

1. Start from the confirmed Part 1 baseline inventory.
2. For each change, compare actual source snapshots/diffs.
3. Add rows only for confirmed collaborations.
4. Mark existing collaborations as preserved/modified/extended/replaced/removed/newly_introduced as applicable.
5. Count per source version independently.
6. Do not count Strategy's multiple concrete policies as multiple Strategy instances when they form one collaboration.
7. Do not count the same before/after instance twice in a single version.
8. Exclude rejected/uncertain candidates from confirmed counts.
9. Reconcile the matrix with architecture diagrams, code paths, and tests.

## Required output

CSV files plus a concise audit note listing all additions/removals and any uncertain pattern claims. If the baseline inventory is incomplete or the evolved source is missing, state that the matrix cannot yet be finalized; do not fabricate a complete CSV.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
