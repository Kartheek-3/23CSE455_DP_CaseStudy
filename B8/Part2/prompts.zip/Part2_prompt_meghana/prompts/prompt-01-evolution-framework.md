# Prompt 01 — Part 2 Evolution Framework, Baseline Comparison, and Evidence Protocol

## Role

Act as a senior software architect, refactoring specialist, test engineer, and empirical software engineering researcher. Continue the B10 Design Pattern Case Study for the Gym Management System.

## Immutable source boundary

- Original application: `data/code/Gym-Managment-System/` — preserve unchanged.
- Evolved application: `Part2/code/Gym-Managment-System/` — use only if present and inspectable.
- Baseline stack: Angular 17 frontend; Python FastAPI backend; SQLAlchemy ORM.
- The supplied Part 2 summary describes three completed changes, but a description is not a substitute for inspecting evolved source, diffs, and test logs.

## Required changes

1. Change 1: Personalized workout recommendations based on fitness goal and difficulty; six goals; Strategy plus a goal-selection Factory; goal detection from member text; new goal/recommendation endpoints; Plans UI updates.
2. Change 2: Trainer assignment by policy; specialization match, least loaded, highest rated; trainer capacity; assignment history; role-aware endpoints and UI; database migration; app-wide Angular AssignmentsService.
3. Change 3: Attendance event notifications; four observers (in-app, email, SMS, assigned-trainer alert); preferences; unread/read/filter operations; close-class/no-show workflow; Angular notification panel and polling.

## Objective

Produce a defensible before/after evolution record. Do not merely say that a feature was added or a pattern was used. Show the original design, new requirement, changed participants, interactions, evidence, tests, and consequences.

## Required method

For each change:
1. Reconstruct only the relevant baseline behavior.
2. Inspect the evolved source and use `git diff` or an equivalent file comparison.
3. Identify added, modified, and removed files.
4. Map each pattern role to concrete classes/interfaces/functions.
5. Distinguish a design intention from an implemented collaboration.
6. Run or inspect actual tests and retain raw output.
7. Check authorization, validation, error handling, persistence, migration, and failure paths.
8. Record impact as `preserved`, `modified`, `extended`, `replaced`, `removed`, or `newly_introduced`.
9. Update `patterns_evolution.csv` and counts without double-counting the same continuing instance.
10. Preserve evidence and limitations.

## Required outputs

- Change-by-change analysis.
- Before/after architecture and UML.
- File/diff evidence index.
- Tests and actual results.
- Pattern evolution CSV and per-version pattern counts.
- Risks, trade-offs, and remaining work.

## Evidence discipline

Use four labels consistently: `SOURCE-VERIFIED`, `USER-REPORTED`, `PROPOSED`, and `NOT-VERIFIED`. The summary reports 11, 19, and 21 checks for Changes 1, 2, and 3 respectively; treat these as user-reported until test logs or reproducible commands are available. Do not state that a pattern or test is source-verified without the evolved code.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
