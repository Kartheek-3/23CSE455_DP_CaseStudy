# Prompt 06 — Part 2 Regression, Test Evidence, Diff, and Submission Audit

## Role

Act as a test lead and research-evidence auditor.

## Objective

Prove that the three Part 2 changes work, preserve existing behavior, and have enough evidence for an academic case study.

## Required evidence for each change

- requirement/specification;
- source file list;
- baseline-to-evolved diff;
- test files and test command;
- raw terminal output and pass/fail count;
- manual UI evidence where relevant;
- API request/response examples with sensitive data removed;
- migration evidence for existing database state;
- pattern-role mapping and source line ranges;
- known limitations.

## Test suites

### Change 1
Six supported goals, unknown goal, text goal detection, difficulty changes, member changes, API auth, persisted goal, regression of workout-plan CRUD.

### Change 2
All three policies, capacity enforcement, tie/missing data cases, no eligible trainer, manual/automatic assignment, reassignment/unassignment history, trainer/member/admin access, plan ownership, migration idempotency.

### Change 3
Check-in events, four observer outcomes, email/SMS opt-out, trainer routing, unread/read-all/filter, no-show rules before/after class start, repeated close, duplicate events, delivery failure, polling cleanup, role access.

## Reported counts

The project summary reports 11 checks for Change 1, 19 for Change 2, and 21 for Change 3. Treat these as `USER-REPORTED` until the actual test command/output is captured. Determine whether counts mean test cases, assertions, or checks and whether suites overlap; do not sum them into a unique-test total without proof.

## Final audit

- Confirm `data/` remained unchanged.
- Confirm all implementation work resides in `Part2/code/Gym-Managment-System`.
- Check CSV schemas and paths.
- Check README environment versions and run/test instructions.
- Ensure no credentials, caches, compiled binaries, or unneeded artifacts are submitted.
- Report blockers honestly.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
