# Prompt 03 — Change 2: Trainer-Assignment Policies, Capacity, and History

## Context

The baseline has Trainer and TrainerAvailability entities in `backend/app/models.py`, trainer endpoints in `backend/app/routers/trainers.py`, member endpoints in `backend/app/routers/members.py`, and plan ownership represented by `WorkoutPlan.trainer_id`. The supplied summary reports three assignment policies and a new assignment-history model/API.

## Objective

Verify the evolved design and evaluate the Strategy pattern, authorization boundaries, and data integrity.

## Required policy analysis

Investigate the three reported policies:
- specialization match,
- least loaded,
- highest rated.

For each policy, document its input data, selection rule, tie-breaking behavior, handling of missing specialization/rating, deterministic behavior, and capacity constraints. Identify the common policy interface and the context/service that invokes it. Explain how policy selection can change without rewriting the assignment workflow.

## Data model and persistence

Verify:
- `Member` or associated profile's assigned-trainer relationship.
- `Trainer.max_clients` or equivalent capacity field.
- Assignment history table/model and its foreign keys/timestamps/actor.
- Migration script behavior against an existing database, idempotency, backup assumptions, and startup invocation.
- Transaction behavior when assignment fails midway.
- Whether unassignment retains history instead of deleting evidence.

## API and authorization

The summary reports assign, unassign, auto-assign, history, and my-clients endpoints under `/api/assignments`. Verify actual paths and methods from source rather than copying this wording blindly. For each endpoint, document role authorization, validation, status codes, and edge cases.

Check that:
- a trainer cannot exceed capacity, including concurrent/manual assignment attempts;
- a trainer can create/edit plans only for their own assigned clients;
- admin, trainer, and member views are appropriately scoped;
- auto-assignment reports when no eligible trainer exists.

## Angular impact

Inspect the member assignment dialog/actions, trainer capacity badge, dashboard My Clients/Your Trainer panels, plans dropdown filtering, and `AssignmentsService`. Determine whether `providedIn: 'root'` makes it framework-managed shared service behavior rather than a manually enforced GoF Singleton.

## Required outputs

- Strategy collaboration diagram and participant map.
- Assignment state/data-flow diagram.
- Endpoint and authorization table.
- Migration review.
- Test matrix: capacity, each policy, ties, no eligible trainer, reassignment, unassignment history, role access, plan ownership, migration rerun.
- Exact paths/line ranges and actual test evidence.

Do not label the change fully verified until the evolved source, migration, and test outputs are available.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
