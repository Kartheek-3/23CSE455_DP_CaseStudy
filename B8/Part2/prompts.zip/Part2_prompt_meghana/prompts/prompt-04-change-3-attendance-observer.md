# Prompt 04 — Change 3: Attendance Notifications With Observer

## Context

The baseline attendance router is `backend/app/routers/attendance.py`; notification persistence and preferences are represented in `backend/app/models.py` and `backend/app/routers/notifications.py`; delivery helpers are in `backend/app/utils/notifications.py`. The baseline includes QR/manual attendance flows and notification settings, but the supplied summary reports a new event/observer design and no-show workflow.

## Objective

Inspect the evolved source to determine whether the implementation genuinely separates event publication from independent reactions.

## Required Observer analysis

The summary reports four observers:
1. in-app notification,
2. email,
3. SMS,
4. alert to assigned trainer.

For each, identify the observer interface/callback, concrete observer class/function, subscription/registration mechanism, event types handled, filtering/preferences, and error handling. Identify the publisher/subject and show the exact event dispatch sequence. Explain whether the attendance operation knows the concrete recipients or delivery channels.

Do not call four direct sequential function calls an Observer implementation unless there is a defensible publisher/subscriber abstraction.

## Attendance event coverage

Trace check-in and the reported attendance-streak/missed-class events. Document event payload, user/member/trainer IDs, deduplication/idempotency, event timing, transaction ordering, and what happens if one observer fails.

## Close-class/no-show behavior

Verify the close-class endpoint/action:
- only allowed after class start;
- determines booked members who did not attend;
- marks them as no-show exactly once;
- does not overwrite valid attendance;
- checks permissions and class ownership;
- emits appropriate events without duplicate notification delivery.

## Notification API and frontend

Verify unread count, mark-one/read-all, filtering, user preferences, and the 30-second polling claim. Inspect notification panel/badge, polling lifecycle cleanup, duplicate requests, and error/loading behavior. Verify that email/SMS preferences affect delivery without suppressing required in-app or trainer alerts unless intended.

## Required outputs

- Observer UML and event sequence diagram.
- Observer participant/evidence table.
- Endpoint contract and authorization table.
- Failure-mode and idempotency analysis.
- Test matrix and actual logs.
- Before/after classification.

Do not infer source paths, event names, or exact endpoint paths from the summary; recover them from the evolved code.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
