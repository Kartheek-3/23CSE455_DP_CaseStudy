# Prompt 02 — Change 1: Personalized Workout Recommendations (Strategy + Factory)

## Context

The baseline already has workout-plan CRUD and persistence:
- `backend/app/models.py`, `WorkoutPlan` around lines 235–254.
- `backend/app/routers/plans.py`, workout-plan create/list/get/update/delete endpoints around lines 51–153.
- `frontend/src/app/components/plans/plans.component.ts`.
- `frontend/src/app/services/plans.service.ts`.

The supplied Part 2 summary reports a new recommendation feature, six goal strategies, a factory, goal detection from a member's free text, two new endpoints, a stored plan goal, and a goal selector/suggestion panel in Angular.

## Objective

Analyze the actual Change 1 implementation and prove whether Strategy and Factory are justified.

## Required investigation

### Backend design
1. Locate the common strategy interface/protocol or common callable contract.
2. Identify all six concrete strategies: General Fitness, Weight Loss, Muscle Building, Strength Training, Endurance, Flexibility.
3. Explain each strategy's inputs, output schema, and recommendation rules.
4. Locate the factory and show how a goal maps to a strategy.
5. Trace free-text goal detection, including examples, ambiguous phrases, no match, multiple goals, case/spacing, and fallback behavior.
6. Locate both new endpoints and document method, path, auth requirements, request parameters/body, response schema, status/error behavior.
7. Show where the selected goal is persisted on a workout plan and how existing records are handled.
8. Verify the strategy output is deterministic or document any nondeterminism.

### Frontend behavior
1. Locate the goal selector and suggestion panel.
2. Trace refresh behavior when goal, difficulty, or member changes.
3. Explain how a member's stored fitness goal pre-fills the form.
4. Verify loading, empty, error, and stale-response states.
5. Check that suggested exercises are recommendations and are not silently saved as a plan without trainer action.

### Tests and quality
Test all six goals, unknown goal, text detection, difficulty variation, member changes, endpoint authorization, persistence, and regression of existing plan CRUD.

## Required result

- Pattern role table for Strategy and Factory.
- Sequence diagram from selected goal to returned recommendations.
- Exact source paths and line ranges.
- Endpoint contract table.
- Test matrix with actual commands/results.
- Change classification and risks.

Do not assume the six strategies or endpoints exist until found in the evolved source. A Factory is a separate pattern claim only if a distinct selection/creation responsibility is evidenced.

## Evidence and reporting rules (mandatory)

1. Treat `data/code/Gym-Managment-System` as the immutable original/baseline. Never edit it while implementing changes.
2. Treat `Part2/code/Gym-Managment-System` as the evolved application only when that directory is actually supplied. Do not infer its source from the baseline.
3. Distinguish **observed source evidence**, **user-reported implementation details**, **proposed design**, and **not yet verified**.
4. Do not invent class names, source paths, line numbers, commit hashes, model/date metadata, test results, runtime values, complexity values, screenshots, or historical LLM conversations.
5. A pattern is confirmed only when the collaboration/roles and interactions are demonstrated in source. Framework conventions alone are not automatically GoF patterns.
6. Keep exact assignment CSV column names. Use UTF-8 CSV, one header row, relative paths, quote fields containing commas.
7. For counts, count confirmed collaborations/instances, not every participant class. Exclude rejected or unconfirmed candidates from confirmed pattern counts.
8. Preserve raw prompts, supplied inputs, raw model outputs, and separate human verification. A reconstructed analysis is not a historical raw model output.
9. Keep secrets, `.env` files, dependency caches, compiled binaries, and credentials out of deliverables.
