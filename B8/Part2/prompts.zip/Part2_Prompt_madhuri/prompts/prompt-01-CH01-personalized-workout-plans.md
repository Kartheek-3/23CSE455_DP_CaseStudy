# Prompt 01 — CH01 Personalized Workout Plans

Evolve the supplied baseline to support personalized workout plans.

Supply:
- Baseline commit/snapshot:
- Existing workout-related source files:
- Part 1 patterns involving workout plans:
- Test framework and baseline test result:
- Existing member/workout models and business rules:

Tasks:
1. Define requirements and acceptance criteria for plan selection using member goals and fitness level; include equipment only if appropriate to the app.
2. Inspect current functionality first; distinguish existing behavior from new behavior.
3. Propose the smallest suitable design. Consider Strategy only if multiple interchangeable algorithms are genuinely needed.
4. Identify actual files to modify/create. Do not invent paths.
5. Provide a patch or implementation only when enough source is supplied.
6. Define tests for each supported goal/level, invalid or missing preferences, unsupported goals, and no suitable plan.
7. Explain how to execute tests. Mark them proposed until actual output is available.
8. State how each verified pattern instance is affected: preserved, modified, extended, replaced, removed, or newly_introduced.
9. Identify UML updates and evidence to save.
10. Provide a concise change record with baseline and after-version identifiers.

Do not overwrite the baseline or claim the feature is integrated/tested without execution evidence.
