# Prompt 05 — Part 2 Submission Audit

Audit the three software-evolution changes and their evidence.

Check:
- Baseline is preserved and reproducible.
- CH01, CH02, CH03 have requirements and acceptance criteria.
- Changed files and commit/snapshot IDs are recorded.
- Tests include relevant normal and edge cases; actual outcomes are evidenced.
- Pattern statuses follow the allowed vocabulary and are justified.
- Continuing collaborations retain instance_name; removed instances are retained historically.
- `patterns_evolution.csv` has exact required headers.
- Pattern counts reconcile per source version and exclude removed instances from current totals.
- Refactoring identifies a real smell, shows a diff, and includes behavior-preservation evidence.
- Metrics use consistent measurement rules.
- UML and LLM/human-verification records match the actual work.

Return pass/fail/pending with exact corrections. Do not mark tests or measurements passed without evidence.
