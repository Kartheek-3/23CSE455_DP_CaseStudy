# Prompt 02 — CH02 Trainer-Assignment Policies

Evolve the supplied baseline to support configurable trainer-assignment policies.

Supply:
- Baseline commit/snapshot:
- Existing trainer/member source files:
- Part 1 trainer-related pattern records:
- Existing eligibility and workload rules:
- Test framework and actual baseline test result:

Tasks:
1. Define requirements and acceptance criteria for trainer assignment.
2. Consider policies such as specialization matching and workload balancing only if supported by the application domain and available data.
3. Specify eligible trainers, tie-breaking, workload calculation, and behavior when no trainer is eligible.
4. Inspect existing code and propose the smallest appropriate change. Consider Strategy only if the code genuinely needs interchangeable policies.
5. Provide actual source paths and implementation guidance/patch when enough source is supplied.
6. Propose tests for matching, eligibility, workload, ties, invalid input, and no eligible trainer.
7. Distinguish proposed tests from tests actually run.
8. Record effects on existing and new pattern collaborations.
9. Identify relevant UML updates, source diffs, and evidence.
10. Prepare a change record with baseline/after version identifiers.

Do not invent classes, source paths, test results, or business rules that are not specified or implemented.
