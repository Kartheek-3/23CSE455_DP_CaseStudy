# Prompt 04 — Pattern Evolution, Refactoring, and Metrics

Using the verified baseline and the actual after-CH01, after-CH02, and after-CH03 source snapshots, prepare the evolution records.

Required `patterns_evolution.csv` columns:
source_version, pattern_name, pattern_type, instance_name, participant_roles, source_locations, intent_and_evidence, status_after_change, change_description

Allowed status values:
baseline, preserved, modified, extended, replaced, removed, newly_introduced

Tasks:
1. Create a record for each confirmed pattern collaboration in each source version.
2. Retain the same instance_name when a collaboration continues; name genuinely separate collaborations distinctly.
3. Retain removed-instance records with status removed, but exclude removed instances from current snapshot counts.
4. Update participant mappings and source line ranges for the correct version.
5. Recalculate pattern counts for baseline, after_CH01, after_CH02, and after_CH03 using the faculty schema.
6. Identify an actual code smell in the changed code and propose/describe a refactoring with a source diff.
7. Specify tests that demonstrate behavior preservation before/after refactoring. Report actual results only when execution output exists.
8. Compare source LOC and other available metrics using the same measurement scope/tool/rules.
9. Explain benefits, trade-offs, limitations, and any unavailable metrics.
10. Recommend UML updates based on real structural changes.

Rules:
- Do not count a continuing collaboration as a new instance merely because it appears in another snapshot.
- Do not infer pattern effects from feature names alone.
- Do not fabricate commits, paths, tests, metrics, or timing.
