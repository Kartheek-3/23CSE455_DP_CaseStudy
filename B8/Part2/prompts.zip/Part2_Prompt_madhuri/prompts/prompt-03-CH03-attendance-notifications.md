# Prompt 03 — CH03 Attendance Notifications

Evolve the supplied baseline to notify members about relevant attendance events.

Supply:
- Baseline commit/snapshot:
- Attendance and notification source files:
- Part 1 attendance/notification pattern records:
- Current notification channels and event model:
- Test framework and actual baseline test result:

Tasks:
1. Define notification events and acceptance criteria, such as attendance recorded and missed class, as supported by the app.
2. Inspect existing attendance and notification functionality before proposing changes.
3. Propose an event-driven design or Observer collaboration only if supported by the actual requirements and architecture.
4. Identify actual files to modify/create and provide a patch only when sufficient source is supplied.
5. Define tests for correct recipient/content, unrelated events, duplicate handling, missing data, and failures as applicable.
6. Explain how event source, subscribers/listeners, and notification delivery interact.
7. Record whether existing pattern collaborations are preserved, extended, modified, replaced, removed, or whether new ones are introduced.
8. Identify updated UML, diffs, tests, and evidence to save.
9. Mark test results as not_run until actual command output is supplied.

Do not assume email/push delivery is required unless the requirements say so. Do not claim Observer solely because an RxJS observable exists; explain the actual collaboration.
