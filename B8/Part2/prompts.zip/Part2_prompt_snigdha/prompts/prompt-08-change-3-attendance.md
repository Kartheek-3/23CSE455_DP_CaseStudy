# Prompt 08 — Part 2 Change 3: Attendance Notifications

Extend attendance with event-driven notifications.

Consider events such as:
- Attendance marked
- Class missed
- Attendance streak milestone

Requirements:
- Separate attendance event production from notification reactions.
- Support registering and removing observers/subscribers.
- Keep notification channels or handlers independently replaceable.
- Avoid sending duplicate notifications for the same event.
- Define what happens when a notification handler fails.
- Preserve role permissions and attendance data integrity.

Inspect actual implementation and identify whether the design is a true Observer collaboration, an RxJS state stream, or simply direct method calls. Provide event payloads, participant roles, tests, and source evidence.
