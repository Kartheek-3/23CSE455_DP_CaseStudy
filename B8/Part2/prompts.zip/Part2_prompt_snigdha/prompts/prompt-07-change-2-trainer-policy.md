# Prompt 07 — Part 2 Change 2: Trainer-Assignment Policies

Extend trainer assignment with selectable assignment policies.

Policies to evaluate:
- Specialization match
- Least loaded trainer
- Highest rated trainer

Requirements:
- Share common eligibility checks (for example, active trainer and capacity).
- Encapsulate each selection algorithm behind a common policy abstraction.
- Let the assignment workflow use a selected policy without embedding all algorithms in route handlers.
- Preserve admin authorization and existing assignment behavior where possible.
- Explain tie-breaking and the no-eligible-trainer case.

Inspect actual source before implementation. Record exact files and line ranges. Provide unit tests for each policy, edge cases, and API-level acceptance tests. Confirm whether Strategy is truly present in production code rather than only in a demonstration.
