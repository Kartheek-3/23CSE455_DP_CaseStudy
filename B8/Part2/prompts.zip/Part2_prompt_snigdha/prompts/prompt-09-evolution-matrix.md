# Prompt 09 — Build the Part 2 Pattern Evolution Matrix

Compare the original Gym Management System with each sequential change:
1. Original code
2. After Personalized Workout Plans
3. After Trainer-Assignment Policies
4. After Attendance Notifications

Use the source snapshots/patches supplied for each stage. Track pattern instances added, retained, modified, or removed.

For each stage:
- Count unique pattern types and distinct collaborations separately.
- Keep framework idioms and GRASP collaborations clearly labelled.
- Explain why a new feature creates (or does not create) a pattern.
- Cite exact source paths and line ranges.
- Do not assume that a proposed feature was merged or tested.

Output a stage-by-stage matrix and machine-readable CSV. Reconcile totals from the actual rows.
