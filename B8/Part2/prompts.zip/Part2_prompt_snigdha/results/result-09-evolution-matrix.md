# Result 09 — Part 2 Pattern Evolution Matrix

| Stage | Feature/change | Pattern impact to record |
|---|---|---|
| Original code | Existing Gym Management System | Only source-confirmed baseline collaborations |
| Change 1 | Personalized Workout Plans | Add recommendation Strategy only if interchangeable strategies exist |
| Change 2 | Trainer-Assignment Policies | Add Trainer Assignment Strategy if policy interface/context are implemented |
| Change 3 | Attendance Notifications | Add Attendance Observer if event publisher notifies registered observers |
| UI notification state | Notification state handling | Record separately if RxJS observable/subject collaboration is present |

## Counting rules
- Count distinct collaborations separately from unique pattern types.
- Do not count a new feature as a pattern automatically.
- Do not duplicate one collaboration because it appears in multiple files.
- Keep source version and stage labels exact.
- Derive totals from CSV rows, not from manually typed summary numbers.

## Important
Final counts must be recalculated from the actual approved `patterns.csv` and change snapshots. This document does not invent totals.
