# Result 07 — Part 2 Change 2: Trainer-Assignment Policies

## Intended feature
Allow trainer selection through interchangeable policies:
- Specialization match
- Least loaded
- Highest rated

## Pattern structure to verify
- Strategy: `TrainerAssignmentPolicy`
- Concrete strategies: `SpecializationMatchPolicy`, `LeastLoadedPolicy`, `HighestRatedPolicy`
- Context: assignment service/function that delegates selection
- Clients: manual and automatic assignment workflows

## Shared rules
Eligibility should be checked consistently, including active trainer status and client capacity. The case-study notes also identify trainer assignment and auto-assignment routes, plus an Angular assignment dialog/workflow.

## Verification boundary
The pattern structure is recorded in the project analysis, but the actual source snapshot and tests must be inspected before claiming the full feature is implemented and tested. Include tie-break rules and no-eligible-trainer behavior in acceptance tests.
