# Result 08 — Part 2 Change 3: Attendance Notifications

## Feature objective
Publish attendance-related events and allow notification handlers to react independently.

## Event examples
- `attendance_marked`
- `class_missed`
- `streak_milestone`

## Observer structure to verify
- Subject/publisher: attendance event publisher
- Observer contract: attendance observer
- Concrete observers: in-app, email, SMS, or trainer-alert handlers where present
- Event source: attendance workflow/router

## Related UI state
The separate notification-state observer may use an RxJS subject/observable to update unread notification state in the Angular UI. Do not merge this client-side state stream with the backend attendance event observer; they are distinct collaborations.

## Verification boundary
Confirm subscriber registration, removal, event payloads, duplicate prevention, and handler failure behavior from actual source and tests.
