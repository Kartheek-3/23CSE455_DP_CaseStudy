{application,backoff,
             [{description,"Exponential backoffs library"},
              {vsn,"1.1.6"},
              {applications,[stdlib,kernel]},
              {registered,[]},
              {licenses,["MIT"]},
              {links,[{"Github","https://github.com/ferd/backoff"}]},
              {maintainers,["Fred Hebert"]},
              {modules,[backoff]}]}.
